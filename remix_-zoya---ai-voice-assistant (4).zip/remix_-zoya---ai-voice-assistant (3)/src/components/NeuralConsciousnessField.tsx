import React, { useEffect, useRef } from "react";
import { EMOTION_META, RadhaConfig, RadhaEmotion } from "../services/memoryService";
import { getActiveAudioTelemetry } from "../services/liveService";
import { BossSentimentRecord } from "../services/sentimentService";

interface NeuralConsciousnessFieldProps {
  config: RadhaConfig;
  appState: "idle" | "listening" | "processing" | "speaking";
  emotion: RadhaEmotion;
  latestSentiment: BossSentimentRecord | null;
  ownerVerified: boolean;
  isWaitingForWakeWord?: boolean;
}

interface SynapticNode {
  theta: number;
  phi: number;
  baseRadius: number;
  speed: number;
  phaseOffset: number;
}

/**
 * Proprietary Signature Feature:
 * Real-Time 3D-Projected Synaptic Neural Consciousness Field.
 * Couples 64 geodesic 3D synaptic filaments + voiceprint harmonic rings directly to live FFT
 * bass/mid/treble energy, Radha's active emotion topology, Boss stress balance, and cursor gravity.
 */
export default function NeuralConsciousnessField({
  config,
  appState,
  emotion,
  latestSentiment,
  ownerVerified,
  isWaitingForWakeWord = false,
}: NeuralConsciousnessFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pointerRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });
  const shockwavesRef = useRef<Array<{ radius: number; alpha: number; color: string }>>([]);
  const isWaitingForWakeWordRef = useRef<boolean>(isWaitingForWakeWord);
  isWaitingForWakeWordRef.current = isWaitingForWakeWord;

  useEffect(() => {
    if (config.neuralFieldEnabled === false) return;

    const prefersReduced =
      typeof window !== "undefined" &&
      window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Generate golden-angle Fibonacci geodesic sphere of 64 synaptic nodes
    const nodeCount = 64;
    const nodes: SynapticNode[] = [];
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < nodeCount; i++) {
      const y = 1 - (i / (nodeCount - 1)) * 2;
      const phi = Math.acos(Math.max(-1, Math.min(1, y)));
      const theta = goldenAngle * i;
      nodes.push({
        theta,
        phi,
        baseRadius: 145 + (i % 4) * 14,
        speed: 0.004 + (i % 5) * 0.0011,
        phaseOffset: i * 0.42,
      });
    }

    const handlePointerMove = (e: PointerEvent) => {
      pointerRef.current = { x: e.clientX, y: e.clientY, active: true };
    };
    const handlePointerLeave = () => {
      pointerRef.current.active = false;
    };
    window.addEventListener("pointermove", handlePointerMove, { passive: true });
    window.addEventListener("pointerleave", handlePointerLeave);

    let rafId = 0;
    let t = 0;
    let lastBeatTime = 0;
    let wakePulseBlend = isWaitingForWakeWordRef.current ? 1 : 0;

    const render = () => {
      rafId = requestAnimationFrame(render);

      const dpr = Math.min(1.75, window.devicePixelRatio || 1);
      const w = canvas.clientWidth || window.innerWidth;
      const h = canvas.clientHeight || window.innerHeight;
      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
      }

      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);

      const audio = getActiveAudioTelemetry(24);
      const primary = config.primaryColor || "#00ff9d";
      const secondary = config.secondaryColor || "#00e5ff";
      const emotionColor = EMOTION_META[emotion]?.color || primary;
      const stressRatio = (latestSentiment?.stressLevel ?? 20) / 100;

      const animMult = Math.max(0.5, Math.min(2.2, config.animationSpeed || 1));
      const energyBoost = audio.bass * 1.4 + audio.mid * 0.9 + (appState === "speaking" ? 0.25 : 0);
      t += (0.012 + energyBoost * 0.025) * animMult;

      const cx = w / 2;
      const cy = h / 2;
      const scaleFactor = Math.min(w, h) / 760;

      // Emit real-time acoustic shockwave on strong vocal peaks
      const now = performance.now();
      if ((audio.bass > 0.28 || audio.mid > 0.34) && now - lastBeatTime > 260) {
        lastBeatTime = now;
        shockwavesRef.current.push({
          radius: 78 * scaleFactor,
          alpha: 0.45,
          color: audio.source === "radha" ? emotionColor : primary,
        });
        if (shockwavesRef.current.length > 5) shockwavesRef.current.shift();
      }

      // Draw expanding harmonic shockwaves
      for (let i = shockwavesRef.current.length - 1; i >= 0; i--) {
        const sw = shockwavesRef.current[i];
        sw.radius += 2.6 + audio.bass * 4;
        sw.alpha *= 0.955;
        if (sw.alpha < 0.015) {
          shockwavesRef.current.splice(i, 1);
          continue;
        }
        ctx.save();
        ctx.strokeStyle = sw.color;
        ctx.globalAlpha = sw.alpha;
        ctx.lineWidth = 1.25;
        ctx.beginPath();
        ctx.arc(cx, cy, sw.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }

      // Cursor gravity influence in perspective rotation
      const ptrOffsetX = pointerRef.current.active ? (pointerRef.current.x - cx) / Math.max(1, w) : 0;
      const ptrOffsetY = pointerRef.current.active ? (pointerRef.current.y - cy) / Math.max(1, h) : 0;

      const rotY = t * 0.55 + ptrOffsetX * 1.1;
      const rotX = Math.sin(t * 0.35) * 0.35 + ptrOffsetY * 0.9;
      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      const cosX = Math.cos(rotX);
      const sinX = Math.sin(rotX);

      // Project 3D Fibonacci synaptic constellation with acoustic harmonic deformation
      const projected: Array<{ x: number; y: number; z: number; depth: number; energy: number }> = [];
      const isAngry = emotion === "angry" || emotion === "hurt";

      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        const bin = audio.bars[i % audio.bars.length] ?? 0.06;
        const harmonic =
          Math.sin(t * (isAngry ? 3.4 : 1.6) + n.phaseOffset) * (isAngry ? 18 : 8) +
          bin * 58 * (1 + stressRatio * 0.3);
        const r = (n.baseRadius + harmonic) * scaleFactor;

        const theta = n.theta + t * n.speed * 18;
        const x0 = r * Math.sin(n.phi) * Math.cos(theta);
        const y0 = r * Math.cos(n.phi);
        const z0 = r * Math.sin(n.phi) * Math.sin(theta);

        // Rotate Y then X
        const x1 = x0 * cosY - z0 * sinY;
        const z1 = x0 * sinY + z0 * cosY;
        const y2 = y0 * cosX - z1 * sinX;
        const z2 = y0 * sinX + z1 * cosX;

        const fov = 560;
        const persp = fov / Math.max(120, fov + z2);
        projected.push({
          x: cx + x1 * persp,
          y: cy + y2 * persp,
          z: z2,
          depth: persp,
          energy: bin,
        });
      }

      // Draw synaptic neural filaments between nearby 3D nodes
      const maxLinkDist = 82 * scaleFactor;
      ctx.lineWidth = 0.85;
      for (let i = 0; i < projected.length; i++) {
        const a = projected[i];
        for (let j = i + 1; j < projected.length; j++) {
          const b = projected[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist = Math.hypot(dx, dy);
          if (dist < maxLinkDist) {
            const strength = (1 - dist / maxLinkDist) * Math.min(a.depth, b.depth);
            ctx.strokeStyle =
              audio.source === "radha" ? emotionColor : i % 3 === 0 ? secondary : primary;
            ctx.globalAlpha = Math.min(0.45, strength * (0.24 + (a.energy + b.energy) * 0.35));
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        }
      }

      // Draw glowing synaptic nodes
      for (let i = 0; i < projected.length; i++) {
        const p = projected[i];
        const radius = Math.max(1.2, (1.7 + p.energy * 3.4) * p.depth);
        ctx.fillStyle =
          ownerVerified && i % 5 === 0
            ? "#00ff9d"
            : audio.source === "radha"
            ? emotionColor
            : i % 2 === 0
            ? primary
            : secondary;
        ctx.globalAlpha = Math.min(0.92, 0.25 + p.depth * 0.45 + p.energy * 0.4);
        ctx.beginPath();
        ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
        ctx.fill();
      }

      // Smoothly blend wake-word standby pulse envelope (0 -> 1) so transitions never pop
      const targetWakeBlend = isWaitingForWakeWordRef.current ? 1 : 0;
      wakePulseBlend += (targetWakeBlend - wakePulseBlend) * 0.08;

      // Draw dynamic outer Biometric Voiceprint Spectral Ring (unique live radial signature)
      const ringRadius = 192 * scaleFactor;
      const wakeBreath = wakePulseBlend > 0.01 ? 0.5 + 0.5 * Math.sin(now / 650) : 0;
      ctx.save();
      ctx.strokeStyle = wakePulseBlend > 0.25 ? primary : ownerVerified ? primary : emotionColor;
      ctx.globalAlpha = Math.min(0.85, 0.28 + audio.mid * 0.45 + wakePulseBlend * (0.14 + wakeBreath * 0.18));
      ctx.lineWidth = 1.2 + wakePulseBlend * (0.35 + wakeBreath * 0.45);
      ctx.beginPath();
      const segs = 72;
      for (let s = 0; s <= segs; s++) {
        const angle = (s / segs) * Math.PI * 2 + t * 0.2;
        const spec = audio.bars[s % audio.bars.length] ?? 0.06;
        const wave = Math.sin(angle * 6 + t * 2) * 3 + spec * 28 * scaleFactor;
        const rx = cx + Math.cos(angle) * (ringRadius + wave);
        const ry = cy + Math.sin(angle) * (ringRadius + wave);
        if (s === 0) ctx.moveTo(rx, ry);
        else ctx.lineTo(rx, ry);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.restore();

      // Wake-Word Standby Radar Pulse Waves (radiate smoothly while Radha waits for her name)
      if (wakePulseBlend > 0.01) {
        const cycleMs = 2400;
        const baseProgress = (now % cycleMs) / cycleMs;
        const waveOffsets = [0, 0.5];

        for (let k = 0; k < waveOffsets.length; k++) {
          const p = (baseProgress + waveOffsets[k]) % 1;
          const eased = 1 - Math.pow(1 - p, 2.2);
          const pulseRadius = (132 + eased * 155) * scaleFactor;
          const alphaCurve = Math.sin(p * Math.PI) * Math.pow(1 - p, 0.65);

          ctx.save();
          ctx.strokeStyle = primary;
          ctx.globalAlpha = Math.max(0, alphaCurve * 0.42 * wakePulseBlend);
          ctx.lineWidth = Math.max(0.8, (1.8 - p * 0.9));
          ctx.beginPath();
          ctx.arc(cx, cy, pulseRadius, 0, Math.PI * 2);
          ctx.stroke();
          ctx.restore();
        }

        // Subtle rotating cardinal acoustic listening arcs outside the biometric ring
        const arcRadius = ringRadius + 16 * scaleFactor;
        const arcSpan = Math.PI / 7;
        const baseRot = now * 0.00045;
        ctx.save();
        ctx.strokeStyle = primary;
        ctx.lineCap = "round";
        ctx.lineWidth = 1.6;
        ctx.globalAlpha = (0.24 + wakeBreath * 0.34) * wakePulseBlend;
        for (let q = 0; q < 4; q++) {
          const startA = baseRot + q * (Math.PI / 2) - arcSpan / 2;
          ctx.beginPath();
          ctx.arc(cx, cy, arcRadius, startA, startA + arcSpan);
          ctx.stroke();
        }
        ctx.restore();
      }
    };

    rafId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener("pointermove", handlePointerMove);
      window.removeEventListener("pointerleave", handlePointerLeave);
    };
  }, [
    appState,
    config.animationSpeed,
    config.neuralFieldEnabled,
    config.primaryColor,
    config.secondaryColor,
    emotion,
    latestSentiment?.stressLevel,
    ownerVerified,
  ]);

  if (config.neuralFieldEnabled === false) return null;

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="absolute inset-0 w-full h-full pointer-events-none z-[1] opacity-85"
    />
  );
}
