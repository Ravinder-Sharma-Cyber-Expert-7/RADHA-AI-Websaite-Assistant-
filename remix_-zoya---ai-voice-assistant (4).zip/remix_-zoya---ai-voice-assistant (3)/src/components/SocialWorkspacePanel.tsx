import React, { useState } from "react";
import {
  Activity,
  Bell,
  CheckCircle2,
  Circle,
  Droplets,
  Instagram,
  Link2,
  Mail,
  MessageCircle,
  RefreshCw,
  Settings2,
  Sun,
  Utensils,
  Volume2,
  X,
  Moon,
} from "lucide-react";
import type { RadhaConfig } from "../services/memoryService";
import type { DailyRoutineState } from "../services/routineCareService";
import type {
  SocialWorkspaceConfig,
  SocialWorkspaceSnapshot,
} from "../services/socialWorkspaceService";
import { signInWithGoogleWorkspace } from "../services/workspaceService";

interface SocialWorkspacePanelProps {
  isOpen: boolean;
  onClose: () => void;
  config: RadhaConfig;
  socialConfig: SocialWorkspaceConfig;
  snapshot: SocialWorkspaceSnapshot;
  isRefreshing: boolean;
  onRefresh: () => void;
  onSaveSocialConfig: (next: SocialWorkspaceConfig) => void;
  onSpeakBriefing: (platform?: "all" | "instagram" | "gmail" | "facebook") => void;
  routineState: DailyRoutineState;
  onToggleRoutineTask: (task: "bathed" | "lunchDone" | "dinnerDone" | "water") => void;
}

const SocialWorkspacePanel: React.FC<SocialWorkspacePanelProps> = ({
  isOpen,
  onClose,
  config,
  socialConfig,
  snapshot,
  isRefreshing,
  onRefresh,
  onSaveSocialConfig,
  onSpeakBriefing,
  routineState,
  onToggleRoutineTask,
}) => {
  const [showSetupModal, setShowSetupModal] = useState(false);
  const [draftConfig, setDraftConfig] = useState<SocialWorkspaceConfig>(socialConfig);
  const [gmailConnecting, setGmailConnecting] = useState(false);
  const [setupMessage, setSetupMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const primary = config.primaryColor || "#00ff88";
  const accent = config.accentColor || "#00d4ff";

  const openSetup = () => {
    setDraftConfig(socialConfig);
    setSetupMessage(null);
    setShowSetupModal(true);
  };

  const handleSaveSetup = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSocialConfig(draftConfig);
    setSetupMessage("Saved! Syncing your workspace channels...");
    setTimeout(() => {
      setShowSetupModal(false);
      setSetupMessage(null);
    }, 650);
  };

  const handleConnectGmail = async () => {
    setGmailConnecting(true);
    setSetupMessage(null);
    try {
      await signInWithGoogleWorkspace();
      setSetupMessage("Gmail connected! Pulling your live inbox...");
      onRefresh();
    } catch {
      setSetupMessage("Gmail sign-in cancelled or popup blocked.");
    } finally {
      setGmailConnecting(false);
    }
  };

  const { instagram: ig, gmail: gm, facebook: fb } = snapshot;

  return (
    <>
      <aside
        className="fixed top-[62px] bottom-[84px] left-3 z-40 w-[340px] max-w-[92vw] rounded-2xl border bg-[#060911]/92 backdrop-blur-xl shadow-2xl flex flex-col overflow-hidden text-white font-mono"
        style={{
          borderColor: `${primary}40`,
          boxShadow: `0 0 36px ${primary}18`,
        }}
      >
        {/* Header */}
        <div
          className="px-3.5 py-2.5 border-b flex items-center justify-between"
          style={{ borderColor: `${primary}28`, backgroundColor: `${primary}0D` }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Activity size={14} style={{ color: primary }} />
            <div className="truncate">
              <div className="text-[11px] font-bold tracking-wider uppercase" style={{ color: primary }}>
                COMMAND & INSIGHTS
              </div>
              <div className="text-[9px] text-white/55 truncate">
                SOCIAL · WORKSPACE · DAILY CARE
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={onRefresh}
              disabled={isRefreshing}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-white/75 hover:text-white transition cursor-pointer"
              title="Refresh Insights"
            >
              <RefreshCw size={12} className={isRefreshing ? "animate-spin" : ""} />
            </button>
            <button
              type="button"
              onClick={openSetup}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 border border-white/10 text-white/75 hover:text-white transition cursor-pointer"
              title="Connect Accounts / API Keys"
            >
              <Settings2 size={12} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-red-500/20 border border-white/10 text-white/70 hover:text-red-300 transition cursor-pointer"
              title="Collapse Panel"
            >
              <X size={12} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-thin">
          {/* Quick Voice Briefing Bar */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSpeakBriefing("all")}
              className="flex-1 py-2 px-3 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1.5 text-black transition hover:brightness-110 cursor-pointer"
              style={{ backgroundColor: primary }}
            >
              <Volume2 size={13} />
              VOICE BRIEFING
            </button>
            <button
              type="button"
              onClick={openSetup}
              className="py-2 px-2.5 rounded-xl text-[10px] font-semibold border border-white/15 bg-white/5 hover:bg-white/10 text-white/85 flex items-center gap-1 transition cursor-pointer"
            >
              <Link2 size={12} style={{ color: accent }} />
              CONNECT
            </button>
          </div>

          {/* 1. Instagram Intelligence Card */}
          <section className="rounded-xl border border-white/12 bg-black/50 p-3 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <Instagram size={14} className="text-pink-400 shrink-0" />
                <span className="text-[11px] font-bold text-white truncate">
                  {ig.handle}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold ${
                    ig.mode === "live"
                      ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-300"
                      : "bg-amber-500/15 border-amber-400/35 text-amber-300"
                  }`}
                >
                  {ig.mode === "live" ? "LIVE API" : "READY / DEMO"}
                </span>
                <button
                  type="button"
                  onClick={() => onSpeakBriefing("instagram")}
                  className="p-1 rounded bg-white/5 hover:bg-white/15 text-white/70 hover:text-white cursor-pointer"
                  title="Ask Radha for Instagram Briefing"
                >
                  <Volume2 size={11} />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5 text-center">
              <div className="rounded-lg bg-white/[0.04] border border-white/10 p-2">
                <div className="text-[9px] text-white/50">FOLLOWERS</div>
                <div className="text-[13px] font-bold tabular-nums text-white mt-0.5">
                  {ig.followers.toLocaleString("en-IN")}
                </div>
              </div>
              <div className="rounded-lg bg-white/[0.04] border border-white/10 p-2">
                <div className="text-[9px] text-white/50">VIDEO VIEWS</div>
                <div className="text-[13px] font-bold tabular-nums mt-0.5" style={{ color: accent }}>
                  {ig.recentVideoViews.toLocaleString("en-IN")}
                </div>
              </div>
              <div className="rounded-lg bg-white/[0.04] border border-white/10 p-2">
                <div className="text-[9px] text-white/50">ENGAGE</div>
                <div className="text-[13px] font-bold tabular-nums mt-0.5" style={{ color: primary }}>
                  {ig.engagementRate}
                </div>
              </div>
            </div>

            <div className="text-[10px] text-white/65 flex items-center justify-between border-t border-white/10 pt-2">
              <span>Last Upload:</span>
              <span className="text-white/90 font-semibold">{ig.lastUploadAt}</span>
            </div>
            <p className="text-[10px] leading-relaxed text-white/60">{ig.summary}</p>
            {ig.error && <p className="text-[9px] text-amber-300">{ig.error}</p>}
          </section>

          {/* 2. Gmail Inbox Summary */}
          <section className="rounded-xl border border-white/12 bg-black/50 p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5">
                <Mail size={14} className="text-sky-400" />
                <span className="text-[11px] font-bold text-white">GMAIL PRIORITY</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-bold tabular-nums">
                  {gm.unreadCount}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold ${
                    gm.mode === "live"
                      ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-300"
                      : "bg-amber-500/15 border-amber-400/35 text-amber-300"
                  }`}
                >
                  {gm.mode === "live" ? "LIVE OAUTH" : "READY / DEMO"}
                </span>
                <button
                  type="button"
                  onClick={() => onSpeakBriefing("gmail")}
                  className="p-1 rounded bg-white/5 hover:bg-white/15 text-white/70 hover:text-white cursor-pointer"
                  title="Ask Radha for Gmail Briefing"
                >
                  <Volume2 size={11} />
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              {gm.messages.slice(0, 3).map((m) => (
                <div
                  key={m.id}
                  className="rounded-lg bg-white/[0.035] border border-white/8 px-2.5 py-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-semibold text-white/90 truncate">
                      {m.subject}
                    </span>
                  </div>
                  <div className="text-[9px] text-white/50 truncate mt-0.5">{m.from}</div>
                </div>
              ))}
            </div>

            {gm.mode !== "live" && (
              <button
                type="button"
                onClick={handleConnectGmail}
                disabled={gmailConnecting}
                className="w-full py-1.5 rounded-lg text-[10px] font-semibold border border-sky-400/35 bg-sky-500/15 hover:bg-sky-500/25 text-sky-200 transition cursor-pointer"
              >
                {gmailConnecting ? "Connecting Gmail..." : "Connect Live Gmail (Google OAuth)"}
              </button>
            )}
          </section>

          {/* 3. Facebook Page & Notifications */}
          <section className="rounded-xl border border-white/12 bg-black/50 p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <MessageCircle size={14} className="text-blue-400 shrink-0" />
                <span className="text-[11px] font-bold text-white truncate">FACEBOOK</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold tabular-nums">
                  {fb.unreadCount}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold ${
                    fb.mode === "live"
                      ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-300"
                      : "bg-amber-500/15 border-amber-400/35 text-amber-300"
                  }`}
                >
                  {fb.mode === "live" ? "LIVE API" : "READY / DEMO"}
                </span>
                <button
                  type="button"
                  onClick={() => onSpeakBriefing("facebook")}
                  className="p-1 rounded bg-white/5 hover:bg-white/15 text-white/70 hover:text-white cursor-pointer"
                  title="Ask Radha for Facebook Briefing"
                >
                  <Volume2 size={11} />
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              {fb.notifications.slice(0, 2).map((n) => (
                <div
                  key={n.id}
                  className="rounded-lg bg-white/[0.035] border border-white/8 px-2.5 py-1.5"
                >
                  <div className="flex items-center justify-between text-[9px] text-blue-300/90">
                    <span className="font-semibold flex items-center gap-1">
                      <Bell size={10} /> {n.sender}
                    </span>
                    <span className="text-white/45">{n.time}</span>
                  </div>
                  <p className="text-[10px] text-white/75 mt-0.5 leading-snug">{n.text}</p>
                </div>
              ))}
            </div>
          </section>

          {/* 4. Daily Routine & Anti-Parrot Care State */}
          <section className="rounded-xl border border-white/12 bg-black/50 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold uppercase tracking-wide" style={{ color: primary }}>
                BOSS DAILY CARE ({routineState.date})
              </span>
              <span className="text-[9px] text-emerald-300/80">ANTI-PARROT ON</span>
            </div>

            <div className="grid grid-cols-2 gap-1.5">
              <button
                type="button"
                onClick={() => onToggleRoutineTask("bathed")}
                className={`p-2 rounded-lg border text-left transition cursor-pointer flex items-center gap-1.5 ${
                  routineState.bathed
                    ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-200"
                    : "bg-white/[0.03] border-white/10 text-white/70 hover:bg-white/10"
                }`}
              >
                {routineState.bathed ? (
                  <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                ) : (
                  <Circle size={13} className="text-white/40 shrink-0" />
                )}
                <div className="min-w-0">
                  <div className="text-[10px] font-bold flex items-center gap-1">
                    <Sun size={10} /> Fresh-Up
                  </div>
                  <div className="text-[8px] opacity-70">4 AM – 9 AM</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onToggleRoutineTask("lunchDone")}
                className={`p-2 rounded-lg border text-left transition cursor-pointer flex items-center gap-1.5 ${
                  routineState.lunchDone
                    ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-200"
                    : "bg-white/[0.03] border-white/10 text-white/70 hover:bg-white/10"
                }`}
              >
                {routineState.lunchDone ? (
                  <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                ) : (
                  <Circle size={13} className="text-white/40 shrink-0" />
                )}
                <div className="min-w-0">
                  <div className="text-[10px] font-bold flex items-center gap-1">
                    <Utensils size={10} /> Lunch
                  </div>
                  <div className="text-[8px] opacity-70">12 PM – 2 PM</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onToggleRoutineTask("dinnerDone")}
                className={`p-2 rounded-lg border text-left transition cursor-pointer flex items-center gap-1.5 ${
                  routineState.dinnerDone
                    ? "bg-emerald-500/15 border-emerald-400/40 text-emerald-200"
                    : "bg-white/[0.03] border-white/10 text-white/70 hover:bg-white/10"
                }`}
              >
                {routineState.dinnerDone ? (
                  <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                ) : (
                  <Circle size={13} className="text-white/40 shrink-0" />
                )}
                <div className="min-w-0">
                  <div className="text-[10px] font-bold flex items-center gap-1">
                    <Moon size={10} /> Dinner
                  </div>
                  <div className="text-[8px] opacity-70">7 PM – 9 PM</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => onToggleRoutineTask("water")}
                className="p-2 rounded-lg border bg-sky-500/10 border-sky-400/30 text-sky-200 hover:bg-sky-500/20 text-left transition cursor-pointer flex items-center gap-1.5"
              >
                <Droplets size={13} className="text-sky-400 shrink-0" />
                <div className="min-w-0">
                  <div className="text-[10px] font-bold">+1 Water</div>
                  <div className="text-[8px] opacity-80">{routineState.waterCount} glasses today</div>
                </div>
              </button>
            </div>
          </section>
        </div>
      </aside>

      {/* Clean Connection Setup Modal */}
      {showSetupModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div
            className="w-full max-w-lg rounded-2xl border bg-[#080d18] text-white font-mono shadow-2xl overflow-hidden"
            style={{ borderColor: `${primary}50` }}
          >
            <div
              className="px-4 py-3 border-b flex items-center justify-between"
              style={{ borderColor: `${primary}30`, backgroundColor: `${primary}10` }}
            >
              <div className="flex items-center gap-2">
                <Link2 size={15} style={{ color: primary }} />
                <h3 className="text-xs font-bold tracking-wider uppercase" style={{ color: primary }}>
                  CONNECT SOCIAL & WORKSPACE INTEGRATIONS
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSetupModal(false)}
                className="p-1 rounded-lg hover:bg-white/10 text-white/70 hover:text-white cursor-pointer"
              >
                <X size={15} />
              </button>
            </div>

            <form onSubmit={handleSaveSetup} className="p-4 space-y-4 max-h-[75vh] overflow-y-auto">
              {/* Instagram Section */}
              <div className="space-y-2 rounded-xl border border-white/10 bg-black/40 p-3">
                <div className="text-[11px] font-bold text-pink-400 flex items-center gap-1.5">
                  <Instagram size={13} /> INSTAGRAM GRAPH API / WEBHOOK
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Handle (@ravinder_boss)"
                    value={draftConfig.instagramHandle}
                    onChange={(e) =>
                      setDraftConfig((prev) => ({ ...prev, instagramHandle: e.target.value }))
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-pink-400"
                  />
                  <input
                    type="text"
                    placeholder="IG Business Account ID"
                    value={draftConfig.instagramAccountId}
                    onChange={(e) =>
                      setDraftConfig((prev) => ({ ...prev, instagramAccountId: e.target.value }))
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-pink-400"
                  />
                </div>
                <input
                  type="password"
                  placeholder="Instagram Graph Access Token (optional)"
                  value={draftConfig.instagramAccessToken}
                  onChange={(e) =>
                    setDraftConfig((prev) => ({ ...prev, instagramAccessToken: e.target.value }))
                  }
                  className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-pink-400"
                />
                <input
                  type="url"
                  placeholder="Or Custom Webhook JSON URL (https://...)"
                  value={draftConfig.instagramWebhookUrl}
                  onChange={(e) =>
                    setDraftConfig((prev) => ({ ...prev, instagramWebhookUrl: e.target.value }))
                  }
                  className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-pink-400"
                />
              </div>

              {/* Facebook Section */}
              <div className="space-y-2 rounded-xl border border-white/10 bg-black/40 p-3">
                <div className="text-[11px] font-bold text-blue-400 flex items-center gap-1.5">
                  <MessageCircle size={13} /> FACEBOOK PAGE API / WEBHOOK
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Page Name"
                    value={draftConfig.facebookPageName}
                    onChange={(e) =>
                      setDraftConfig((prev) => ({ ...prev, facebookPageName: e.target.value }))
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-blue-400"
                  />
                  <input
                    type="text"
                    placeholder="Facebook Page ID"
                    value={draftConfig.facebookPageId}
                    onChange={(e) =>
                      setDraftConfig((prev) => ({ ...prev, facebookPageId: e.target.value }))
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-blue-400"
                  />
                </div>
                <input
                  type="password"
                  placeholder="Facebook Page Access Token (optional)"
                  value={draftConfig.facebookAccessToken}
                  onChange={(e) =>
                    setDraftConfig((prev) => ({ ...prev, facebookAccessToken: e.target.value }))
                  }
                  className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-blue-400"
                />
                <input
                  type="url"
                  placeholder="Or Custom Facebook Webhook URL (https://...)"
                  value={draftConfig.facebookWebhookUrl}
                  onChange={(e) =>
                    setDraftConfig((prev) => ({ ...prev, facebookWebhookUrl: e.target.value }))
                  }
                  className="w-full px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] text-white focus:outline-none focus:border-blue-400"
                />
              </div>

              {/* Gmail Section */}
              <div className="space-y-2 rounded-xl border border-white/10 bg-black/40 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-sky-400 flex items-center gap-1.5">
                    <Mail size={13} /> GMAIL WORKSPACE OAUTH
                  </span>
                  <button
                    type="button"
                    onClick={handleConnectGmail}
                    disabled={gmailConnecting}
                    className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-sky-500/20 border border-sky-400/40 text-sky-200 hover:bg-sky-500/30 cursor-pointer"
                  >
                    {gmailConnecting ? "Connecting..." : "Sign In with Google"}
                  </button>
                </div>
                <p className="text-[10px] text-white/55">
                  Uses Radha&apos;s secure Google Workspace OAuth to monitor important unread inbox emails live. Leave tokens blank to stay in safe Ready-to-Connect Demo mode.
                </p>
              </div>

              {setupMessage && (
                <div className="text-[11px] px-3 py-2 rounded-lg bg-emerald-500/15 border border-emerald-400/35 text-emerald-200">
                  {setupMessage}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowSetupModal(false)}
                  className="px-3.5 py-2 rounded-lg text-[11px] border border-white/15 bg-white/5 hover:bg-white/10 text-white/75 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-[11px] font-bold text-black cursor-pointer hover:brightness-110"
                  style={{ backgroundColor: primary }}
                >
                  Save & Sync
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default SocialWorkspacePanel;
