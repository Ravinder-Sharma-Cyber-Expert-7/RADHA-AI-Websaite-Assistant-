import React, { useState } from "react";
import { CheckCircle, Circle, Copy, HelpCircle, Terminal, Check, Shield, Cpu, Wifi, Key, Sparkles } from "lucide-react";

interface GuideStep {
  id: number;
  title: string;
  shortDesc: string;
  details: string[];
  tips?: string;
  command?: string;
}

interface TailsGuideProps {
  onAskQuestion?: (question: string) => void;
}

export default function TailsGuide({ onAskQuestion }: TailsGuideProps) {
  const [completedSteps, setCompletedSteps] = useState<number[]>(() => {
    const saved = localStorage.getItem("tails_completed_steps");
    return saved ? JSON.parse(saved) : [];
  });
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [activeStep, setActiveStep] = useState<number>(1);

  const steps: GuideStep[] = [
    {
      id: 1,
      title: "Download & Verify",
      shortDesc: "Get the official Tails USB image and verify its cryptographic integrity.",
      details: [
        "Go to the official Tails website (tails.net) and download the 'Tails USB image' (.img file, approx 1.3 GB).",
        "It is CRITICAL to verify the download. Tails offers an automatic web verification tool on their download page.",
        "Alternative (PGP): Download the PGP signature and use GnuPG to verify the file: 'gpg --verify tails-amd64-*.img.sig'"
      ],
      tips: "Never download Tails from any third-party source. Always use tails.net.",
      command: "gpg --keyid-format long --import tails-signing.key"
    },
    {
      id: 2,
      title: "Flash the USB Drive",
      shortDesc: "Write the Tails image onto an 8GB+ USB flash drive.",
      details: [
        "Insert a USB flash drive (minimum 8 GB capacity) into your system. Note: All data on this drive will be wiped.",
        "On Windows/macOS: Use BalenaEtcher (recommended) to write the downloaded .img file to the USB.",
        "On Linux: Use GNOME Disks or BalenaEtcher. Avoid using 'dd' unless you are an expert.",
        "Wait for the flashing and verification process to complete. Do not unplug the drive."
      ],
      tips: "If BalenaEtcher fails, try running it as Administrator (Windows) or using a different USB port."
    },
    {
      id: 3,
      title: "Boot Tails OS",
      shortDesc: "Restart your host computer and boot from the USB drive.",
      details: [
        "Shut down your computer completely.",
        "Insert the flashed Tails USB drive.",
        "Turn on the computer and immediately start tapping your system's Boot Menu Key:",
        "• PC (HP): F9 | (Dell): F12 | (Lenovo): F12 or Fn+F12 | (ASUS/Acer): F8, F12, or Esc",
        "• Mac: Press and hold the Option (Alt) key immediately after the startup chime.",
        "Select the USB drive (often labeled 'EFI Boot', 'USB Storage', or 'Linutronix') from the menu."
      ],
      tips: "If it boots into your normal OS instead, disable 'Secure Boot' or 'Fast Boot' in your BIOS/UEFI settings."
    },
    {
      id: 4,
      title: "Welcome Screen Settings",
      shortDesc: "Configure essential boot settings before launching the desktop.",
      details: [
        "When Tails starts, you will see the Welcome Screen.",
        "Set your Language, Keyboard layout, and Timezone.",
        "Click the '+' button under 'Additional Settings' (extremely important):",
        "• Set an 'Administration Password'. This is required if you want to install additional software, configure persistence, or run root commands.",
        "• Keep MAC Address Spoofing ENABLED (default) to hide your hardware identifier on public networks."
      ],
      tips: "The administration password is temporary and resets every time you shut down Tails."
    },
    {
      id: 5,
      title: "Setup Encrypted Persistence",
      shortDesc: "Create an encrypted volume on the USB to save files across reboots.",
      details: [
        "Once booted into the Tails desktop, connect to Wi-Fi or Ethernet.",
        "Go to Applications -> Tails -> Persistent Storage.",
        "Set a strong passphrase. If you lose this passphrase, your persistent data is lost forever!",
        "Choose which features to persist (e.g., Personal Data, GnuPG, Tor Browser Bookmarks, Bitcoin Wallet).",
        "Restart Tails, enter your passphrase at the Welcome Screen, and enjoy a fully persistent secure workspace."
      ],
      tips: "Everything NOT stored in the Persistent folder will be wiped completely on shutdown."
    }
  ];

  const toggleStep = (stepId: number) => {
    const updated = completedSteps.includes(stepId)
      ? completedSteps.filter((id) => id !== stepId)
      : [...completedSteps, stepId];
    setCompletedSteps(updated);
    localStorage.setItem("tails_completed_steps", JSON.stringify(updated));
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-black/40 text-white rounded-2xl p-4 overflow-y-auto border border-white/5 backdrop-blur-md">
      {/* Header Info */}
      <div className="mb-6 p-4 rounded-xl bg-violet-500/10 border border-violet-500/20">
        <div className="flex items-center gap-2 mb-2 text-violet-400">
          <Shield size={18} />
          <h2 className="font-semibold text-base">Tails OS: Amnesic Incognito Live System</h2>
        </div>
        <p className="text-xs text-white/70 leading-relaxed">
          Tails is a secure portable operating system that protects your privacy and anonymity. It runs entirely in your computer's RAM, leaving no footprint on the hard drive.
        </p>
      </div>

      {/* Progress Bar */}
      <div className="mb-6 px-1">
        <div className="flex justify-between text-xs text-white/50 mb-1">
          <span>Installation Progress</span>
          <span className="font-mono text-violet-400">
            {completedSteps.length} of {steps.length} completed
          </span>
        </div>
        <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-pink-500 transition-all duration-500"
            style={{ width: `${(completedSteps.length / steps.length) * 100}%` }}
          />
        </div>
      </div>

      {/* Step Tabs / Selector */}
      <div className="flex gap-1 overflow-x-auto pb-2 mb-4 scrollbar-thin border-b border-white/5">
        {steps.map((step) => (
          <button
            key={step.id}
            onClick={() => setActiveStep(step.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
              activeStep === step.id
                ? "bg-violet-500 text-white shadow-lg"
                : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            Step {step.id}
          </button>
        ))}
        <button
          onClick={() => setActiveStep(6)}
          className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
            activeStep === 6
              ? "bg-violet-500 text-white shadow-lg"
              : "bg-white/5 text-white/60 hover:bg-white/10"
          }`}
        >
          Troubleshooting
        </button>
      </div>

      {/* Dynamic Step Content */}
      <div className="flex-1 min-h-0">
        {activeStep <= 5 ? (
          (() => {
            const step = steps.find((s) => s.id === activeStep)!;
            const isCompleted = completedSteps.includes(step.id);
            return (
              <div className="flex flex-col h-full justify-between">
                <div>
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <span className="text-[10px] font-mono tracking-wider text-pink-400 uppercase">
                        Phase {step.id}
                      </span>
                      <h3 className="text-lg font-semibold text-white mt-0.5">{step.title}</h3>
                    </div>
                    <button
                      onClick={() => toggleStep(step.id)}
                      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-all ${
                        isCompleted
                          ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                          : "bg-white/5 text-white/60 border-white/10 hover:border-white/20"
                      }`}
                    >
                      {isCompleted ? (
                        <>
                          <Check size={12} />
                          <span>Done</span>
                        </>
                      ) : (
                        <>
                          <Circle size={12} />
                          <span>Mark Done</span>
                        </>
                      )}
                    </button>
                  </div>

                  <p className="text-xs text-white/80 mb-3 italic">{step.shortDesc}</p>

                  <div className="flex items-center gap-2 mb-4">
                    <button
                      onClick={() => onAskQuestion?.(`Tell me more about Step ${step.id}: ${step.title}. Especially regarding: ${step.shortDesc}`)}
                      className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-semibold bg-violet-500/10 hover:bg-violet-500/20 text-violet-300 border border-violet-500/20 transition-all cursor-pointer"
                    >
                      <Sparkles size={11} className="text-violet-400 animate-pulse" />
                      <span>Ask Radha about this step</span>
                    </button>
                  </div>

                  <ul className="space-y-3 mb-4">
                    {step.details.map((detail, idx) => (
                      <li key={idx} className="flex gap-2.5 items-start text-xs text-white/70 leading-relaxed">
                        <span className="w-1.5 h-1.5 rounded-full bg-violet-400 mt-1.5 shrink-0" />
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>

                  {step.command && (
                    <div className="mb-4 bg-black/60 rounded-xl p-3 border border-white/10 relative group">
                      <div className="flex justify-between items-center text-[10px] text-white/40 mb-1.5 font-mono">
                        <span className="flex items-center gap-1">
                          <Terminal size={10} />
                          Terminal Command
                        </span>
                        <button
                          onClick={() => copyToClipboard(step.command!)}
                          className="hover:text-white transition-colors flex items-center gap-1"
                        >
                          {copiedText === step.command ? (
                            <>
                              <Check size={10} className="text-emerald-400" />
                              <span>Copied</span>
                            </>
                          ) : (
                            <>
                              <Copy size={10} />
                              <span>Copy</span>
                            </>
                          )}
                        </button>
                      </div>
                      <code className="text-xs font-mono text-cyan-400 break-all select-all block pr-6">
                        {step.command}
                      </code>
                    </div>
                  )}

                  {step.tips && (
                    <div className="p-3 rounded-xl bg-pink-500/5 border border-pink-500/10 text-xs text-pink-300/90 leading-relaxed mb-4">
                      <strong>💡 Pro Tip:</strong> {step.tips}
                    </div>
                  )}
                </div>

                <div className="flex justify-between pt-4 mt-auto border-t border-white/5">
                  <button
                    disabled={activeStep === 1}
                    onClick={() => setActiveStep((prev) => prev - 1)}
                    className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white/80 hover:bg-white/10 disabled:opacity-30 disabled:pointer-events-none transition-all"
                  >
                    Previous
                  </button>
                  <button
                    onClick={() => setActiveStep((prev) => (prev === 5 ? 6 : prev + 1))}
                    className="px-3 py-1.5 rounded-lg bg-violet-500 hover:bg-violet-600 text-xs text-white font-medium shadow-lg transition-all"
                  >
                    {activeStep === 5 ? "Troubleshooting" : "Next Step"}
                  </button>
                </div>
              </div>
            );
          })()
        ) : (
          <div className="flex flex-col h-full justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <HelpCircle size={18} className="text-pink-400" />
                <h3 className="text-base font-semibold">Tails OS Troubleshooting</h3>
              </div>

              <div className="space-y-4 text-xs">
                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex flex-col justify-between gap-2">
                  <div>
                    <span className="font-medium text-pink-300 flex items-center gap-1 mb-1">
                      <Cpu size={12} />
                      1. USB is not showing up in Boot Menu
                    </span>
                    <p className="text-white/70 leading-relaxed">
                      Make sure the USB was flashed as UEFI. If you have an older motherboard, you might need to enable 'Legacy Boot' / 'CSM' support in your BIOS settings. Alternatively, flash using Rufus and choose MBR partition scheme.
                    </p>
                  </div>
                  <button
                    onClick={() => onAskQuestion?.("My Tails USB is not showing up in the Boot Menu. How can I fix this?")}
                    className="self-start flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 border border-pink-500/20 transition-all cursor-pointer"
                  >
                    <Sparkles size={10} className="text-pink-400 animate-pulse" />
                    <span>Ask Radha how to fix this</span>
                  </button>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex flex-col justify-between gap-2">
                  <div>
                    <span className="font-medium text-pink-300 flex items-center gap-1 mb-1">
                      <Wifi size={12} />
                      2. Wi-Fi connection is not working
                    </span>
                    <p className="text-white/70 leading-relaxed">
                      Tails does not include some proprietary Wi-Fi drivers. If your Wi-Fi is missing, try using an Ethernet cable, a USB Wi-Fi adapter that supports Linux out-of-the-box, or USB tethering from your smartphone.
                    </p>
                  </div>
                  <button
                    onClick={() => onAskQuestion?.("My Wi-Fi is not working in Tails OS. What proprietary driver workarounds or hardware can I use?")}
                    className="self-start flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 border border-pink-500/20 transition-all cursor-pointer"
                  >
                    <Sparkles size={10} className="text-pink-400 animate-pulse" />
                    <span>Ask Radha how to fix this</span>
                  </button>
                </div>

                <div className="p-3 bg-white/5 rounded-xl border border-white/5 flex flex-col justify-between gap-2">
                  <div>
                    <span className="font-medium text-pink-300 flex items-center gap-1 mb-1">
                      <Key size={12} />
                      3. MAC Spoofing error at Boot
                    </span>
                    <p className="text-white/70 leading-relaxed">
                      On some network cards, MAC spoofing fails. If Tails refuses to connect to the network or blocks internet, restart Tails and disable 'MAC Address Spoofing' from the Welcome screen additional settings.
                    </p>
                  </div>
                  <button
                    onClick={() => onAskQuestion?.("I get a MAC Address Spoofing error at boot in Tails. Should I disable it, and what are the security trade-offs?")}
                    className="self-start flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 border border-pink-500/20 transition-all cursor-pointer"
                  >
                    <Sparkles size={10} className="text-pink-400 animate-pulse" />
                    <span>Ask Radha how to fix this</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-start pt-4 mt-6 border-t border-white/5">
              <button
                onClick={() => setActiveStep(5)}
                className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-xs text-white/80 hover:bg-white/10 transition-all"
                  >
                Back to Steps
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
