import React, { useState } from "react";
import {
  Activity,
  Brain,
  Flame,
  HeartPulse,
  Loader2,
  Send,
  ShieldAlert,
  Sparkles,
  TrendingUp,
} from "lucide-react";
import { RadhaConfig } from "../services/memoryService";
import { BossSentimentRecord } from "../services/sentimentService";

interface BossSentimentPanelProps {
  config: RadhaConfig;
  sentiments: BossSentimentRecord[];
  latestSentiment: BossSentimentRecord | null;
  onRunDeepAnalyze: (customText?: string) => Promise<void>;
}

function getPolarityColor(polarity: BossSentimentRecord["polarity"], primary: string): string {
  switch (polarity) {
    case "positive":
      return primary;
    case "intense":
      return "#ff2a55";
    case "negative":
      return "#f97316";
    default:
      return "#00e5ff";
  }
}

export default function BossSentimentPanel({
  config,
  sentiments,
  latestSentiment,
  onRunDeepAnalyze,
}: BossSentimentPanelProps) {
  const [analyzing, setAnalyzing] = useState(false);
  const [sampleText, setSampleText] = useState("");

  const primary = config.primaryColor || "#00ff9d";
  const secondary = config.secondaryColor || "#00e5ff";

  const current: BossSentimentRecord = latestSentiment || {
    id: "baseline",
    polarity: "neutral",
    score: 12,
    stressLevel: 20,
    energyLevel: 55,
    warmthLevel: 68,
    dominantMood: "Focused & Ready",
    triggers: [],
    insight: "Jaise hi Boss kuch bolenge ya likhenge, live sentiment analysis auto-update hoga.",
    radhaGuidance: "Maintain warm, attentive, sharp Hinglish tone.",
    sourceText: "",
    createdAt: Date.now(),
  };

  const activeColor = getPolarityColor(current.polarity, primary);

  // Build SVG waveform across recent sentiment scores (-100..+100)
  const waveData = sentiments
    .slice(0, 14)
    .reverse()
    .map((s) => s.score);
  const displayWave = waveData.length >= 2 ? waveData : [10, 14, 18, current.score];
  const width = 260;
  const height = 56;
  const coords = displayWave.map((score, idx) => {
    const x = (idx / Math.max(1, displayWave.length - 1)) * width;
    // Map +100 -> y=6, 0 -> y=28, -100 -> y=50
    const y = 28 - (Math.max(-100, Math.min(100, score)) / 100) * 22;
    return { x, y };
  });
  const polyline = coords.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const lastPt = coords[coords.length - 1] || { x: width, y: 28 };

  const handleAnalyzeClick = async (custom?: string) => {
    setAnalyzing(true);
    try {
      await onRunDeepAnalyze(custom);
      if (custom) setSampleText("");
    } finally {
      setAnalyzing(false);
    }
  };

  const normalizedScorePct = Math.round(((current.score + 100) / 200) * 100);

  return (
    <div className="space-y-3 font-mono text-xs">
      {/* Live Boss Sentiment Header Card */}
      <div
        className="p-3.5 rounded-xl bg-black/60 border space-y-3"
        style={{ borderColor: `${activeColor}45`, boxShadow: `0 0 22px ${activeColor}15` }}
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-white/55">
              <Brain size={12} style={{ color: activeColor }} />
              <span>BOSS SENTIMENT ENGINE</span>
            </div>
            <div className="text-sm font-bold text-white mt-0.5">{current.dominantMood}</div>
          </div>
          <div className="text-right shrink-0">
            <div className="text-lg font-bold tabular-nums" style={{ color: activeColor }}>
              {current.score > 0 ? `+${current.score}` : current.score}
            </div>
            <div
              className="text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded inline-block"
              style={{ backgroundColor: `${activeColor}22`, color: activeColor }}
            >
              {current.polarity}
            </div>
          </div>
        </div>

        {/* Polarity Balance Scale (-100 to +100) */}
        <div className="space-y-1">
          <div className="flex justify-between text-[9px] text-white/40 uppercase">
            <span>-100 NEG</span>
            <span>0 NEUTRAL</span>
            <span>+100 POS</span>
          </div>
          <div className="relative h-2 rounded-full bg-white/10 overflow-hidden">
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/30 z-10" />
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${normalizedScorePct}%`,
                background: `linear-gradient(90deg, #ff2a55, ${secondary}, ${primary})`,
              }}
            />
          </div>
        </div>

        {/* 3 Core Emotional Telemetry Bars */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          <div className="p-2 rounded-lg bg-white/[0.03] border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-[9px] text-white/55">
              <span className="flex items-center gap-1">
                <ShieldAlert size={9} className="text-amber-400" /> STRESS
              </span>
              <span className="text-amber-300 font-bold tabular-nums">{current.stressLevel}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full bg-amber-400 transition-all duration-500"
                style={{ width: `${current.stressLevel}%` }}
              />
            </div>
          </div>

          <div className="p-2 rounded-lg bg-white/[0.03] border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-[9px] text-white/55">
              <span className="flex items-center gap-1">
                <Flame size={9} style={{ color: secondary }} /> ENERGY
              </span>
              <span className="font-bold tabular-nums" style={{ color: secondary }}>
                {current.energyLevel}%
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${current.energyLevel}%`, backgroundColor: secondary }}
              />
            </div>
          </div>

          <div className="p-2 rounded-lg bg-white/[0.03] border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-[9px] text-white/55">
              <span className="flex items-center gap-1">
                <HeartPulse size={9} style={{ color: primary }} /> WARMTH
              </span>
              <span className="font-bold tabular-nums" style={{ color: primary }}>
                {current.warmthLevel}%
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${current.warmthLevel}%`, backgroundColor: primary }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Sentiment Trend Waveform SVG */}
      <div className="p-3 rounded-xl bg-black/55 border border-white/10 space-y-2">
        <div className="flex items-center justify-between text-[10px] text-white/60 uppercase tracking-wider">
          <span className="flex items-center gap-1.5">
            <TrendingUp size={11} style={{ color: primary }} />
            SENTIMENT WAVEFORM ({sentiments.length} SAMPLES)
          </span>
          <span className="text-[9px] text-white/40">LIVE SYNC</span>
        </div>

        <div className="rounded-lg bg-[#02080b] border border-white/[0.06] px-1.5 py-1.5">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-14 overflow-visible">
            {/* Baseline 0 */}
            <line
              x1="0"
              y1="28"
              x2={width}
              y2="28"
              stroke="rgba(255,255,255,0.16)"
              strokeDasharray="3 3"
            />
            <line x1="0" y1="12" x2={width} y2="12" stroke="rgba(255,255,255,0.05)" />
            <line x1="0" y1="44" x2={width} y2="44" stroke="rgba(255,255,255,0.05)" />
            <polyline
              fill="none"
              stroke={activeColor}
              strokeWidth="1.8"
              strokeLinejoin="round"
              strokeLinecap="round"
              points={polyline}
              style={{ filter: `drop-shadow(0 0 4px ${activeColor})` }}
            />
            <circle cx={lastPt.x} cy={lastPt.y} r="3" fill={activeColor} />
            <circle cx={lastPt.x} cy={lastPt.y} r="6.5" fill={activeColor} opacity="0.25" />
          </svg>
        </div>

        {/* AI Insight + Radha Adaptive Guidance */}
        <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/10 space-y-1.5 font-sans">
          <div className="text-[11px] text-white/90 leading-snug">
            <span className="font-mono text-[10px] uppercase mr-1.5" style={{ color: activeColor }}>
              INSIGHT:
            </span>
            {current.insight}
          </div>
          <div className="text-[10.5px] text-white/60 leading-snug">
            <span className="font-mono text-[9.5px] uppercase mr-1.5" style={{ color: secondary }}>
              RADHA ADAPTATION:
            </span>
            {current.radhaGuidance}
          </div>
          {current.triggers.length > 0 && (
            <div className="flex flex-wrap gap-1 pt-0.5 font-mono">
              {current.triggers.map((t, i) => (
                <span
                  key={i}
                  className="text-[9px] px-1.5 py-0.5 rounded bg-white/10 text-white/80"
                >
                  #{t}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Deep Gemini Sentiment Scan Controls */}
      <div className="p-3 rounded-xl bg-black/55 border border-white/10 space-y-2">
        <button
          type="button"
          disabled={analyzing}
          onClick={() => handleAnalyzeClick()}
          className="w-full py-2 px-3 rounded-lg text-[11px] font-bold text-black flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer"
          style={{ background: `linear-gradient(90deg, ${primary}, ${secondary})` }}
        >
          {analyzing ? <Loader2 size={13} className="animate-spin" /> : <Sparkles size={13} />}
          <span>{analyzing ? "RUNNING DEEP SENTIMENT SCAN..." : "DEEP AI SCAN LAST CONVERSATION"}</span>
        </button>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!sampleText.trim()) return;
            handleAnalyzeClick(sampleText.trim());
          }}
          className="flex gap-1.5"
        >
          <input
            type="text"
            value={sampleText}
            onChange={(e) => setSampleText(e.target.value)}
            placeholder="Analyze custom sentence sentiment..."
            className="flex-1 min-w-0 bg-white/5 border border-white/15 rounded-lg px-2.5 py-1.5 text-[11px] text-white placeholder:text-white/35 outline-none focus:border-emerald-400"
          />
          <button
            type="submit"
            disabled={analyzing || !sampleText.trim()}
            className="px-2.5 py-1.5 rounded-lg text-black font-bold disabled:opacity-40 cursor-pointer"
            style={{ backgroundColor: primary }}
            title="Analyze Text"
          >
            <Send size={12} />
          </button>
        </form>
      </div>

      {/* Recent Boss Sentiment History */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 text-[10px] text-white/50 uppercase tracking-wider">
          <Activity size={11} style={{ color: secondary }} />
          <span>RECENT SENTIMENT LOGS</span>
        </div>
        {sentiments.length === 0 ? (
          <div className="text-center py-4 text-[11px] text-white/40 font-sans">
            Abhi koi Boss sentiment record nahi hai. Radha se baat karein — har line ka real-time sentiment yahan track hoga.
          </div>
        ) : (
          sentiments.slice(0, 10).map((item) => {
            const col = getPolarityColor(item.polarity, primary);
            return (
              <div
                key={item.id}
                className="p-2.5 rounded-lg bg-black/45 border border-white/10 space-y-1"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[10.5px] font-bold truncate" style={{ color: col }}>
                    {item.dominantMood} ({item.score > 0 ? `+${item.score}` : item.score})
                  </span>
                  <span className="text-[9px] text-white/35 shrink-0">
                    {new Date(item.createdAt).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                </div>
                {item.sourceText && (
                  <p className="text-[10.5px] text-white/75 font-sans line-clamp-2">
                    &quot;{item.sourceText}&quot;
                  </p>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
