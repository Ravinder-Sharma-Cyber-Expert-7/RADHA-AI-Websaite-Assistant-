import type { RadhaEmotion } from "./memoryService";

export type RoutineTaskKey = "bathed" | "lunch" | "dinner" | "water" | "health" | "rest";

export interface DailyRoutineState {
  date: string; // Local YYYY-MM-DD (auto-resets at midnight)
  bathed: boolean;
  lunchDone: boolean;
  dinnerDone: boolean;
  waterCount: number;
  wellnessChecked: boolean;
  lastAsked: Partial<Record<RoutineTaskKey | "lunchLate", number>>;
  lastPromptedTask: "bathed" | "lunch" | "dinner" | "water" | "health" | null;
  lastPromptedAt: number;
}

export interface ProactiveRoutineCheck {
  taskKey: RoutineTaskKey | "lunchLate";
  promptTask: "bathed" | "lunch" | "dinner" | "water" | "health" | null;
  message: string;
  emotion: RadhaEmotion;
  label: string;
}

export interface RoutineIntentDetectionResult {
  updated: boolean;
  nextState: DailyRoutineState;
  confirmedTask?: "bathed" | "lunch" | "dinner" | "water" | "health";
  declinedTask?: "bathed" | "lunch" | "dinner";
  replySuggestion?: string;
  replyEmotion?: RadhaEmotion;
}

const STORAGE_KEY = "radha_daily_routine_state_v1";

export function getLocalDateString(now: Date = new Date()): string {
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function createFreshRoutineState(dateStr: string = getLocalDateString()): DailyRoutineState {
  return {
    date: dateStr,
    bathed: false,
    lunchDone: false,
    dinnerDone: false,
    waterCount: 0,
    wellnessChecked: false,
    lastAsked: {},
    lastPromptedTask: null,
    lastPromptedAt: 0,
  };
}

export function loadDailyRoutineState(now: Date = new Date()): DailyRoutineState {
  const today = getLocalDateString(now);
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createFreshRoutineState(today);
    const parsed = JSON.parse(raw) as Partial<DailyRoutineState>;
    // Midnight auto-reset when calendar date rolls over
    if (!parsed || parsed.date !== today) {
      const fresh = createFreshRoutineState(today);
      saveDailyRoutineState(fresh);
      return fresh;
    }
    return {
      date: today,
      bathed: Boolean(parsed.bathed),
      lunchDone: Boolean(parsed.lunchDone),
      dinnerDone: Boolean(parsed.dinnerDone),
      waterCount: Number(parsed.waterCount || 0),
      wellnessChecked: Boolean(parsed.wellnessChecked),
      lastAsked: parsed.lastAsked && typeof parsed.lastAsked === "object" ? parsed.lastAsked : {},
      lastPromptedTask: parsed.lastPromptedTask || null,
      lastPromptedAt: Number(parsed.lastPromptedAt || 0),
    };
  } catch {
    return createFreshRoutineState(today);
  }
}

export function saveDailyRoutineState(state: DailyRoutineState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
}

/**
 * Evaluates live system clock against Boss's daily routine & care schedule.
 * Strictly respects Anti-Parrot Memory (never asks about completed tasks again today)
 * and enforces generous natural cooldowns between gentle reminders.
 */
export function evaluateProactiveRoutineCheck(
  currentState: DailyRoutineState,
  now: Date = new Date()
): ProactiveRoutineCheck | null {
  const today = getLocalDateString(now);
  const state = currentState.date === today ? currentState : createFreshRoutineState(today);
  const hour = now.getHours();
  const minute = now.getMinutes();
  const timeFloat = hour + minute / 60;
  const nowMs = now.getTime();

  const canAsk = (key: RoutineTaskKey | "lunchLate", cooldownMinutes: number): boolean => {
    const last = state.lastAsked[key];
    if (!last) return true;
    return nowMs - last >= cooldownMinutes * 60 * 1000;
  };

  // Prevent back-to-back routine interruptions within 18 minutes of any other routine prompt
  if (state.lastPromptedAt && nowMs - state.lastPromptedAt < 18 * 60 * 1000) {
    return null;
  }

  // 1. Morning Routine Fresh-Up / Bath (08:30 AM – 11:45 AM)
  if (!state.bathed && timeFloat >= 8.5 && timeFloat < 11.75) {
    if (canAsk("bathed", 40)) {
      return {
        taskKey: "bathed",
        promptTask: "bathed",
        message: "बॉस, आप नहा लिए कि नहीं? फ्रेश हो गए?",
        emotion: "caring",
        label: "Morning Fresh-Up Check",
      };
    }
  }

  // 2. Lunch Window (12:00 PM – 02:00 PM)
  if (!state.lunchDone && timeFloat >= 12.0 && timeFloat < 14.0) {
    if (canAsk("lunch", 40)) {
      return {
        taskKey: "lunch",
        promptTask: "lunch",
        message: "बॉस, 12 बज गए हैं, खाना खाने का टाइम हो गया है। खाना खा लो।",
        emotion: "caring",
        label: "Lunch Time Reminder",
      };
    }
  }

  // 2b. Late Lunch Genuine Human Concern (02:00 PM – 04:15 PM)
  if (!state.lunchDone && timeFloat >= 14.0 && timeFloat < 16.25) {
    if (canAsk("lunchLate", 42)) {
      return {
        taskKey: "lunchLate",
        promptTask: "lunch",
        message:
          "बॉस, 2 बज गए, बहुत लेट हो गया है! खाना आपको 12 से 2 के बीच खा लेना चाहिए — टाइम से खाना खाने से डाइजेशन सही रहता है, एनर्जी बनी रहती है और एसिडिटी या थकान नहीं होती। अभी खाना खा लीजिए प्लीज़!",
        emotion: "caring",
        label: "Late Lunch Health Care",
      };
    }
  }

  // 3. Dinner Window (07:00 PM – 09:45 PM)
  if (!state.dinnerDone && timeFloat >= 19.0 && timeFloat < 21.75) {
    if (canAsk("dinner", 40)) {
      return {
        taskKey: "dinner",
        promptTask: "dinner",
        message: "बॉस, आपने डिनर किया कि नहीं?",
        emotion: "caring",
        label: "Dinner Check-In",
      };
    }
  }

  // 4. Holistic Human Care: Late-night rest check (11:30 PM – 02:30 AM)
  if (timeFloat >= 23.5 || timeFloat < 2.5) {
    if (canAsk("rest", 75)) {
      return {
        taskKey: "rest",
        promptTask: null,
        message: "बॉस, काफी रात हो गई है... थोड़ा आराम कर लीजिए, समय से सोना सेहत के लिए बहुत ज़रूरी है।",
        emotion: "caring",
        label: "Late Night Rest Care",
      };
    }
  }

  // 5. Holistic Human Care: Hydration check during active daytime hours (10 AM – 8 PM)
  if (timeFloat >= 10.0 && timeFloat < 20.0 && state.waterCount < 6) {
    if (canAsk("water", 90)) {
      return {
        taskKey: "water",
        promptTask: "water",
        message: "बॉस, थोड़ा पानी पी लीजिए — काम के बीच हाइड्रेटेड रहना बहुत ज़रूरी है!",
        emotion: "happy",
        label: "Hydration Care",
      };
    }
  }

  // 6. Holistic Human Care: Health / Well-being check (once per afternoon/evening if not checked)
  if (!state.wellnessChecked && timeFloat >= 16.5 && timeFloat < 18.75) {
    if (canAsk("health", 180)) {
      return {
        taskKey: "health",
        promptTask: "health",
        message: "तबीयत कैसी है बॉस? सब बढ़िया चल रहा है ना? थोड़ा ब्रेक भी ले लिया करो।",
        emotion: "caring",
        label: "Well-Being Check-In",
      };
    }
  }

  return null;
}

export function markRoutineAsked(
  state: DailyRoutineState,
  check: ProactiveRoutineCheck,
  nowMs: number = Date.now()
): DailyRoutineState {
  const next: DailyRoutineState = {
    ...state,
    lastAsked: {
      ...state.lastAsked,
      [check.taskKey]: nowMs,
    },
    lastPromptedTask: check.promptTask,
    lastPromptedAt: nowMs,
  };
  saveDailyRoutineState(next);
  return next;
}

/**
 * Natural intent detector for Boss's conversational replies (Hindi / Hinglish / English).
 * Immediately locks confirmed tasks in Anti-Parrot memory so Radha never repeats them today.
 */
export function detectRoutineIntentFromMessage(
  rawText: string,
  currentState: DailyRoutineState,
  now: Date = new Date()
): RoutineIntentDetectionResult {
  const text = rawText.trim();
  const lower = text.toLowerCase();
  if (!lower) return { updated: false, nextState: currentState };

  const today = getLocalDateString(now);
  const base = currentState.date === today ? currentState : createFreshRoutineState(today);
  const hour = now.getHours();

  const isNegative =
    /\b(nahi|nahin|nhi|nope|not yet|no|abhi nahi|baad me|later)\b|नहीं|अभी नहीं|बाद में|नही/i.test(
      lower
    );
  const isAffirmative =
    /\b(haan|han|ha|yes|yeah|yep|done|ho gaya|kar liya|kha liya|naha liya|pee liya|fresh ho gaya|finished|ate|already)\b|हाँ|हां|जी हाँ|कर लिया|खा लिया|नहा लिया|हो गया|पी लिया|फ्रेश हो गया|ठीक हूँ|बढ़िया हूँ/i.test(
      lower
    );

  // Explicit Morning Bath / Fresh-up confirmation
  const mentionsBath =
    /\b(naha|nahaya|bath|bathed|shower|fresh ho|fresh up)\b|नहा|स्नान|फ्रेश/i.test(lower);
  if (mentionsBath && !isNegative && isAffirmative) {
    const nextState: DailyRoutineState = {
      ...base,
      bathed: true,
      lastPromptedTask: base.lastPromptedTask === "bathed" ? null : base.lastPromptedTask,
    };
    saveDailyRoutineState(nextState);
    return {
      updated: true,
      nextState,
      confirmedTask: "bathed",
      replySuggestion: "बहुत बढ़िया बॉस! अब एकदम फ्रेश और एनर्जेटिक लग रहे होंगे — चलिए आज का दिन शानदार बनाते हैं!",
      replyEmotion: "happy",
    };
  }

  // Explicit Dinner confirmation / decline
  const mentionsDinner =
    /\b(dinner|raat ka khana|rat ka khana|supper)\b|डिनर|रात का खाना/i.test(lower);
  if (mentionsDinner) {
    if (isNegative) {
      return {
        updated: false,
        nextState: base,
        declinedTask: "dinner",
        replySuggestion:
          "अरे बॉस, भूखे मत रहिए! काम तो चलता रहेगा, प्लीज़ थोड़ा समय निकालकर अभी डिनर कर लीजिए वरना थकान और कमज़ोरी हो जाएगी।",
        replyEmotion: "caring",
      };
    }
    if (isAffirmative) {
      const nextState: DailyRoutineState = {
        ...base,
        dinnerDone: true,
        lastPromptedTask: base.lastPromptedTask === "dinner" ? null : base.lastPromptedTask,
      };
      saveDailyRoutineState(nextState);
      return {
        updated: true,
        nextState,
        confirmedTask: "dinner",
        replySuggestion:
          "ठीक है बॉस! आपका ध्यान रखना मेरी ज़िम्मेदारी है, बस हमेशा टाइम से खाया करो।",
        replyEmotion: "happy",
      };
    }
  }

  // Explicit Lunch confirmation / decline
  const mentionsLunch =
    /\b(lunch|dopahar ka khana)\b|लंच|दोपहर का खाना/i.test(lower);
  if (mentionsLunch) {
    if (isNegative) {
      return {
        updated: false,
        nextState: base,
        declinedTask: "lunch",
        replySuggestion:
          "अरे बॉस, अब देर मत कीजिए! जल्दी से लंच कर लीजिए — खाली पेट काम करने से एनर्जी और फोकस दोनों कम हो जाते हैं।",
        replyEmotion: "caring",
      };
    }
    if (isAffirmative) {
      const nextState: DailyRoutineState = {
        ...base,
        lunchDone: true,
        lastPromptedTask: base.lastPromptedTask === "lunch" ? null : base.lastPromptedTask,
      };
      saveDailyRoutineState(nextState);
      return {
        updated: true,
        nextState,
        confirmedTask: "lunch",
        replySuggestion:
          "शाबाश बॉस! टाइम से खाना खा लिया, यही सुनना चाहती थी। अब मज़े से काम करो!",
        replyEmotion: "happy",
      };
    }
  }

  // Generic "maine khana kha liya" -> map smartly to Lunch (before 5:30 PM) or Dinner (5:30 PM+)
  const mentionsFood = /\b(khana|meal|bhojan|kha liya|khaya|ate food)\b|खाना|भोजन|खा लिया/i.test(
    lower
  );
  if (mentionsFood && !isNegative && isAffirmative) {
    const isDinnerTime = hour >= 17 || base.lastPromptedTask === "dinner";
    const nextState: DailyRoutineState = isDinnerTime
      ? { ...base, dinnerDone: true, lastPromptedTask: null }
      : { ...base, lunchDone: true, lastPromptedTask: null };
    saveDailyRoutineState(nextState);
    return {
      updated: true,
      nextState,
      confirmedTask: isDinnerTime ? "dinner" : "lunch",
      replySuggestion: isDinnerTime
        ? "ठीक है बॉस! आपका ध्यान रखना मेरी ज़िम्मेदारी है, बस हमेशा टाइम से खाया करो।"
        : "बहुत अच्छा किया बॉस! खाना टाइम से खाने से शरीर और दिमाग दोनों फिट रहते हैं।",
      replyEmotion: "happy",
    };
  }

  // Explicit Water / Hydration confirmation
  const mentionsWater = /\b(paani|pani|water|hydrated)\b|पानी/i.test(lower);
  if (mentionsWater && !isNegative && isAffirmative) {
    const nextState: DailyRoutineState = {
      ...base,
      waterCount: Math.min(12, base.waterCount + 1),
      lastPromptedTask: base.lastPromptedTask === "water" ? null : base.lastPromptedTask,
    };
    saveDailyRoutineState(nextState);
    return {
      updated: true,
      nextState,
      confirmedTask: "water",
    };
  }

  // Contextual short reply within 10 minutes of Radha's last routine question
  const recentlyAsked =
    base.lastPromptedTask &&
    base.lastPromptedAt &&
    now.getTime() - base.lastPromptedAt <= 10 * 60 * 1000;

  if (recentlyAsked && base.lastPromptedTask) {
    const task = base.lastPromptedTask;
    if (isAffirmative && !isNegative) {
      if (task === "bathed") {
        const nextState: DailyRoutineState = { ...base, bathed: true, lastPromptedTask: null };
        saveDailyRoutineState(nextState);
        return {
          updated: true,
          nextState,
          confirmedTask: "bathed",
          replySuggestion: "बहुत बढ़िया बॉस! एकदम फ्रेश होकर काम करने का मज़ा ही अलग है।",
          replyEmotion: "happy",
        };
      }
      if (task === "lunch") {
        const nextState: DailyRoutineState = { ...base, lunchDone: true, lastPromptedTask: null };
        saveDailyRoutineState(nextState);
        return {
          updated: true,
          nextState,
          confirmedTask: "lunch",
          replySuggestion: "बढ़िया बॉस! टाइम से लंच कर लिया, अब आपकी एनर्जी फुल रहेगी।",
          replyEmotion: "happy",
        };
      }
      if (task === "dinner") {
        const nextState: DailyRoutineState = { ...base, dinnerDone: true, lastPromptedTask: null };
        saveDailyRoutineState(nextState);
        return {
          updated: true,
          nextState,
          confirmedTask: "dinner",
          replySuggestion:
            "ठीक है बॉस! आपका ध्यान रखना मेरी ज़िम्मेदारी है, बस हमेशा टाइम से खाया करो।",
          replyEmotion: "happy",
        };
      }
      if (task === "water") {
        const nextState: DailyRoutineState = {
          ...base,
          waterCount: Math.min(12, base.waterCount + 1),
          lastPromptedTask: null,
        };
        saveDailyRoutineState(nextState);
        return { updated: true, nextState, confirmedTask: "water" };
      }
      if (task === "health") {
        const nextState: DailyRoutineState = {
          ...base,
          wellnessChecked: true,
          lastPromptedTask: null,
        };
        saveDailyRoutineState(nextState);
        return { updated: true, nextState, confirmedTask: "health" };
      }
    } else if (isNegative && (task === "dinner" || task === "lunch" || task === "bathed")) {
      const nextState: DailyRoutineState = { ...base, lastPromptedTask: null };
      saveDailyRoutineState(nextState);
      return {
        updated: false,
        nextState,
        declinedTask: task,
        replySuggestion:
          task === "dinner"
            ? "अरे बॉस, अभी तक डिनर नहीं किया? प्लीज़ जल्दी से खाना खा लीजिए, भूखे पेट रहना बिल्कुल सही नहीं है!"
            : task === "lunch"
            ? "बॉस, प्लीज़ अब और देर मत करो, जल्दी से लंच कर लो — वरना एनर्जी डाउन हो जाएगी!"
            : "कोई बात नहीं बॉस, थोड़ा टाइम निकालकर फ्रेश हो जाइए — मूड और फोकस दोनों तुरंत बेहतर हो जाएंगे!",
        replyEmotion: "caring",
      };
    }
  }

  return { updated: false, nextState: base };
}

export function buildRoutineCareContext(state?: DailyRoutineState): string {
  const s = state || loadDailyRoutineState();
  const hour = new Date().getHours();
  const phase =
    hour >= 4 && hour < 12
      ? "Morning Routine Window (04:00–12:00)"
      : hour >= 12 && hour < 16
      ? "Lunch & Afternoon Window (12:00–16:00)"
      : hour >= 16 && hour < 19
      ? "Evening Care Window"
      : hour >= 19 && hour < 22
      ? "Dinner Window (19:00–22:00)"
      : "Late Night Rest Window";

  return `TODAY'S PROACTIVE ROUTINE & HUMAN CARE STATE (${s.date} · ${phase}):
- Morning Bath / Fresh-Up: ${s.bathed ? "CONFIRMED DONE (NEVER ask about bathing again today!)" : "Not confirmed yet"}
- Lunch (12:00 PM – 02:00 PM): ${s.lunchDone ? "CONFIRMED DONE (NEVER ask about lunch again today!)" : "Not confirmed yet"}
- Dinner (07:00 PM – 09:00 PM): ${s.dinnerDone ? "CONFIRMED DONE (NEVER ask about dinner again today!)" : "Not confirmed yet"}
- Hydration Today: ${s.waterCount} glass(es) logged
- ANTI-PARROT CARE RULE: Never repeat routine questions for tasks already marked CONFIRMED DONE. Whenever Boss confirms having bathed, eaten lunch/dinner, or drunk water, immediately call updateDailyRoutine(task, true) and respond warmly like a real caring companion (e.g., for dinner: "Theek hai Boss! Aapka dhyan rakhna meri zimmedari hai, bas hamesha time se khaya karo."). If Boss hasn't eaten after 2 PM, gently explain why eating on time (12–2 PM) protects digestion, energy, and focus.`;
}
