import { motion } from "motion/react";
import {
  DEFAULT_RADHA_CONFIG,
  EMOTION_META,
  RadhaConfig,
  RadhaEmotion,
} from "../services/memoryService";

type VisualizerState = "idle" | "listening" | "processing" | "speaking";

interface VisualizerProps {
  state: VisualizerState;
  emotion?: RadhaEmotion;
  config?: RadhaConfig;
}

export default function Visualizer({
  state,
  emotion = "neutral",
  config = DEFAULT_RADHA_CONFIG,
}: VisualizerProps) {
  const speedMultiplier = Math.max(0.3, Math.min(3, config.animationSpeed || 1));
  const scaleMultiplier = Math.max(0.65, Math.min(1.35, config.visualizerScale || 1));
  const glowIntensity = Math.max(0.2, Math.min(1.6, config.glowIntensity || 1.0));
  const styleMode = config.visualizerStyle || "hud";

  const getRingAnimation = (index: number, reverse: boolean = false) => {
    const baseSpeed =
      emotion === "angry"
        ? 1.1
        : emotion === "excited"
        ? 1.4
        : state === "listening"
        ? 2.8
        : state === "processing"
        ? 1.4
        : state === "speaking"
        ? 1.9
        : 14;
    const duration = Math.max(0.6, (baseSpeed + index * 2) / speedMultiplier);
    return {
      rotate: reverse ? [-360, 0] : [0, 360],
      transition: { duration, repeat: Infinity, ease: "linear" as const },
    };
  };

  const getPulseAnimation = () => {
    if (emotion === "angry") {
      return {
        scale: [1, 1.07, 0.96, 1.05, 1],
        opacity: [0.85, 1, 0.85, 1, 0.85],
        transition: { duration: 0.4 / speedMultiplier, repeat: Infinity, ease: "easeInOut" as const },
      };
    }
    if (state === "speaking") {
      return {
        scale: [1, 1.05, 0.98, 1.03, 1],
        opacity: [0.85, 1, 0.85, 1, 0.85],
        transition: { duration: 0.45 / speedMultiplier, repeat: Infinity, ease: "easeInOut" as const },
      };
    }
    if (state === "listening") {
      return {
        scale: [1, 1.03, 1],
        opacity: [0.75, 1, 0.75],
        transition: { duration: 0.95 / speedMultiplier, repeat: Infinity, ease: "easeInOut" as const },
      };
    }
    if (state === "processing") {
      return {
        scale: [0.97, 1.03, 0.97],
        opacity: [0.65, 0.95, 0.65],
        transition: { duration: 0.75 / speedMultiplier, repeat: Infinity, ease: "linear" as const },
      };
    }
    return {
      scale: [1, 1.015, 1],
      opacity: [0.55, 0.75, 0.55],
      transition: { duration: 3.5 / speedMultiplier, repeat: Infinity, ease: "easeInOut" as const },
    };
  };

  const emotionInfo = EMOTION_META[emotion] || EMOTION_META.neutral;

  const getActiveColor = () => {
    if (emotion !== "neutral") {
      return emotionInfo.color;
    }
    switch (state) {
      case "listening":
        return config.primaryColor || "#00ff9d";
      case "processing":
        return "#00e5ff";
      case "speaking":
        return config.secondaryColor || "#00e5ff";
      default:
        return config.primaryColor || "#00ff9d";
    }
  };

  const activeColor = getActiveColor();
  const displayName = (config.assistantName || "RADHA").toUpperCase();

  return (
    <div className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none">
      <div
        className="relative flex items-center justify-center w-[min(82vw,470px)] h-[min(82vw,470px)] transition-transform duration-500"
        style={{ transform: `scale(${scaleMultiplier})` }}
      >
        {/* Ambient Cyber Aura */}
        <motion.div
          animate={getPulseAnimation()}
          className="absolute w-[74%] h-[74%] rounded-full blur-[95px] transition-colors duration-500"
          style={{
            backgroundColor: activeColor,
            opacity: Math.min(0.42, 0.19 * glowIntensity),
          }}
        />

        {/* Tactical Hacker HUD Style */}
        {styleMode === "hud" && (
          <>
            {/* Crosshair axis lines */}
            <div
              className="absolute w-[108%] h-px opacity-20"
              style={{
                background: `linear-gradient(90deg, transparent, ${activeColor}, transparent)`,
              }}
            />
            <div
              className="absolute h-[108%] w-px opacity-20"
              style={{
                background: `linear-gradient(180deg, transparent, ${activeColor}, transparent)`,
              }}
            />

            {/* Corner targeting brackets */}
            <div
              className="absolute top-[7%] left-[7%] w-5 h-5 border-t-2 border-l-2 opacity-45"
              style={{ borderColor: activeColor }}
            />
            <div
              className="absolute top-[7%] right-[7%] w-5 h-5 border-t-2 border-r-2 opacity-45"
              style={{ borderColor: activeColor }}
            />
            <div
              className="absolute bottom-[7%] left-[7%] w-5 h-5 border-b-2 border-l-2 opacity-45"
              style={{ borderColor: activeColor }}
            />
            <div
              className="absolute bottom-[7%] right-[7%] w-5 h-5 border-b-2 border-r-2 opacity-45"
              style={{ borderColor: activeColor }}
            />

            {/* Radar sweep beam */}
            <motion.div
              animate={{
                rotate: [0, 360],
                transition: { duration: Math.max(2, 6 / speedMultiplier), repeat: Infinity, ease: "linear" },
              }}
              className="absolute w-[84%] h-[84%] rounded-full opacity-25"
              style={{
                background: `conic-gradient(from 0deg, ${activeColor}66 0deg, transparent 55deg, transparent 360deg)`,
              }}
            />

            {/* Outer degree ring SVG */}
            <motion.svg
              animate={getRingAnimation(4, false)}
              viewBox="0 0 200 200"
              className="absolute w-[100%] h-[100%] opacity-35"
            >
              <circle
                cx="100"
                cy="100"
                r="95"
                fill="none"
                stroke={activeColor}
                strokeWidth="0.7"
                strokeDasharray="3 5"
              />
              <circle
                cx="100"
                cy="100"
                r="88"
                fill="none"
                stroke={activeColor}
                strokeWidth="1.2"
                strokeDasharray="18 28"
              />
            </motion.svg>

            <motion.div
              animate={getRingAnimation(3, true)}
              className="absolute w-[82%] h-[82%] rounded-full border border-dotted opacity-40 transition-colors duration-500"
              style={{ borderColor: activeColor }}
            />
            <motion.div
              animate={getRingAnimation(2, false)}
              className="absolute w-[69%] h-[69%] rounded-full border-2 border-t-transparent border-b-transparent opacity-60 transition-colors duration-500"
              style={{
                borderLeftColor: activeColor,
                borderRightColor: config.secondaryColor || activeColor,
              }}
            />
            <motion.div
              animate={getRingAnimation(1, true)}
              className="absolute w-[56%] h-[56%] rounded-full border-2 border-dashed opacity-60 transition-colors duration-500"
              style={{ borderColor: activeColor }}
            />
            <motion.div
              animate={getRingAnimation(0, false)}
              className="absolute w-[45%] h-[45%] rounded-full border-[3px] border-dotted opacity-80 transition-colors duration-500"
              style={{ borderColor: activeColor }}
            />
          </>
        )}

        {/* Orb Style */}
        {styleMode === "orb" && (
          <>
            <motion.div
              animate={{
                scale: [1, 1.12, 1],
                rotate: [0, 180, 360],
                transition: { duration: 7 / speedMultiplier, repeat: Infinity, ease: "easeInOut" },
              }}
              className="absolute w-[72%] h-[72%] rounded-full blur-2xl opacity-35"
              style={{
                background: `conic-gradient(from 0deg, ${activeColor}, ${config.secondaryColor}, transparent, ${activeColor})`,
              }}
            />
            <motion.div
              animate={getRingAnimation(1, false)}
              className="absolute w-[58%] h-[58%] rounded-full border opacity-55"
              style={{
                borderColor: activeColor,
                boxShadow: `0 0 ${32 * glowIntensity}px ${activeColor}`,
              }}
            />
          </>
        )}

        {/* Neon Dual-Ring Style */}
        {styleMode === "neon" && (
          <>
            <motion.div
              animate={getRingAnimation(2, false)}
              className="absolute w-[82%] h-[82%] rounded-full border-2 opacity-70"
              style={{
                borderColor: activeColor,
                borderTopColor: "transparent",
                boxShadow: `0 0 ${28 * glowIntensity}px ${activeColor}`,
              }}
            />
            <motion.div
              animate={getRingAnimation(1, true)}
              className="absolute w-[62%] h-[62%] rounded-full border-2 opacity-80"
              style={{
                borderColor: config.secondaryColor,
                borderBottomColor: "transparent",
                boxShadow: `0 0 ${22 * glowIntensity}px ${config.secondaryColor}`,
              }}
            />
          </>
        )}

        {/* Minimal Style */}
        {styleMode === "minimal" && (
          <motion.div
            animate={getPulseAnimation()}
            className="absolute w-[52%] h-[52%] rounded-full border opacity-45"
            style={{ borderColor: activeColor }}
          />
        )}

        {/* Core Circle */}
        <motion.div
          animate={getPulseAnimation()}
          className="relative w-[36%] h-[36%] rounded-full border-2 bg-[#02080a]/75 backdrop-blur-md flex flex-col items-center justify-center overflow-hidden transition-colors duration-500"
          style={{
            borderColor: activeColor,
            boxShadow: `0 0 ${42 * glowIntensity}px ${activeColor}99, inset 0 0 ${28 * glowIntensity}px ${activeColor}66`,
          }}
        >
          {config.avatarImageUrl ? (
            <img
              src={config.avatarImageUrl}
              alt={displayName}
              className="w-full h-full object-cover opacity-90"
            />
          ) : (
            <div className="flex flex-col items-center justify-center px-3 text-center">
              <div
                className="text-[9px] font-mono tracking-[0.28em] opacity-70 uppercase mb-0.5"
                style={{ color: activeColor }}
              >
                {state === "speaking"
                  ? "TX // VOICE"
                  : state === "listening"
                  ? "RX // LIVE"
                  : state === "processing"
                  ? "EXEC // AI"
                  : "CORE // RDY"}
              </div>
              <div
                className="font-mono font-bold tracking-[0.22em] text-lg sm:text-2xl md:text-3xl text-white select-none"
                style={{
                  textShadow: `0 0 14px ${activeColor}, 0 0 28px ${activeColor}`,
                }}
              >
                {displayName}
              </div>
              {config.showEmotionBadge && (
                <div
                  className="mt-1.5 text-[10.5px] font-mono font-medium tracking-wider opacity-90 transition-colors duration-300"
                  style={{ color: activeColor }}
                >
                  {emotionInfo.hindiLabel} · {emotionInfo.label}
                </div>
              )}
            </div>
          )}
        </motion.div>

        {/* Emotion caption below avatar when custom avatar image is used */}
        {config.avatarImageUrl && config.showEmotionBadge && (
          <div
            className="absolute bottom-[22%] text-xs font-mono font-medium tracking-wider transition-colors duration-300 bg-black/60 px-2.5 py-0.5 rounded border"
            style={{
              color: activeColor,
              borderColor: `${activeColor}45`,
              textShadow: `0 0 12px ${activeColor}`,
            }}
          >
            {displayName} · {emotionInfo.hindiLabel}
          </div>
        )}
      </div>
    </div>
  );
}
