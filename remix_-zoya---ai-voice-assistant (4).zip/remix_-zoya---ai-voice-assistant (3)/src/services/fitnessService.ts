import { initializeApp, getApps } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

export type BiologicalSource = "disconnected" | "google-fit" | "apple-health" | "webhook";

export interface BiologicalStatusData {
  source: BiologicalSource;
  connectedLabel: string;
  steps: number | null;
  heartRateBpm: number | null;
  caloriesKcal: number | null;
  activeMinutes: number | null;
  distanceKm: number | null;
  lastSyncedAt: number | null;
  recordedDate: string | null;
}

const BIO_STORAGE_KEY = "radha_biological_status_v1";

// Strict in-memory Google Fit OAuth token (never written to localStorage/sessionStorage)
let cachedFitAccessToken: string | null = null;
let cachedFitAccountEmail: string | null = null;

export const EMPTY_BIOLOGICAL_STATUS: BiologicalStatusData = {
  source: "disconnected",
  connectedLabel: "Not Connected",
  steps: null,
  heartRateBpm: null,
  caloriesKcal: null,
  activeMinutes: null,
  distanceKm: null,
  lastSyncedAt: null,
  recordedDate: null,
};

export function loadBiologicalStatus(): BiologicalStatusData {
  try {
    const raw = localStorage.getItem(BIO_STORAGE_KEY);
    if (!raw) return { ...EMPTY_BIOLOGICAL_STATUS };
    const parsed = JSON.parse(raw) as BiologicalStatusData;
    if (parsed && parsed.source && parsed.source !== "disconnected") {
      return {
        ...EMPTY_BIOLOGICAL_STATUS,
        ...parsed,
      };
    }
  } catch {}
  return { ...EMPTY_BIOLOGICAL_STATUS };
}

export function saveBiologicalStatus(data: BiologicalStatusData): void {
  try {
    localStorage.setItem(BIO_STORAGE_KEY, JSON.stringify(data));
  } catch {}
}

export function clearBiologicalStatus(): BiologicalStatusData {
  cachedFitAccessToken = null;
  cachedFitAccountEmail = null;
  try {
    localStorage.removeItem(BIO_STORAGE_KEY);
  } catch {}
  return { ...EMPTY_BIOLOGICAL_STATUS };
}

export function hasActiveGoogleFitToken(): boolean {
  return Boolean(cachedFitAccessToken);
}

/**
 * 100% REAL Google Fit OAuth + REST API Aggregate Query (Steps, Heart Rate, Calories, Move Minutes, Distance).
 * Uses Firebase Auth GoogleAuthProvider popup with official Fitness read scopes.
 */
export async function connectAndSyncGoogleFit(): Promise<BiologicalStatusData> {
  const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
  const auth = getAuth(app);

  if (!cachedFitAccessToken) {
    const provider = new GoogleAuthProvider();
    provider.addScope("https://www.googleapis.com/auth/fitness.activity.read");
    provider.addScope("https://www.googleapis.com/auth/fitness.heart_rate.read");
    provider.addScope("https://www.googleapis.com/auth/fitness.location.read");

    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Could not obtain Google Fit OAuth token.");
    }
    cachedFitAccessToken = credential.accessToken;
    cachedFitAccountEmail = result.user?.email || "Google Fit";
  }

  return fetchGoogleFitTodayMetrics(cachedFitAccessToken, cachedFitAccountEmail || "Google Fit");
}

export async function refreshGoogleFitMetrics(): Promise<BiologicalStatusData> {
  if (!cachedFitAccessToken) {
    return connectAndSyncGoogleFit();
  }
  return fetchGoogleFitTodayMetrics(cachedFitAccessToken, cachedFitAccountEmail || "Google Fit");
}

async function fetchGoogleFitTodayMetrics(
  token: string,
  accountLabel: string
): Promise<BiologicalStatusData> {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const startTimeMillis = startOfDay.getTime();
  const endTimeMillis = Date.now();

  const res = await fetch("https://www.googleapis.com/fitness/v1/users/me/dataset:aggregate", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      aggregateBy: [
        { dataTypeName: "com.google.step_count.delta" },
        { dataTypeName: "com.google.heart_rate.bpm" },
        { dataTypeName: "com.google.calories.expended" },
        { dataTypeName: "com.google.active_minutes" },
        { dataTypeName: "com.google.distance.delta" },
      ],
      bucketByTime: { durationMillis: Math.max(60_000, endTimeMillis - startTimeMillis) },
      startTimeMillis,
      endTimeMillis,
    }),
  });

  if (res.status === 401 || res.status === 403) {
    cachedFitAccessToken = null;
    throw new Error("Google Fit authorization expired or Fitness API scope not granted.");
  }
  if (!res.ok) {
    throw new Error(`Google Fit API returned status ${res.status}`);
  }

  const json = await res.json();
  let steps = 0;
  let hasSteps = false;
  let hrSum = 0;
  let hrCount = 0;
  let calories = 0;
  let hasCalories = false;
  let activeMinutes = 0;
  let hasActiveMinutes = false;
  let distanceMeters = 0;
  let hasDistance = false;

  const buckets: any[] = Array.isArray(json?.bucket) ? json.bucket : [];
  for (const bucket of buckets) {
    const datasets: any[] = Array.isArray(bucket?.dataset) ? bucket.dataset : [];
    for (const ds of datasets) {
      const dsId = String(ds?.dataSourceId || "").toLowerCase();
      const points: any[] = Array.isArray(ds?.point) ? ds.point : [];
      for (const pt of points) {
        const valObj = pt?.value?.[0];
        if (!valObj) continue;
        const num =
          typeof valObj.intVal === "number"
            ? valObj.intVal
            : typeof valObj.fpVal === "number"
            ? valObj.fpVal
            : null;
        if (num === null) continue;

        if (dsId.includes("step_count")) {
          steps += num;
          hasSteps = true;
        } else if (dsId.includes("heart_rate")) {
          hrSum += num;
          hrCount += 1;
        } else if (dsId.includes("calories")) {
          calories += num;
          hasCalories = true;
        } else if (dsId.includes("active_minutes")) {
          activeMinutes += num;
          hasActiveMinutes = true;
        } else if (dsId.includes("distance")) {
          distanceMeters += num;
          hasDistance = true;
        }
      }
    }
  }

  const data: BiologicalStatusData = {
    source: "google-fit",
    connectedLabel: `Google Fit (${accountLabel})`,
    steps: hasSteps ? Math.round(steps) : 0,
    heartRateBpm: hrCount > 0 ? Math.round(hrSum / hrCount) : null,
    caloriesKcal: hasCalories ? Math.round(calories) : null,
    activeMinutes: hasActiveMinutes ? Math.round(activeMinutes) : null,
    distanceKm: hasDistance ? Number((distanceMeters / 1000).toFixed(2)) : null,
    lastSyncedAt: Date.now(),
    recordedDate: startOfDay.toISOString().slice(0, 10),
  };

  saveBiologicalStatus(data);
  return data;
}

/**
 * 100% REAL Apple Health Parser:
 * Supports Apple Health `export.xml` (iPhone Health App -> Export All Health Data)
 * AND JSON exports from Apple Health / Health Auto Export / iOS Shortcuts.
 */
export async function parseAppleHealthFile(file: File): Promise<BiologicalStatusData> {
  // Cap very large exports safely to tail/head chunks if needed (Apple Health XML can be big)
  const MAX_READ_BYTES = 12 * 1024 * 1024; // 12 MB
  const slice = file.size > MAX_READ_BYTES ? file.slice(file.size - MAX_READ_BYTES) : file;
  const text = await slice.text();

  const lowerName = file.name.toLowerCase();
  if (lowerName.endsWith(".json") || text.trim().startsWith("{") || text.trim().startsWith("[")) {
    return parseAppleHealthJson(text, file.name);
  }

  // Parse Apple Health XML <Record type="HKQuantityTypeIdentifier..." startDate="YYYY-MM-DD..." value="..." />
  const recordRegex =
    /<Record[^>]*type="(HKQuantityTypeIdentifier(?:StepCount|HeartRate|ActiveEnergyBurned|AppleExerciseTime|DistanceWalkingRunning))"[^>]*>/gi;

  interface DayBucket {
    steps: number;
    hrValues: number[];
    calories: number;
    activeMinutes: number;
    distanceKm: number;
  }

  const byDate = new Map<string, DayBucket>();
  const ensureBucket = (dateKey: string): DayBucket => {
    let b = byDate.get(dateKey);
    if (!b) {
      b = { steps: 0, hrValues: [], calories: 0, activeMinutes: 0, distanceKm: 0 };
      byDate.set(dateKey, b);
    }
    return b;
  };

  let match: RegExpExecArray | null;
  let totalParsed = 0;

  while ((match = recordRegex.exec(text)) !== null) {
    const tag = match[0];
    const type = match[1];
    const valMatch = tag.match(/value="([\d.]+)"/i);
    const dateMatch = tag.match(/startDate="(\d{4}-\d{2}-\d{2})/i);
    if (!valMatch || !dateMatch) continue;

    const val = Number(valMatch[1]);
    if (Number.isNaN(val)) continue;
    const dateKey = dateMatch[1];
    const bucket = ensureBucket(dateKey);
    totalParsed += 1;

    if (type === "HKQuantityTypeIdentifierStepCount") {
      bucket.steps += val;
    } else if (type === "HKQuantityTypeIdentifierHeartRate") {
      bucket.hrValues.push(val);
    } else if (type === "HKQuantityTypeIdentifierActiveEnergyBurned") {
      bucket.calories += val;
    } else if (type === "HKQuantityTypeIdentifierAppleExerciseTime") {
      bucket.activeMinutes += val;
    } else if (type === "HKQuantityTypeIdentifierDistanceWalkingRunning") {
      const unitMatch = tag.match(/unit="([^"]+)"/i);
      const unit = (unitMatch?.[1] || "km").toLowerCase();
      bucket.distanceKm += unit === "mi" ? val * 1.60934 : unit === "m" ? val / 1000 : val;
    }
  }

  if (totalParsed === 0 || byDate.size === 0) {
    throw new Error(
      "No Apple Health activity records found. Upload Apple Health export.xml or Health Auto Export .json."
    );
  }

  // Pick the most recent real recorded date in the export
  const latestDate = Array.from(byDate.keys()).sort().pop()!;
  const latest = byDate.get(latestDate)!;
  const avgHr =
    latest.hrValues.length > 0
      ? Math.round(latest.hrValues.reduce((a, b) => a + b, 0) / latest.hrValues.length)
      : null;

  const data: BiologicalStatusData = {
    source: "apple-health",
    connectedLabel: `Apple Health (${latestDate})`,
    steps: Math.round(latest.steps),
    heartRateBpm: avgHr,
    caloriesKcal: latest.calories > 0 ? Math.round(latest.calories) : null,
    activeMinutes: latest.activeMinutes > 0 ? Math.round(latest.activeMinutes) : null,
    distanceKm: latest.distanceKm > 0 ? Number(latest.distanceKm.toFixed(2)) : null,
    lastSyncedAt: Date.now(),
    recordedDate: latestDate,
  };

  saveBiologicalStatus(data);
  return data;
}

function parseAppleHealthJson(rawText: string, fileName: string): BiologicalStatusData {
  const parsed = JSON.parse(rawText);

  // Supports both flat JSON ({ steps, heartRate, calories, activeMinutes, distanceKm })
  // and Health Auto Export format ({ data: { metrics: [{ name, data: [{ qty, Avg }] }] } })
  let steps: number | null = null;
  let heartRateBpm: number | null = null;
  let caloriesKcal: number | null = null;
  let activeMinutes: number | null = null;
  let distanceKm: number | null = null;

  if (Array.isArray(parsed?.data?.metrics)) {
    for (const metric of parsed.data.metrics) {
      const name = String(metric?.name || "").toLowerCase();
      const entries: any[] = Array.isArray(metric?.data) ? metric.data : [];
      if (entries.length === 0) continue;
      if (name.includes("step")) {
        steps = Math.round(entries.reduce((acc, e) => acc + Number(e?.qty || 0), 0));
      } else if (name.includes("heart_rate")) {
        const vals = entries
          .map((e) => Number(e?.Avg ?? e?.qty ?? 0))
          .filter((n) => n > 0);
        if (vals.length > 0) {
          heartRateBpm = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
        }
      } else if (name.includes("active_energy") || name.includes("calorie")) {
        caloriesKcal = Math.round(entries.reduce((acc, e) => acc + Number(e?.qty || 0), 0));
      } else if (name.includes("exercise_time") || name.includes("active_minutes")) {
        activeMinutes = Math.round(entries.reduce((acc, e) => acc + Number(e?.qty || 0), 0));
      } else if (name.includes("walking_running_distance") || name.includes("distance")) {
        distanceKm = Number(
          entries.reduce((acc, e) => acc + Number(e?.qty || 0), 0).toFixed(2)
        );
      }
    }
  } else {
    const obj = Array.isArray(parsed) ? parsed[parsed.length - 1] || {} : parsed;
    if (typeof obj.steps === "number") steps = Math.round(obj.steps);
    if (typeof obj.heartRateBpm === "number" || typeof obj.heartRate === "number") {
      heartRateBpm = Math.round(Number(obj.heartRateBpm ?? obj.heartRate));
    }
    if (typeof obj.caloriesKcal === "number" || typeof obj.calories === "number") {
      caloriesKcal = Math.round(Number(obj.caloriesKcal ?? obj.calories));
    }
    if (typeof obj.activeMinutes === "number") activeMinutes = Math.round(obj.activeMinutes);
    if (typeof obj.distanceKm === "number") distanceKm = Number(obj.distanceKm.toFixed(2));
  }

  if (
    steps === null &&
    heartRateBpm === null &&
    caloriesKcal === null &&
    activeMinutes === null
  ) {
    throw new Error("JSON file does not contain recognized Apple Health or Fitness metrics.");
  }

  const data: BiologicalStatusData = {
    source: "apple-health",
    connectedLabel: `Apple Health (${fileName.slice(0, 22)})`,
    steps,
    heartRateBpm,
    caloriesKcal,
    activeMinutes,
    distanceKm,
    lastSyncedAt: Date.now(),
    recordedDate: new Date().toISOString().slice(0, 10),
  };

  saveBiologicalStatus(data);
  return data;
}

/**
 * Real HTTPS Health Webhook Sync via server proxy (for iOS Shortcuts / Health Auto Export endpoints).
 */
export async function syncHealthWebhookUrl(url: string): Promise<BiologicalStatusData> {
  const res = await fetch("/api/health/sync", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url: url.trim() }),
  });
  const payload = await res.json();
  if (!res.ok) {
    throw new Error(payload?.error || `Health webhook sync failed (${res.status})`);
  }

  const data: BiologicalStatusData = {
    source: "webhook",
    connectedLabel: payload.connectedLabel || "Live Health Feed",
    steps: typeof payload.steps === "number" ? Math.round(payload.steps) : null,
    heartRateBpm:
      typeof payload.heartRateBpm === "number" ? Math.round(payload.heartRateBpm) : null,
    caloriesKcal:
      typeof payload.caloriesKcal === "number" ? Math.round(payload.caloriesKcal) : null,
    activeMinutes:
      typeof payload.activeMinutes === "number" ? Math.round(payload.activeMinutes) : null,
    distanceKm:
      typeof payload.distanceKm === "number" ? Number(payload.distanceKm.toFixed(2)) : null,
    lastSyncedAt: Date.now(),
    recordedDate: new Date().toISOString().slice(0, 10),
  };

  saveBiologicalStatus(data);
  return data;
}
