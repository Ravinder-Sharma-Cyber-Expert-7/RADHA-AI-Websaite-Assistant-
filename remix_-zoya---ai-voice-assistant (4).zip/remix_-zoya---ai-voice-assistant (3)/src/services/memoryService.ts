import {
  BossSentimentRecord,
  loadLocalSentiments,
  saveLocalSentiments,
} from "./sentimentService";

export type RadhaEmotion =
  | "neutral"
  | "happy"
  | "angry"
  | "sad"
  | "caring"
  | "playful"
  | "excited"
  | "hurt";

export interface ChatMessage {
  id: string;
  sender: "user" | "radha";
  text: string;
  emotion?: RadhaEmotion;
  timestamp?: number;
}

export interface MemoryItem {
  id: string;
  content: string;
  category: string;
  createdAt: number;
}

export interface ReminderItem {
  id: string;
  title: string;
  triggerAt: number;
  completed: boolean;
  createdAt: number;
}

export interface TaskItem {
  id: string;
  title: string;
  priority: "low" | "medium" | "high";
  completed: boolean;
  createdAt: number;
}

export interface MoodEntry {
  id: string;
  emotion: RadhaEmotion;
  note: string;
  createdAt: number;
}

export interface BondingState {
  xp: number;
  level: number;
  interactions: number;
}

export interface WebSearchResult {
  answer: string;
  sources: Array<{ title: string; uri: string }>;
}

export interface UploadedVaultFile {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  summary: string;
  contentPreview?: string;
  sha256?: string;
  uploadedAt: number;
}

export interface SystemEventItem {
  id: string;
  category: string;
  summary: string;
  createdAt: number;
}

export interface SessionContextState {
  sessionId: string;
  summary: string;
  activeTopic: string;
  lastEmotion: RadhaEmotion;
  lastUserMessage: string;
  lastRadhaMessage: string;
  openLoop: string;
  messageCount: number;
  updatedAt: number;
}

export type VisualizerStyle = "hud" | "orb" | "neon" | "minimal";
export type VoicePersona = "Kore" | "Zephyr" | "Puck" | "Charon" | "Fenrir" | "Aoede";
export type EmotionIntensity = "normal" | "high" | "ultra";
export type CompactChatPosition = "right" | "left" | "hidden";
export type PreferredLanguage = "hi-IN" | "en-IN" | "auto";

export interface BiometricSecurityProfile {
  calibrated: boolean;
  biometricHash: string;
  geometrySignature: string;
  antiSpoofScore: number;
  parallaxDelta: number;
  angleSnapshots: string[]; // [front, left, right, tilt] compressed thumbnails
  calibratedAt: number;
  requireLivenessCheck: boolean;
}

export interface RadhaConfig {
  // Identity & Origin
  assistantName: string;
  creatorName: string;
  creationDate: string;
  creationDay: string;
  extraInstructions: string;
  preferredLanguage: PreferredLanguage;

  // Owner Biometric Profile & Personal Details
  ownerPhotoUrl: string;
  ownerFullName: string;
  ownerNickname: string;
  ownerRole: string;
  ownerCity: string;
  ownerBio: string;
  faceRecognitionEnabled: boolean;
  biometricProfile?: BiometricSecurityProfile;

  // System, Wake-Word & Anti-Drop Voice Control
  wakeWordText: string;
  autoSleepOnBye: boolean;
  autoReconnectVoice: boolean;
  voiceWaveformEnabled: boolean;
  neuralFieldEnabled: boolean;

  // Emotions & Voice
  voiceName: VoicePersona;
  voicePitch: number;
  emotionIntensity: EmotionIntensity;
  scoldAngerReaction: boolean;
  detectLaughAndCry: boolean;
  showEmotionBadge: boolean;
  inactivityCheckinEnabled: boolean;
  inactivitySeconds: number;

  // Look & Design Customization
  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  backgroundImageUrl: string;
  backgroundOverlayOpacity: number;
  avatarImageUrl: string;
  visualizerStyle: VisualizerStyle;
  visualizerScale: number;
  animationSpeed: number;
  glowIntensity: number;
  compactChatPosition: CompactChatPosition;
  compactChatWidth: number;
  showTelemetryPanel: boolean;
  fontScale: number;
}

export const DEFAULT_RADHA_CONFIG: RadhaConfig = {
  assistantName: "Radha",
  creatorName: "Ravindra Boss",
  creationDate: "1 May 2024",
  creationDay: "Wednesday (बुधवार)",
  extraInstructions: "",
  preferredLanguage: "hi-IN",

  ownerPhotoUrl: "",
  ownerFullName: "Ravindra Sharma",
  ownerNickname: "Ravindra Boss",
  ownerRole: "Creator & Cyber Expert",
  ownerCity: "India",
  ownerBio: "",
  faceRecognitionEnabled: true,
  biometricProfile: undefined,

  wakeWordText: "राधा",
  autoSleepOnBye: true,
  autoReconnectVoice: true,
  voiceWaveformEnabled: false,
  neuralFieldEnabled: true,

  voiceName: "Kore",
  voicePitch: 1.0,
  emotionIntensity: "ultra",
  scoldAngerReaction: true,
  detectLaughAndCry: true,
  showEmotionBadge: true,
  inactivityCheckinEnabled: false,
  inactivitySeconds: 120,

  // Khatarnak Hacker-Style Default Palette (100% customizable in Admin Panel @123hack)
  primaryColor: "#00ff9d",
  secondaryColor: "#00e5ff",
  backgroundColor: "#020608",
  backgroundImageUrl: "",
  backgroundOverlayOpacity: 0.65,
  avatarImageUrl: "",
  visualizerStyle: "hud",
  visualizerScale: 1,
  animationSpeed: 1.1,
  glowIntensity: 1.0,
  compactChatPosition: "right",
  compactChatWidth: 300,
  showTelemetryPanel: true,
  fontScale: 1,
};

export const EMOTION_META: Record<
  RadhaEmotion,
  { label: string; hindiLabel: string; color: string; glow: string }
> = {
  neutral: {
    label: "Tactical Calm",
    hindiLabel: "शांत",
    color: "#00ff9d",
    glow: "rgba(0, 255, 157, 0.75)",
  },
  happy: {
    label: "Happy",
    hindiLabel: "खुश",
    color: "#fbbf24",
    glow: "rgba(251, 191, 36, 0.75)",
  },
  angry: {
    label: "Angry",
    hindiLabel: "गुस्सा",
    color: "#ff2a55",
    glow: "rgba(255, 42, 85, 0.85)",
  },
  hurt: {
    label: "Upset",
    hindiLabel: "नाराज़",
    color: "#f97316",
    glow: "rgba(249, 115, 22, 0.8)",
  },
  sad: {
    label: "Sad",
    hindiLabel: "उदास",
    color: "#60a5fa",
    glow: "rgba(96, 165, 250, 0.75)",
  },
  caring: {
    label: "Caring",
    hindiLabel: "फ़िक्रमंद",
    color: "#00e5ff",
    glow: "rgba(0, 229, 255, 0.75)",
  },
  playful: {
    label: "Playful",
    hindiLabel: "मस्तीखोर",
    color: "#ec4899",
    glow: "rgba(236, 72, 153, 0.8)",
  },
  excited: {
    label: "Excited",
    hindiLabel: "उत्साहित",
    color: "#a855f7",
    glow: "rgba(168, 85, 247, 0.85)",
  },
};

export function getBondingRank(level: number): string {
  if (level >= 15) return "Soul-Link Supreme";
  if (level >= 10) return "Cyber Partner Elite";
  if (level >= 6) return "Deep Trust Sync";
  if (level >= 3) return "Close Companion";
  return "Neural Bond Active";
}

const CONFIG_STORAGE_KEY = "radha_admin_config_v2";
const MEMORIES_STORAGE_KEY = "radha_long_term_memories_v1";
const HISTORY_STORAGE_KEY = "radha_chat_history";
const SESSION_CONTEXT_STORAGE_KEY = "radha_session_context_blob_v1";

export function createDefaultSessionContext(): SessionContextState {
  return {
    sessionId: `sess-${Date.now()}`,
    summary: "",
    activeTopic: "",
    lastEmotion: "neutral",
    lastUserMessage: "",
    lastRadhaMessage: "",
    openLoop: "",
    messageCount: 0,
    updatedAt: 0,
  };
}

export function loadLocalSessionContext(): SessionContextState {
  try {
    const raw = localStorage.getItem(SESSION_CONTEXT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === "object") {
        return { ...createDefaultSessionContext(), ...parsed };
      }
    }
  } catch (e) {
    console.warn("Could not load local session context blob:", e);
  }
  return createDefaultSessionContext();
}

export function saveLocalSessionContext(state: SessionContextState): void {
  try {
    localStorage.setItem(SESSION_CONTEXT_STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Could not save local session context blob:", e);
  }
}

export function updateSessionContextFromMessage(
  prev: SessionContextState,
  msg: ChatMessage,
  allMessages: ChatMessage[],
  currentEmotion: RadhaEmotion
): SessionContextState {
  const nextUser = msg.sender === "user" ? msg.text : prev.lastUserMessage;
  const nextRadha = msg.sender === "radha" ? msg.text : prev.lastRadhaMessage;
  const recentSnippet = allMessages
    .slice(-4)
    .map((m) => `${m.sender === "user" ? "Boss" : "Radha"}: ${m.text.slice(0, 90)}`)
    .join(" | ");

  const fallbackTopic =
    prev.activeTopic ||
    (msg.sender === "user" ? msg.text.slice(0, 70) : nextUser.slice(0, 70)) ||
    "General conversation";

  const nextSummary =
    prev.summary && prev.summary.length > 20 && allMessages.length - prev.messageCount < 2
      ? prev.summary
      : prev.summary
      ? `${prev.summary} Latest exchange: ${recentSnippet}`.slice(0, 480)
      : `Recent exchange: ${recentSnippet}`.slice(0, 480);

  return {
    sessionId: prev.sessionId || `sess-${Date.now()}`,
    summary: nextSummary,
    activeTopic: fallbackTopic,
    lastEmotion: msg.emotion || currentEmotion || prev.lastEmotion || "neutral",
    lastUserMessage: nextUser.slice(0, 260),
    lastRadhaMessage: nextRadha.slice(0, 260),
    openLoop: prev.openLoop || "",
    messageCount: allMessages.length,
    updatedAt: Date.now(),
  };
}

export function buildSessionContextSummary(
  sessionContext?: SessionContextState | null
): string {
  const ctx = sessionContext || loadLocalSessionContext();
  if (
    !ctx ||
    (!ctx.summary && !ctx.lastUserMessage && !ctx.lastRadhaMessage && !ctx.activeTopic)
  ) {
    return "Fresh session — no prior conversation state recorded yet.";
  }

  const lines: string[] = [];
  if (ctx.summary) lines.push(`- Rolling Summary: ${ctx.summary}`);
  if (ctx.activeTopic) lines.push(`- Active Topic: ${ctx.activeTopic}`);
  if (ctx.openLoop) lines.push(`- Ongoing / Unresolved Thread: ${ctx.openLoop}`);
  if (ctx.lastEmotion && ctx.lastEmotion !== "neutral") {
    lines.push(`- Last Emotional State: ${ctx.lastEmotion}`);
  }
  if (ctx.lastUserMessage) {
    lines.push(`- Last User Turn: "${ctx.lastUserMessage}"`);
  }
  if (ctx.lastRadhaMessage) {
    lines.push(`- Last Radha Turn: "${ctx.lastRadhaMessage}"`);
  }
  if (ctx.updatedAt > 0) {
    lines.push(
      `- Last Active: ${new Date(ctx.updatedAt).toLocaleString()} (${ctx.messageCount} turns saved)`
    );
  }
  return lines.join("\n");
}

export function loadLocalConfig(): RadhaConfig {
  try {
    const raw = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (raw) {
      return { ...DEFAULT_RADHA_CONFIG, ...JSON.parse(raw) };
    }
  } catch (e) {
    console.warn("Could not load local config:", e);
  }
  return { ...DEFAULT_RADHA_CONFIG };
}

export function saveLocalConfig(config: RadhaConfig): void {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.warn("Could not save local config:", e);
  }
}

export function loadLocalMemories(): MemoryItem[] {
  try {
    const raw = localStorage.getItem(MEMORIES_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return [];
}

export function saveLocalMemories(memories: MemoryItem[]): void {
  try {
    localStorage.setItem(MEMORIES_STORAGE_KEY, JSON.stringify(memories));
  } catch (e) {}
}

export function loadLocalMessages(): ChatMessage[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return [];
}

export function saveLocalMessages(messages: ChatMessage[]): void {
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(messages.slice(-150)));
  } catch (e) {}
}

export function detectVisualExperienceIntent(
  text: string,
  sender: "user" | "radha"
): { effect: "cry" | "rose" | "food_thali" | "clear"; caption?: string } | null {
  const lower = text.toLowerCase().trim();
  if (!lower) return null;

  // Dismiss / clear overlay intent
  if (
    sender === "user" &&
    /(अब मत रो|मत रो राधा|आंसू पोंछ|आँसू पोंछ|रोक दो|थाली हटा|गुलाब हटा|स्टॉप क्राइंग|stop crying|clear screen|remove overlay|hata do)/i.test(
      lower
    )
  ) {
    return { effect: "clear" };
  }

  // Realistic crying / teardrops intent
  if (
    /(रो के दिखा|रो कर दिखा|थोड़ा रो|थोड[ा़] रो|रोने वाली फीलिंग|रोने का इमोशन|आंसू गिर|आँसू गिर|रो रही हूँ|रो रही हूं|सच में रो|ro ke dikha|ro kar dikha|thoda ro|rone wali feeling|show me crying|cry for me|crying emotion)/i.test(
      lower
    )
  ) {
    return {
      effect: "cry",
      caption: "राधा सच में भावुक हो गई है... आँसू बह रहे हैं।",
    };
  }

  // Realistic red rose gift intent ("I love you" or rose request)
  if (
    /(आई लव यू|आइ लव यू|लव यू राधा|i love you|love you radha|love you too|गुलाब का फूल|गुलाब दो|गुलाब दिखा|ये रहा आपके लिए गुलाब|आपके लिए गुलाब|give me a rose|show me a rose|rose for you|gulab de do|gulab dikha)/i.test(
      lower
    )
  ) {
    return {
      effect: "rose",
      caption: "आई लव यू टू, बॉस! ये रहा आपके लिए प्यार भरा गुलाब।",
    };
  }

  // Realistic Royal Indian Thali food intent
  if (
    /(खाने की थाली|खाना लाओ|खाना दे दो|खाना खिला|थाली लाओ|थाली निकाल|थाली दिखा|भूख लगी|बहुत भूख|भूखा हूँ|भूखा हूं|लंच लगा|डिनर लगा|khane ki thali|khana lao|khana de do|khana khila|thali lao|thali nikal|bhookh lagi|bhukh lagi|hungry.*food|serve food|indian thali)/i.test(
      lower
    )
  ) {
    return {
      effect: "food_thali",
      caption: "लीजिए बॉस, गरमा-गरम शाही थाली तैयार है — पहले अच्छे से खाना खा लीजिए!",
    };
  }

  return null;
}

/**
 * High-precision emotion detector — ONLY triggers non-neutral emotions on unmistakable emotional cues.
 * Eliminates false random angry/excited spikes during normal everyday Hindi conversation.
 */
export function detectEmotionFromText(
  text: string,
  sender: "user" | "radha"
): RadhaEmotion | null {
  const lower = text.toLowerCase().trim();
  if (!lower || lower.length < 3) return null;

  if (sender === "user") {
    // Only trigger angry when Boss genuinely scolds/insults Radha directly
    if (
      /(चुप रहो|बकवास बंद|दिमाग खराब मत|तुम पागल हो|तुम बेवकूफ हो|गधी|शट अप|shut up|you are stupid|you idiot|chup raho|bakwas band|badtameez|बदतमीज़|तुम्हें तमीज नहीं|get lost|बिल्कुल बेकार हो)/i.test(
        lower
      )
    ) {
      return "angry";
    }
    // Genuine crying / sadness / distress
    if (
      /(रो के दिखा|रो कर दिखा|थोड़ा रो|रोने वाली फीलिंग|बहुत रो रहा|रो रहा हूँ|रो रही हूँ|बहुत उदास हूँ|दिल टूट गया|बहुत दुखी हूँ|i am crying|i feel depressed|feeling lonely|bahut udaas|dil toot gaya|bahut pareshan hoon|बहुत परेशान हूँ)/i.test(
        lower
      )
    ) {
      return /(रो के दिखा|रो कर दिखा|थोड़ा रो|रोने वाली फीलिंग|show me crying|cry for me)/i.test(lower)
        ? "sad"
        : "caring";
    }
    // Genuine love / apology / affection
    if (
      /(आई लव यू|i love you|love you radha|सॉरी राधा|माफ़ कर दो|माफ कर दो|sorry radha|मान जाओ|नाराज़ मत हो|naraz mat ho|तुम बहुत प्यारी हो)/i.test(
        lower
      )
    ) {
      return "happy";
    }
    // Genuine laughter / big joy
    if (
      /(हाहाहा|हीहीही|hahaha|hehehe|बहुत खुश हूँ|मज़ा आ गया आज|party karte hain|woohoo|bahut khush hoon)/i.test(
        lower
      )
    ) {
      return "happy";
    }
    // Explicit playful request
    if (
      /(कोई जोक सुनाओ|चुटकुला सुनाओ|मज़ाक करो|tell me a joke|chutkula sunao|masti karte hain)/i.test(
        lower
      )
    ) {
      return "playful";
    }
    return null;
  }

  // Radha's own reply emotion — only match unmistakable emotional statements
  if (
    /(मैं नाराज़ हूँ|मैं नाराज हूँ|मुझ पर गुस्सा|डांट रहे हैं|चिल्ला रहे हैं|मुझसे बात मत कीजिए|मैं कट्टी हूँ|main naraz hoon|daant rahe ho|mat baat kijiye)/i.test(
      lower
    )
  ) {
    return /(बुरा लगा|दिल दुखा|hurt|bura laga|नाराज़ हूँ|naraz hoon)/i.test(lower)
      ? "hurt"
      : "angry";
  }
  if (
    /(आँसू आ गए|आंसू आ गए|मैं सच में रो रही|मेरा दिल बहुत उदास|रोने का मन|aansu aa gaye|ro rahi hoon)/i.test(
      lower
    )
  ) {
    return "sad";
  }
  if (
    /(टेंशन मत लीजिए मैं हूँ ना|परेशान मत होइए|आपका पूरा ख्याल रखूँगी|tension mat lijiye main hoon na|pareshan mat hoiye)/i.test(
      lower
    )
  ) {
    return "caring";
  }
  if (
    /(आई लव यू टू|i love you too|ये रहा आपके लिए गुलाब|हाहाहा|hahaha|बहुत खुशी हुई|दिल खुश हो गया)/i.test(
      lower
    )
  ) {
    return "happy";
  }
  if (
    /(ज़बरदस्त जीत|बहुत बड़ी बधाई|क्या कमाल कर दिया बॉस|shabaash boss|superb achievement)/i.test(
      lower
    )
  ) {
    return "excited";
  }
  return null;
}

export async function fetchPersistentState(): Promise<{
  messages: ChatMessage[];
  memories: MemoryItem[];
  config: RadhaConfig;
  reminders: ReminderItem[];
  tasks: TaskItem[];
  moods: MoodEntry[];
  sentiments: BossSentimentRecord[];
  bonding: BondingState;
  sessionContext: SessionContextState;
  uploadedFiles: UploadedVaultFile[];
  systemEvents: SystemEventItem[];
}> {
  const localSessionCtx = loadLocalSessionContext();
  const localSentiments = loadLocalSentiments();
  try {
    const res = await fetch("/api/state");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const localCfg = loadLocalConfig();
    const mergedConfig: RadhaConfig = {
      ...DEFAULT_RADHA_CONFIG,
      ...(data.settings || {}),
      ...localCfg,
    };
    const serverMessages: ChatMessage[] = Array.isArray(data.messages) ? data.messages : [];
    const localMessages = loadLocalMessages();
    const finalMessages = serverMessages.length > 0 ? serverMessages : localMessages;

    const serverMemories: MemoryItem[] = Array.isArray(data.memories) ? data.memories : [];
    const localMemories = loadLocalMemories();
    const finalMemories = serverMemories.length > 0 ? serverMemories : localMemories;

    const serverSentiments: BossSentimentRecord[] = Array.isArray(data.sentiments) ? data.sentiments : [];
    const finalSentiments = serverSentiments.length > 0 ? serverSentiments : localSentiments;

    const serverSessionCtx: SessionContextState | null =
      data.sessionContext && typeof data.sessionContext === "object"
        ? { ...createDefaultSessionContext(), ...data.sessionContext }
        : null;

    let finalSessionCtx: SessionContextState =
      serverSessionCtx && serverSessionCtx.updatedAt >= localSessionCtx.updatedAt
        ? serverSessionCtx
        : localSessionCtx;

    // If neither blob existed yet but persisted messages exist, bootstrap the session context immediately
    if (finalSessionCtx.updatedAt === 0 && finalMessages.length > 0) {
      const lastMsg = finalMessages[finalMessages.length - 1];
      const lastUser = [...finalMessages].reverse().find((m) => m.sender === "user");
      const lastRadha = [...finalMessages].reverse().find((m) => m.sender === "radha");
      finalSessionCtx = updateSessionContextFromMessage(
        {
          ...finalSessionCtx,
          lastUserMessage: lastUser?.text || "",
          lastRadhaMessage: lastRadha?.text || "",
        },
        lastMsg,
        finalMessages,
        lastMsg.emotion || "neutral"
      );
    }

    saveLocalConfig(mergedConfig);
    saveLocalMemories(finalMemories);
    saveLocalMessages(finalMessages);
    saveLocalSessionContext(finalSessionCtx);
    saveLocalSentiments(finalSentiments);

    return {
      messages: finalMessages,
      memories: finalMemories,
      config: mergedConfig,
      reminders: Array.isArray(data.reminders) ? data.reminders : [],
      tasks: Array.isArray(data.tasks) ? data.tasks : [],
      moods: Array.isArray(data.moods) ? data.moods : [],
      sentiments: finalSentiments,
      bonding: data.bonding || { xp: 120, level: 2, interactions: 0 },
      sessionContext: finalSessionCtx,
      uploadedFiles: Array.isArray(data.uploadedFiles) ? data.uploadedFiles : [],
      systemEvents: Array.isArray(data.systemEvents) ? data.systemEvents : [],
    };
  } catch (err) {
    console.warn("Falling back to local persistent storage:", err);
    return {
      messages: loadLocalMessages(),
      memories: loadLocalMemories(),
      config: loadLocalConfig(),
      reminders: [],
      tasks: [],
      moods: [],
      sentiments: localSentiments,
      bonding: { xp: 120, level: 2, interactions: 0 },
      sessionContext: localSessionCtx,
      uploadedFiles: [],
      systemEvents: [],
    };
  }
}

export async function persistSessionContext(state: SessionContextState): Promise<void> {
  saveLocalSessionContext(state);
  try {
    await fetch("/api/session-context", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(state),
    });
  } catch (e) {}
}

export async function refreshSessionContextSummary(
  recentMessages: ChatMessage[],
  currentState: SessionContextState
): Promise<SessionContextState> {
  if (recentMessages.length < 2) return currentState;
  try {
    const res = await fetch("/api/memory/session-summary", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recentMessages: recentMessages.slice(-14),
        previousState: currentState,
      }),
    });
    if (!res.ok) return currentState;
    const data = await res.json();
    if (data.sessionContext && typeof data.sessionContext === "object") {
      const merged: SessionContextState = {
        ...currentState,
        ...data.sessionContext,
        updatedAt: Date.now(),
      };
      saveLocalSessionContext(merged);
      return merged;
    }
    return currentState;
  } catch (e) {
    return currentState;
  }
}

export async function persistMessage(msg: ChatMessage): Promise<void> {
  try {
    await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(msg),
    });
  } catch (e) {}
}

export async function clearServerMessages(): Promise<void> {
  try {
    await fetch("/api/messages", { method: "DELETE" });
  } catch (e) {}
}

export async function addPersistentMemory(
  content: string,
  category: string = "general"
): Promise<MemoryItem | null> {
  const trimmed = content.trim();
  if (!trimmed) return null;
  const fallbackItem: MemoryItem = {
    id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    content: trimmed,
    category,
    createdAt: Date.now(),
  };
  try {
    const res = await fetch("/api/memories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: trimmed, category }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return data.memory || fallbackItem;
  } catch (e) {
    return fallbackItem;
  }
}

export async function deletePersistentMemory(id: string): Promise<void> {
  try {
    await fetch(`/api/memories/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (e) {}
}

export async function savePersistentConfig(config: RadhaConfig): Promise<void> {
  saveLocalConfig(config);
  try {
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config),
    });
  } catch (e) {}
}

export async function extractBackgroundMemories(
  recentMessages: ChatMessage[],
  existingMemories: MemoryItem[]
): Promise<MemoryItem[]> {
  if (recentMessages.length < 2) return [];
  try {
    const res = await fetch("/api/memory/summarize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recentMessages: recentMessages.slice(-8),
        existingMemories: existingMemories.slice(-30).map((m) => m.content),
      }),
    });
    if (!res.ok) return [];
    const data = await res.json();
    return Array.isArray(data.added) ? data.added : [];
  } catch (e) {
    return [];
  }
}

// Reminders API
export async function createPersistentReminder(
  title: string,
  triggerAt: number
): Promise<ReminderItem | null> {
  try {
    const res = await fetch("/api/reminders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, triggerAt }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.reminder || null;
  } catch (e) {
    return null;
  }
}

export async function markReminderCompleted(id: string, completed: boolean): Promise<void> {
  try {
    await fetch(`/api/reminders/${encodeURIComponent(id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed }),
    });
  } catch (e) {}
}

export async function deletePersistentReminder(id: string): Promise<void> {
  try {
    await fetch(`/api/reminders/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (e) {}
}

// Tasks API
export async function createPersistentTask(
  title: string,
  priority: "low" | "medium" | "high" = "medium"
): Promise<TaskItem | null> {
  try {
    const res = await fetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, priority }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.task || null;
  } catch (e) {
    return null;
  }
}

export async function togglePersistentTask(id: string, completed: boolean): Promise<void> {
  try {
    await fetch(`/api/tasks/${encodeURIComponent(id)}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completed }),
    });
  } catch (e) {}
}

export async function deletePersistentTask(id: string): Promise<void> {
  try {
    await fetch(`/api/tasks/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch (e) {}
}

// Mood Diary & Bonding API
export async function logMoodEntry(
  emotion: RadhaEmotion,
  note: string,
  xpGain: number = 15
): Promise<{ mood: MoodEntry; bonding: BondingState } | null> {
  try {
    const res = await fetch("/api/moods", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ emotion, note, xpGain }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.mood && data.bonding) {
      return { mood: data.mood, bonding: data.bonding };
    }
    return null;
  } catch (e) {
    return null;
  }
}

// Real-Time Web Search (Google Search Grounding) — automatically attaches Session Context
export async function searchLiveWeb(query: string): Promise<WebSearchResult> {
  const res = await fetch("/api/gemini/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      query,
      sessionContextSummary: buildSessionContextSummary(),
    }),
  });
  if (!res.ok) {
    let errMsg = `Search HTTP ${res.status}`;
    try {
      const errData = await res.json();
      if (errData?.error) errMsg = errData.error;
    } catch {}
    throw new Error(errMsg);
  }
  return res.json();
}

// Multimodal File / Photo / Code Analysis — automatically attaches Session Context & stores in Vault
export async function analyzeUploadedFile(params: {
  base64Data: string;
  mimeType: string;
  fileName: string;
  question?: string;
}): Promise<string> {
  const res = await analyzeAndStoreUploadedFile(params);
  return res.analysis;
}

export async function analyzeAndStoreUploadedFile(params: {
  base64Data: string;
  mimeType: string;
  fileName: string;
  question?: string;
}): Promise<{ analysis: string; vaultFile: UploadedVaultFile | null }> {
  const res = await fetch("/api/gemini/analyze", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ...params,
      sessionContextSummary: buildSessionContextSummary(),
    }),
  });
  if (!res.ok) {
    let errMsg = `Analyze HTTP ${res.status}`;
    try {
      const errData = await res.json();
      if (errData?.error) errMsg = errData.error;
    } catch {}
    throw new Error(errMsg);
  }
  const data = await res.json();
  return {
    analysis: data.analysis || "Analysis complete.",
    vaultFile: data.vaultFile || null,
  };
}

export async function uploadFileToSystemVault(params: {
  base64Data: string;
  mimeType: string;
  fileName: string;
  question?: string;
}): Promise<{ file: UploadedVaultFile; systemEvent: SystemEventItem } | null> {
  const res = await fetch("/api/files/vault", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    let errMsg = `Vault upload HTTP ${res.status}`;
    try {
      const errData = await res.json();
      if (errData?.error) errMsg = errData.error;
    } catch {}
    throw new Error(errMsg);
  }
  const data = await res.json();
  if (data.file && data.systemEvent) {
    return { file: data.file, systemEvent: data.systemEvent };
  }
  return null;
}

export async function deleteVaultFile(id: string): Promise<void> {
  try {
    await fetch(`/api/files/vault/${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch {}
}

export async function logSystemEvent(
  category: string,
  summary: string
): Promise<SystemEventItem | null> {
  try {
    const res = await fetch("/api/system-events", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ category, summary }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.event || null;
  } catch {
    return null;
  }
}

export interface OwnerFaceVerificationResult {
  isOwner: boolean;
  faceDetected: boolean;
  confidence: number;
  expression: string;
  greeting: string;
  visualNote: string;
  spoofDetected?: boolean;
  livenessVerified?: boolean;
  hashVerified?: boolean;
}

export interface OwnerCalibrationResult {
  calibrated: boolean;
  livenessPassed: boolean;
  antiSpoofScore: number;
  biometricHash: string;
  geometrySignature: string;
  calibratedAt: number;
  reason?: string;
}

export async function calibrateOwnerBiometrics(params: {
  angleFrames: Array<{ angle: string; dataUrl: string }>;
  ownerName: string;
  parallaxDelta: number;
  spatialVector: string;
}): Promise<OwnerCalibrationResult> {
  const res = await fetch("/api/vision/calibrate-owner", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    let msg = `Calibration HTTP ${res.status}`;
    try {
      const err = await res.json();
      if (err?.error) msg = err.error;
    } catch {}
    throw new Error(msg);
  }
  return res.json();
}

export async function verifyOwnerFace(params: {
  ownerPhotoDataUrl?: string;
  liveFrameBase64: string;
  liveFrame2Base64?: string;
  ownerName: string;
  ownerBio?: string;
  biometricProfile?: BiometricSecurityProfile;
}): Promise<OwnerFaceVerificationResult> {
  const res = await fetch("/api/vision/verify-owner", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });
  if (!res.ok) {
    let msg = `Face verify HTTP ${res.status}`;
    try {
      const err = await res.json();
      if (err?.error) msg = err.error;
    } catch {}
    throw new Error(msg);
  }
  return res.json();
}
