import { getDynamicSystemInstruction, RadhaContextSnapshot } from "./geminiService";
import { formatUrl } from "./commandService";
import {
  ChatMessage,
  DEFAULT_RADHA_CONFIG,
  MemoryItem,
  RadhaConfig,
  RadhaEmotion,
  ReminderItem,
  TaskItem,
  addPersistentMemory,
  createPersistentReminder,
  createPersistentTask,
  detectEmotionFromText,
  searchLiveWeb,
} from "./memoryService";
import {
  getTtsAnalyser,
  getUnlockedLiveInputContext,
  getUnlockedLivePlaybackContext,
  isTtsAudioPlaying,
  stopActivePCM,
} from "../utils/audioUtils";
import {
  fetchCurrentLocationWeather,
  fetchWeatherByCity,
  formatWeatherHindiReply,
  LiveWeatherData,
} from "./weatherService";
import { addVoiceNote, VoiceNoteItem } from "./deviceCareService";

// Filter empty, punctuation-only, or accidental 1-character noise triggers
export function isMeaningfulTranscript(text: string): boolean {
  const stripped = text.replace(/[\s.,!?…\-_~`'"()[\]{}:;/\\|<>]+/g, "").trim();
  return stripped.length >= 2;
}

// Singleton guard so two LiveSessionManager instances can NEVER output overlapping double sound
let activeLiveInstance: LiveSessionManager | null = null;

export interface AudioWaveformSnapshot {
  bars: number[]; // Normalized 0..1 values
  source: "user" | "radha" | "idle";
  levelDb: number;
  bass: number;
  mid: number;
  treble: number;
}

/**
 * Reads live 60FPS real audio spectrum from active Mic, Live Radha Voice, or TTS Playback
 * (used by the 3D Synaptic Neural Consciousness Field).
 */
export function getActiveAudioTelemetry(barCount: number = 40): AudioWaveformSnapshot {
  if (activeLiveInstance) {
    return activeLiveInstance.getWaveformSnapshot(barCount);
  }
  const ttsAnalyser = getTtsAnalyser();
  if (ttsAnalyser && isTtsAudioPlaying()) {
    return extractBarsFromAnalyser(ttsAnalyser, barCount, "radha");
  }
  return {
    bars: new Array(barCount).fill(0.06),
    source: "idle",
    levelDb: -60,
    bass: 0,
    mid: 0,
    treble: 0,
  };
}

function extractBarsFromAnalyser(
  analyser: AnalyserNode,
  barCount: number,
  source: "user" | "radha"
): AudioWaveformSnapshot {
  const freqData = new Uint8Array(analyser.frequencyBinCount);
  analyser.getByteFrequencyData(freqData);

  const bars: number[] = [];
  const usableBins = Math.max(1, Math.floor(freqData.length * 0.85));
  let sum = 0;
  for (let i = 0; i < barCount; i++) {
    const startIdx = Math.floor((i / barCount) * usableBins);
    const endIdx = Math.max(startIdx + 1, Math.floor(((i + 1) / barCount) * usableBins));
    let peak = 0;
    for (let j = startIdx; j < endIdx && j < freqData.length; j++) {
      if (freqData[j] > peak) peak = freqData[j];
    }
    const norm = Math.min(1, peak / 210);
    sum += norm;
    bars.push(Math.max(0.06, norm));
  }

  const avg = sum / Math.max(1, barCount);
  const bassSlice = freqData.slice(0, Math.max(2, Math.floor(usableBins * 0.25)));
  const midSlice = freqData.slice(Math.floor(usableBins * 0.25), Math.floor(usableBins * 0.65));
  const trebleSlice = freqData.slice(Math.floor(usableBins * 0.65), usableBins);

  const avgSlice = (arr: Uint8Array) =>
    arr.length ? arr.reduce((a, b) => a + b, 0) / (arr.length * 255) : 0;

  const levelDb = avg > 0.01 ? Math.round(20 * Math.log10(Math.max(0.001, avg))) : -60;
  return {
    bars,
    source: avg > 0.03 ? source : "idle",
    levelDb: Math.max(-60, Math.min(0, levelDb)),
    bass: avgSlice(bassSlice),
    mid: avgSlice(midSlice),
    treble: avgSlice(trebleSlice),
  };
}

// Anti-aliased low-pass FIR downsampler from microphone sample rate (48kHz/44.1kHz) to 16000 Hz.
// Eliminates high-frequency aliasing distortion on Hindi consonants (स/श/च/ट/क/त) so Gemini hears every word clearly!
function resampleTo16k(input: Float32Array, fromRate: number): Float32Array {
  if (fromRate === 16000) return input;
  const ratio = fromRate / 16000;
  const newLength = Math.floor(input.length / ratio);
  const result = new Float32Array(newLength);
  if (ratio > 1.2) {
    // Weighted anti-aliasing window spanning [pos - radius, pos + radius]
    const radius = Math.max(1, Math.ceil(ratio));
    for (let i = 0; i < newLength; i++) {
      const center = i * ratio;
      const start = Math.max(0, Math.floor(center - radius));
      const end = Math.min(input.length - 1, Math.ceil(center + radius));
      let weightedSum = 0;
      let weightTotal = 0;
      for (let j = start; j <= end; j++) {
        const dist = Math.abs(j - center) / (radius + 0.5);
        // Smooth triangular/Bartlett anti-alias kernel
        const w = Math.max(0, 1 - dist);
        weightedSum += input[j] * w;
        weightTotal += w;
      }
      result[i] = weightTotal > 0 ? weightedSum / weightTotal : input[Math.min(Math.floor(center), input.length - 1)];
    }
    return result;
  }
  for (let i = 0; i < newLength; i++) {
    const pos = i * ratio;
    const index = Math.floor(pos);
    const frac = pos - index;
    const nextIndex = Math.min(index + 1, input.length - 1);
    result[i] = input[index] * (1 - frac) + input[nextIndex] * frac;
  }
  return result;
}

function encodeFloat32ToPcm16Base64(samples: Float32Array, muteToZeros: boolean): string {
  const buffer = new ArrayBuffer(samples.length * 2);
  if (!muteToZeros) {
    const view = new DataView(buffer);
    for (let i = 0; i < samples.length; i++) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      const val = s < 0 ? s * 0x8000 : s * 0x7fff;
      view.setInt16(i * 2, val, true);
    }
  }
  const bytes = new Uint8Array(buffer);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

// Detect natural Hindi/Hinglish/English farewell phrases from Boss
export function isFarewellPhrase(text: string): boolean {
  const clean = text.toLowerCase().trim();
  if (!clean) return false;
  return /(?:^|[\s,!.?])(bye|good\s*bye|goodbye|alvida|ok\s*bye|okay\s*bye|bye\s*radha|radha\s*bye|बाय|अलविदा|गुड\s*बाय)(?:$|[\s,!.?])|बात करते हैं.*बाय|बाद में बात करते|baad\s*me(?:in)?\s*baat\s*karte|ab\s*theek\s*hai.*bye|अब ठीक है.*बाय|बंद हो जा|band\s*ho\s*ja|sleep\s*mode/i.test(
    clean
  );
}

const VALID_EMOTIONS: RadhaEmotion[] = [
  "neutral",
  "happy",
  "angry",
  "hurt",
  "sad",
  "caring",
  "playful",
  "excited",
];

export class LiveSessionManager {
  private ws: WebSocket | null = null;
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private inputAnalyser: AnalyserNode | null = null;

  // Audio playback state
  private playbackContext: AudioContext | null = null;
  private outputGainNode: GainNode | null = null;
  private outputAnalyser: AnalyserNode | null = null;
  private currentEmotion: RadhaEmotion = "neutral";
  private nextPlayTime: number = 0;
  private isPlaying: boolean = false;
  private _isMuted: boolean = false;
  public isMicMuted: boolean = false;
  private isStopping: boolean = false;
  private isLiveReady: boolean = false;
  private isReconnecting: boolean = false;
  private reconnectAttempts: number = 0;
  private reconnectTimer: number | null = null;
  private keepAliveTimer: number | null = null;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private finishPlaybackTimer: number | null = null;
  private playbackWatchdogTimer: number | null = null;
  private lastAudioChunkAt: number = 0;
  private isModelGenerating: boolean = false;

  // Farewell auto-sleep state (finish speaking goodbye -> cleanly end link -> re-arm wake-word)
  private pendingFarewell: boolean = false;
  private farewellFallbackTimer: number | null = null;

  // Echo suppression, pre-roll syllable buffer & noise-floor VAD hangover
  private echoCooldownUntil: number = 0;
  private lastUserSpeechTime: number = 0;
  private lastVoiceAboveFloorAt: number = 0;
  private preRollFrame: Float32Array | null = null;
  private wasInSpeechTail: boolean = false;

  // Turn transcription buffers
  private currentTurnUserText: string = "";
  private currentTurnRadhaText: string = "";

  // Context for session setup & seamless reconnect
  private sessionConfig: RadhaConfig = DEFAULT_RADHA_CONFIG;
  private sessionMemories: MemoryItem[] = [];
  private sessionRecentMessages: ChatMessage[] = [];
  private sessionContextSnapshot: RadhaContextSnapshot = {};

  public get isMuted(): boolean {
    return this._isMuted;
  }

  public set isMuted(val: boolean) {
    this._isMuted = val;
    if (val) {
      this.stopPlayback();
    }
  }

  public updateConfig(config: RadhaConfig) {
    this.sessionConfig = config;
  }

  public setEmotion(emotion: RadhaEmotion) {
    this.currentEmotion = emotion;
    // Keep Radha's original live voice gain natural and distortion-free
    if (this.outputGainNode && this.playbackContext && this.playbackContext.state !== "closed") {
      try {
        this.outputGainNode.gain.setTargetAtTime(1.0, this.playbackContext.currentTime, 0.03);
      } catch {}
    }
  }

  public updateSessionContext(
    memories: MemoryItem[],
    recentMessages: ChatMessage[],
    ctx: RadhaContextSnapshot
  ) {
    this.sessionMemories = memories;
    this.sessionRecentMessages = recentMessages;
    this.sessionContextSnapshot = ctx;
  }

  public onStateChange: (state: "idle" | "listening" | "processing" | "speaking") => void = () => {};
  public onReady: () => void = () => {};
  public onMessage: (sender: "user" | "radha", text: string) => void = () => {};
  public onCommand: (url: string) => void = () => {};
  public onClose: () => void = () => {};
  public onFarewellComplete: () => void = () => {};
  public onUserSpeech: () => void = () => {};
  public onPlaybackEnd: () => void = () => {};
  public onEmotionChange: (emotion: RadhaEmotion, reason?: string) => void = () => {};
  public onMemorySaved: (memory: MemoryItem) => void = () => {};
  public onReminderCreated: (reminder: ReminderItem) => void = () => {};
  public onTaskCreated: (task: TaskItem) => void = () => {};
  public onCyberEvent: (logLine: string) => void = () => {};
  public onRoutineUpdated: (
    task: "bathed" | "lunch" | "dinner" | "water" | "health",
    completed: boolean
  ) => void = () => {};
  public onGetSocialBriefing: (
    platform: "all" | "instagram" | "gmail" | "facebook"
  ) => Promise<string> | string = () => "Workspace monitor ready.";
  public onWeatherFetched: (weather: LiveWeatherData) => void = () => {};
  public onVoiceNoteSaved: (note: VoiceNoteItem) => void = () => {};

  constructor() {}

  public getWaveformSnapshot(barCount: number = 40): AudioWaveformSnapshot {
    if (this.isPlaying && this.outputAnalyser) {
      return extractBarsFromAnalyser(this.outputAnalyser, barCount, "radha");
    }
    if (!this.isMicMuted && this.inputAnalyser) {
      return extractBarsFromAnalyser(this.inputAnalyser, barCount, "user");
    }
    return {
      bars: new Array(barCount).fill(0.06),
      source: "idle",
      levelDb: -60,
      bass: 0,
      mid: 0,
      treble: 0,
    };
  }

  async start(
    config: RadhaConfig = DEFAULT_RADHA_CONFIG,
    memories: MemoryItem[] = [],
    recentMessages: ChatMessage[] = [],
    ctx: RadhaContextSnapshot = {}
  ) {
    try {
      stopActivePCM();
      if (activeLiveInstance && activeLiveInstance !== this) {
        activeLiveInstance.stop();
      }
      activeLiveInstance = this;

      this.isStopping = false;
      this.isReconnecting = false;
      this.isLiveReady = false;
      this.isModelGenerating = false;
      this.isPlaying = false;
      this.reconnectAttempts = 0;
      this.pendingFarewell = false;
      this.currentTurnUserText = "";
      this.currentTurnRadhaText = "";
      this.sessionConfig = config;
      this.sessionMemories = memories;
      this.sessionRecentMessages = recentMessages;
      this.sessionContextSnapshot = ctx;
      this.onStateChange("processing");

      // Reuse user-gesture-unlocked persistent AudioContexts so Wake-Word activation NEVER starts suspended!
      this.audioContext = getUnlockedLiveInputContext();
      this.playbackContext = getUnlockedLivePlaybackContext();
      if (!this.audioContext || !this.playbackContext) {
        throw new Error("Web Audio API is not supported in this browser");
      }

      if (this.audioContext.state === "suspended") {
        await this.audioContext.resume().catch(() => {});
      }
      if (this.playbackContext.state === "suspended") {
        await this.playbackContext.resume().catch(() => {});
      }

      this.inputAnalyser = this.audioContext.createAnalyser();
      this.inputAnalyser.fftSize = 128;
      this.inputAnalyser.smoothingTimeConstant = 0.7;

      this.outputGainNode = this.playbackContext.createGain();
      this.outputGainNode.gain.value = 1.0;

      this.outputAnalyser = this.playbackContext.createAnalyser();
      this.outputAnalyser.fftSize = 128;
      this.outputAnalyser.smoothingTimeConstant = 0.72;
      this.outputGainNode.connect(this.outputAnalyser);
      this.outputAnalyser.connect(this.playbackContext.destination);

      this.nextPlayTime = this.playbackContext.currentTime;

      // Capture mic with full hardware AEC, noise suppression, and auto gain.
      // Retry once after 260ms in case Wake-Word SpeechRecognition is still releasing hardware mic on Android/Windows.
      const micConstraints: MediaStreamConstraints = {
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      };
      try {
        this.mediaStream = await navigator.mediaDevices.getUserMedia(micConstraints);
      } catch (micErr: any) {
        if (micErr?.name === "NotAllowedError" || micErr?.name === "PermissionDeniedError") {
          throw micErr;
        }
        await new Promise((r) => setTimeout(r, 260));
        this.mediaStream = await navigator.mediaDevices.getUserMedia(micConstraints);
      }

      this.source = this.audioContext.createMediaStreamSource(this.mediaStream);
      // 2048 samples (~42ms at 48kHz) cuts voice capture latency in half for crisper listening & faster replies
      this.processor = this.audioContext.createScriptProcessor(2048, 1, 1);
      this.preRollFrame = null;
      this.wasInSpeechTail = false;

      this.processor.onaudioprocess = (e) => {
        if (this.isStopping || this.isReconnecting) return;
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
        if (!this.isLiveReady) return;
        if (this.isMicMuted) return;

        const rawInputData = e.inputBuffer.getChannelData(0);
        const actualSampleRate = this.audioContext?.sampleRate || 16000;
        const inputData = resampleTo16k(rawInputData, actualSampleRate);

        let sumSquares = 0;
        for (let i = 0; i < inputData.length; i++) {
          sumSquares += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sumSquares / Math.max(1, inputData.length));

        // Strict Anti-Echo Gate + Pre-Roll Syllable Preservation + Continuous 16kHz VAD Stream:
        // - Sends digital zeros while Radha speaks (zero self-echo).
        // - On speech onset, flushes the previous 42ms pre-roll frame so the very first Hindi consonant is NEVER clipped!
        // - Holds an 800ms tail after voice stops so sentence endings stay 100% intact before transitioning to clean silence zeros.
        const activelyOutputtingSound =
          this.isPlaying ||
          this.activeSources.size > 0 ||
          isTtsAudioPlaying();
        const nowMs = Date.now();
        const inEchoCooldown = nowMs < this.echoCooldownUntil;

        let shouldMuteToDigitalSilence = false;
        if (activelyOutputtingSound || inEchoCooldown) {
          shouldMuteToDigitalSilence = true;
          this.preRollFrame = null;
          this.wasInSpeechTail = false;
        } else {
          if (rms >= 0.0022) {
            this.lastVoiceAboveFloorAt = nowMs;
          }
          const withinSpeechTail = nowMs - this.lastVoiceAboveFloorAt <= 800;
          if (!withinSpeechTail) {
            shouldMuteToDigitalSilence = true;
            // Keep a copy of the latest quiet frame as a 42ms pre-roll lookback for soft initial consonants
            this.preRollFrame = new Float32Array(inputData);
            this.wasInSpeechTail = false;
          } else {
            // If we just transitioned from silence -> speech, flush the 42ms pre-roll frame first!
            if (!this.wasInSpeechTail && this.preRollFrame) {
              this.safeSend({
                type: "audio",
                data: encodeFloat32ToPcm16Base64(this.preRollFrame, false),
              });
              this.preRollFrame = null;
            }
            this.wasInSpeechTail = true;
            if (rms >= 0.01) {
              this.lastUserSpeechTime = nowMs;
              this.onUserSpeech();
            }
          }
        }

        this.safeSend({
          type: "audio",
          data: encodeFloat32ToPcm16Base64(inputData, shouldMuteToDigitalSilence),
        });
      };

      const silentGain = this.audioContext.createGain();
      silentGain.gain.value = 0;
      this.source.connect(this.inputAnalyser);
      this.inputAnalyser.connect(this.processor);
      this.processor.connect(silentGain);
      silentGain.connect(this.audioContext.destination);

      // Keep AudioContexts awake & clear any stuck playback flags automatically
      this.keepAliveTimer = window.setInterval(() => {
        if (this.isStopping) return;
        if (this.audioContext?.state === "suspended") {
          this.audioContext.resume().catch(() => {});
        }
        if (this.playbackContext?.state === "suspended") {
          this.playbackContext.resume().catch(() => {});
        }
        // Watchdog: if no audio chunk arrived for 4s and no buffer is playing, guarantee listening state
        if (
          (this.isPlaying || this.isModelGenerating) &&
          this.activeSources.size === 0 &&
          Date.now() - this.lastAudioChunkAt > 4000
        ) {
          this.isPlaying = false;
          this.isModelGenerating = false;
          if (this.isLiveReady) this.onStateChange("listening");
        }
      }, 2500);

      this.connectWebSocket();
    } catch (error) {
      this.stop();
      throw error;
    }
  }

  private scheduleReconnect(reason: string) {
    if (this.isStopping || this.pendingFarewell) return;
    if (this.sessionConfig.autoReconnectVoice === false) {
      this.stop();
      return;
    }
    if (this.isReconnecting) return;

    if (this.reconnectAttempts >= 6) {
      this.onCyberEvent("VOICE LINK MAX RETRIES REACHED");
      this.stop();
      return;
    }

    this.isReconnecting = true;
    this.isLiveReady = false;
    this.isModelGenerating = false;
    this.reconnectAttempts += 1;

    if (this.ws) {
      try {
        this.ws.onclose = null;
        this.ws.onerror = null;
        this.ws.onmessage = null;
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    const delayMs = Math.min(3500, 350 * Math.pow(1.6, this.reconnectAttempts - 1));
    this.onCyberEvent(`AUTO-RECONNECTING VOICE LINK (#${this.reconnectAttempts}: ${reason})`);

    if (this.reconnectTimer) {
      window.clearTimeout(this.reconnectTimer);
    }
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      if (this.isStopping) return;
      this.isReconnecting = false;
      this.connectWebSocket();
    }, delayMs);
  }

  private triggerFarewellShutdown() {
    if (this.farewellFallbackTimer) {
      window.clearTimeout(this.farewellFallbackTimer);
      this.farewellFallbackTimer = null;
    }
    this.pendingFarewell = false;
    this.onCyberEvent("FAREWELL COMPLETE -> ENTERING WAKE STANDBY");
    this.stop();
    this.onFarewellComplete();
  }

  private armFarewellAutoSleep() {
    if (this.sessionConfig.autoSleepOnBye === false) return;
    if (this.pendingFarewell) return;
    this.pendingFarewell = true;
    this.onCyberEvent("FAREWELL DETECTED -> AUTO-SLEEP AFTER REPLY");

    if (this.farewellFallbackTimer) {
      window.clearTimeout(this.farewellFallbackTimer);
    }
    this.farewellFallbackTimer = window.setTimeout(() => {
      if (this.pendingFarewell && !this.isPlaying && !this.isModelGenerating) {
        this.triggerFarewellShutdown();
      }
    }, 8500);
  }

  private markLiveReady() {
    if (this.isLiveReady) return;
    this.isLiveReady = true;
    this.isReconnecting = false;
    this.reconnectAttempts = 0;
    this.echoCooldownUntil = Date.now() + 160;
    this.onStateChange("listening");
    this.onCyberEvent("VOICE LINK READY · ORIGINAL EMOTIONAL VOICE ON");
    this.onReady();
  }

  private connectWebSocket() {
    if (this.isStopping) return;

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      const socket = new WebSocket(wsUrl);
      this.ws = socket;

      socket.onopen = () => {
        if (this.isStopping || this.ws !== socket) return;
        this.safeSend({
          type: "setup",
          voiceName: this.sessionConfig.voiceName || "Kore",
          systemInstruction: getDynamicSystemInstruction(
            this.sessionConfig,
            this.sessionMemories,
            this.sessionRecentMessages,
            this.sessionContextSnapshot
          ),
        });
      };

      socket.onmessage = async (event) => {
        if (this.isStopping || this.ws !== socket) return;
        try {
          const data = JSON.parse(event.data);

          if (data.type === "ping") {
            this.safeSend({ type: "pong" });
            return;
          }
          if (data.type === "pong") return;

          if (data.type === "open") {
            this.markLiveReady();
          } else if (data.type === "message") {
            const message = data.message;
            if (!message) return;

            if (message.setupComplete) {
              this.markLiveReady();
              return;
            }

            // Seamless live session rollover instead of dropping Boss mid-conversation
            if (message.goAway) {
              this.scheduleReconnect("SESSION ROLLOVER");
              return;
            }

            // Capture Boss's live spoken transcript (official SDK uses inputTranscription; support both)
            const userTranscriptChunk =
              message.serverContent?.inputTranscription?.text ||
              message.serverContent?.inputAudioTranscription?.text;
            if (userTranscriptChunk) {
              this.currentTurnUserText += userTranscriptChunk;
              this.lastUserSpeechTime = Date.now();
              this.onUserSpeech();
              if (isFarewellPhrase(this.currentTurnUserText)) {
                this.armFarewellAutoSleep();
              }
            }

            if (message.serverContent?.modelTurn) {
              this.isModelGenerating = true;
              this.lastAudioChunkAt = Date.now();
              if (isMeaningfulTranscript(this.currentTurnUserText)) {
                const userText = this.currentTurnUserText.trim();
                const detectedUserMood = detectEmotionFromText(userText, "user");
                if (detectedUserMood) {
                  this.onEmotionChange(detectedUserMood);
                }
                if (isFarewellPhrase(userText)) {
                  this.armFarewellAutoSleep();
                }
                this.onMessage("user", userText);
              }
              this.currentTurnUserText = "";
            }

            if (message.serverContent?.modelTurn?.parts) {
              for (const part of message.serverContent.modelTurn.parts) {
                if (part.inlineData?.data) {
                  this.playAudioChunk(part.inlineData.data);
                }
              }
            }

            if (message.serverContent?.interrupted) {
              this.stopPlayback();
              this.onStateChange("listening");
              if (this.currentTurnRadhaText.trim()) {
                this.onMessage("radha", this.currentTurnRadhaText.trim() + "...");
                this.currentTurnRadhaText = "";
              }
            }

            const radhaChunk =
              message.serverContent?.outputTranscription?.text ||
              message.serverContent?.modelTurn?.parts
                ?.map((p: any) => p.text)
                .filter(Boolean)
                .join(" ");
            if (radhaChunk) {
              this.currentTurnRadhaText += radhaChunk;
              const liveDetected = detectEmotionFromText(this.currentTurnRadhaText, "radha");
              if (liveDetected) {
                this.setEmotion(liveDetected);
                this.onEmotionChange(liveDetected);
              }
            }

            if (message.serverContent?.generationComplete) {
              this.isModelGenerating = false;
            }

            if (message.serverContent?.turnComplete) {
              this.isModelGenerating = false;
              if (isMeaningfulTranscript(this.currentTurnUserText)) {
                const userText = this.currentTurnUserText.trim();
                const detectedUserMood = detectEmotionFromText(userText, "user");
                if (detectedUserMood) {
                  this.setEmotion(detectedUserMood);
                  this.onEmotionChange(detectedUserMood);
                }
                if (isFarewellPhrase(userText)) {
                  this.armFarewellAutoSleep();
                }
                this.onMessage("user", userText);
              }
              this.currentTurnUserText = "";
              if (isMeaningfulTranscript(this.currentTurnRadhaText)) {
                const radhaText = this.currentTurnRadhaText.trim();
                const detectedRadhaMood = detectEmotionFromText(radhaText, "radha");
                if (detectedRadhaMood) {
                  this.setEmotion(detectedRadhaMood);
                  this.onEmotionChange(detectedRadhaMood);
                }
                this.onMessage("radha", radhaText);
              }
              this.currentTurnRadhaText = "";
              this.handlePlaybackChunkEnded();
            }

            // Handle Live Function Calls
            const functionCalls = message.toolCall?.functionCalls;
            if (functionCalls && functionCalls.length > 0) {
              const responsesToSend: any[] = [];

              for (const call of functionCalls) {
                if (call.name === "executeBrowserAction") {
                  const args = call.args as any;
                  let url = "";
                  if (args.actionType === "youtube") {
                    url = `https://www.youtube.com/results?search_query=${encodeURIComponent(args.query)}`;
                  } else if (args.actionType === "spotify") {
                    url = `https://open.spotify.com/search/${encodeURIComponent(args.query)}`;
                  } else if (args.actionType === "whatsapp") {
                    url = `https://web.whatsapp.com/send?phone=${args.target || ""}&text=${encodeURIComponent(args.query)}`;
                  } else if (args.actionType === "search") {
                    url = `https://www.google.com/search?q=${encodeURIComponent(args.query)}`;
                  } else {
                    url = formatUrl(args.query);
                  }

                  this.onCommand(url);
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: { result: "Action executed successfully in the browser." },
                  });
                } else if (call.name === "saveMemory") {
                  const args = call.args as any;
                  const fact = String(args?.fact || "").trim();
                  const category = String(args?.category || "general").trim();
                  if (fact) {
                    const saved = await addPersistentMemory(fact, category);
                    if (saved) {
                      this.sessionMemories = [saved, ...this.sessionMemories];
                      this.onMemorySaved(saved);
                    }
                  }
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: { result: "Memory saved permanently." },
                  });
                } else if (call.name === "setRadhaEmotion") {
                  const args = call.args as any;
                  const rawEmotion = String(args?.emotion || "neutral").toLowerCase() as RadhaEmotion;
                  const validEmotion: RadhaEmotion = VALID_EMOTIONS.includes(rawEmotion)
                    ? rawEmotion
                    : "neutral";
                  this.setEmotion(validEmotion);
                  this.onEmotionChange(validEmotion, args?.reason);
                  this.onCyberEvent(`EMOTION_SYNC -> ${validEmotion.toUpperCase()}`);
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: { result: `Emotion updated to ${validEmotion}.` },
                  });
                } else if (call.name === "createReminder") {
                  const args = call.args as any;
                  const title = String(args?.title || "Reminder").trim();
                  const delayMin = Math.max(0.25, Number(args?.delayMinutes || 5));
                  const triggerAt = Date.now() + Math.round(delayMin * 60 * 1000);
                  const created = await createPersistentReminder(title, triggerAt);
                  if (created) {
                    this.onReminderCreated(created);
                    this.onCyberEvent(`ALARM_SET -> "${title}" (+${delayMin}m)`);
                  }
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: {
                      result: `Reminder "${title}" scheduled for ${new Date(triggerAt).toLocaleTimeString()}.`,
                    },
                  });
                } else if (call.name === "addTask") {
                  const args = call.args as any;
                  const title = String(args?.title || "").trim();
                  const priority = ["low", "medium", "high"].includes(args?.priority)
                    ? args.priority
                    : "medium";
                  if (title) {
                    const created = await createPersistentTask(title, priority);
                    if (created) {
                      this.onTaskCreated(created);
                      this.onCyberEvent(`TASK_LOGGED -> [${priority.toUpperCase()}] ${title}`);
                    }
                  }
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: { result: `Task "${title}" saved to Ravindra Boss's list.` },
                  });
                } else if (call.name === "searchWeb") {
                  const args = call.args as any;
                  const query = String(args?.query || "").trim();
                  this.onCyberEvent(`WEB_INTEL_QUERY -> "${query}"`);
                  try {
                    const res = await searchLiveWeb(query);
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: {
                        answer: res.answer,
                        sources: res.sources.map((s) => s.title).join(", "),
                      },
                    });
                  } catch {
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: { answer: "Live search temporarily busy." },
                    });
                  }
                } else if (call.name === "updateDailyRoutine") {
                  const args = call.args as any;
                  const rawTask = String(args?.task || "").toLowerCase();
                  const allowedTasks = ["bathed", "lunch", "dinner", "water", "health"] as const;
                  const task = allowedTasks.find((t) => t === rawTask);
                  const completed = Boolean(args?.completed ?? true);
                  if (task) {
                    this.onRoutineUpdated(task, completed);
                    this.onCyberEvent(`ROUTINE_LOCKED -> ${task.toUpperCase()}=${completed ? "DONE" : "PENDING"}`);
                  }
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: {
                      result: task
                        ? `Routine task '${task}' marked as ${completed ? "completed" : "pending"} for today. Never repeat asking about it again today.`
                        : "Invalid routine task.",
                    },
                  });
                } else if (call.name === "getSocialWorkspaceBriefing") {
                  const args = call.args as any;
                  const rawPlatform = String(args?.platform || "all").toLowerCase();
                  const platform = (["all", "instagram", "gmail", "facebook"].includes(rawPlatform)
                    ? rawPlatform
                    : "all") as "all" | "instagram" | "gmail" | "facebook";
                  this.onCyberEvent(`SOCIAL_BRIEFING -> ${platform.toUpperCase()}`);
                  try {
                    const summary = await this.onGetSocialBriefing(platform);
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: { briefing: summary },
                    });
                  } catch {
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: { briefing: "Workspace insights are temporarily refreshing." },
                    });
                  }
                } else if (call.name === "getLiveWeather") {
                  const args = call.args as any;
                  const city = String(args?.city || "").trim();
                  this.onCyberEvent(`LIVE_WEATHER -> ${city || "GPS AUTO"}`);
                  try {
                    const weather = city
                      ? await fetchWeatherByCity(city)
                      : await fetchCurrentLocationWeather();
                    this.onWeatherFetched(weather);
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: {
                        city: weather.city,
                        temperatureC: weather.tempC,
                        feelsLikeC: weather.feelsLikeC,
                        humidity: weather.humidity,
                        windKmh: weather.windKmh,
                        condition: weather.conditionEn,
                        hindiSummary: formatWeatherHindiReply(
                          weather,
                          this.sessionConfig.ownerNickname || "बॉस"
                        ),
                      },
                    });
                  } catch {
                    responsesToSend.push({
                      name: call.name,
                      id: call.id,
                      response: { error: "Live weather could not be fetched right now." },
                    });
                  }
                } else if (call.name === "saveVoiceNote") {
                  const args = call.args as any;
                  const content = String(args?.content || "").trim();
                  if (content) {
                    const saved = addVoiceNote(content);
                    if (saved) {
                      this.onVoiceNoteSaved(saved);
                      this.onCyberEvent(`VOICE_NOTE_SAVED -> ${content.slice(0, 28)}`);
                    }
                  }
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: { result: content ? `Note saved permanently: ${content}` : "Empty note ignored." },
                  });
                } else if (call.name === "endVoiceSession") {
                  this.armFarewellAutoSleep();
                  responsesToSend.push({
                    name: call.name,
                    id: call.id,
                    response: {
                      result:
                        "Voice session will cleanly enter wake-word standby as soon as you finish your goodbye.",
                    },
                  });
                }
              }

              if (responsesToSend.length > 0) {
                this.safeSend({
                  type: "toolResponse",
                  functionResponses: responsesToSend,
                });
              }
            }
          } else if (data.type === "error") {
            this.scheduleReconnect("STREAM RECOVERY");
          } else if (data.type === "close") {
            if (!this.isStopping) {
              if (this.pendingFarewell) {
                this.triggerFarewellShutdown();
              } else {
                this.scheduleReconnect("UPSTREAM REFRESH");
              }
            }
          }
        } catch {
          // Ignore malformed packets safely
        }
      };

      socket.onclose = () => {
        if (this.isStopping || this.ws !== socket) return;
        if (this.pendingFarewell) {
          this.triggerFarewellShutdown();
        } else {
          this.scheduleReconnect("WS DROP");
        }
      };

      socket.onerror = () => {
        // Handled by onclose -> scheduleReconnect
      };
    } catch {
      this.scheduleReconnect("SOCKET INIT");
    }
  }

  private safeSend(payload: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(typeof payload === "string" ? payload : JSON.stringify(payload));
      } catch {}
    }
  }

  private playAudioChunk(base64Data: string) {
    if (!this.playbackContext || this.isMuted || this.isStopping) return;

    try {
      if (this.playbackContext.state === "suspended") {
        this.playbackContext.resume().catch(() => {});
      }

      this.lastAudioChunkAt = Date.now();
      if (this.finishPlaybackTimer) {
        window.clearTimeout(this.finishPlaybackTimer);
        this.finishPlaybackTimer = null;
      }

      const binaryString = atob(base64Data);
      const len = binaryString.length;
      const sampleCount = Math.floor(len / 2);
      if (sampleCount === 0) return;

      const audioBuffer = this.playbackContext.createBuffer(1, sampleCount, 24000);
      const channelData = audioBuffer.getChannelData(0);

      for (let i = 0; i < sampleCount; i++) {
        const byte1 = binaryString.charCodeAt(i * 2);
        const byte2 = binaryString.charCodeAt(i * 2 + 1);
        let val = (byte2 << 8) | byte1;
        if (val >= 0x8000) val -= 0x10000;
        channelData[i] = val / 32768.0;
      }

      const source = this.playbackContext.createBufferSource();
      source.buffer = audioBuffer;
      // Preserve Radha's exact original Gemini Live voice (zero artificial emotion speed/pitch warping)
      const clampedPitch = Math.max(0.85, Math.min(1.2, this.sessionConfig.voicePitch || 1.0));
      source.playbackRate.value = clampedPitch;

      if (this.outputGainNode) {
        this.outputGainNode.gain.setTargetAtTime(1.0, this.playbackContext.currentTime, 0.02);
        source.connect(this.outputGainNode);
      } else if (this.outputAnalyser) {
        source.connect(this.outputAnalyser);
      } else {
        source.connect(this.playbackContext.destination);
      }
      this.activeSources.add(source);

      const currentTime = this.playbackContext.currentTime;
      if (this.activeSources.size <= 1 && this.nextPlayTime <= currentTime) {
        // 70ms smooth jitter buffer prevents syllable clips / stutters on first word
        this.nextPlayTime = currentTime + 0.07;
      } else if (this.nextPlayTime < currentTime) {
        // 35ms recovery cushion if network jitter caused a brief gap
        this.nextPlayTime = currentTime + 0.035;
      }

      const dur = audioBuffer.duration / clampedPitch;
      source.start(this.nextPlayTime);
      this.nextPlayTime += dur;
      this.isPlaying = true;
      this.onStateChange("speaking");

      source.onended = () => {
        this.activeSources.delete(source);
        this.handlePlaybackChunkEnded();
      };

      // Safety watchdog: if AudioContext is suspended by browser autoplay policy, never lock mic forever
      if (this.playbackWatchdogTimer) {
        window.clearTimeout(this.playbackWatchdogTimer);
      }
      this.playbackWatchdogTimer = window.setTimeout(() => {
        if (this.playbackContext && this.playbackContext.state === "suspended") {
          this.playbackContext.resume().catch(() => {});
          this.stopPlayback();
          if (this.isLiveReady) this.onStateChange("listening");
        }
      }, Math.max(3000, Math.round((this.nextPlayTime - currentTime) * 1000) + 1800));
    } catch {}
  }

  private handlePlaybackChunkEnded() {
    if (this.finishPlaybackTimer) {
      window.clearTimeout(this.finishPlaybackTimer);
      this.finishPlaybackTimer = null;
    }

    if (this.activeSources.size > 0 || this.isModelGenerating) {
      return;
    }

    const now = this.playbackContext?.currentTime || 0;
    const remainingMs = (this.nextPlayTime - now) * 1000;

    if (remainingMs > 25 && this.playbackContext?.state === "running") {
      this.finishPlaybackTimer = window.setTimeout(() => {
        this.handlePlaybackChunkEnded();
      }, Math.max(20, Math.min(remainingMs, 120)));
      return;
    }

    // Release isPlaying immediately and hold a crisp 180ms acoustic settle so Boss can reply right away without clipped opening words!
    this.isPlaying = false;
    this.echoCooldownUntil = Date.now() + 180;

    this.finishPlaybackTimer = window.setTimeout(() => {
      if (this.activeSources.size === 0 && !this.isModelGenerating) {
        if (this.playbackContext) {
          this.nextPlayTime = this.playbackContext.currentTime;
        }
        if (this.pendingFarewell) {
          this.triggerFarewellShutdown();
          return;
        }
        this.onStateChange("listening");
        this.onPlaybackEnd();
      }
    }, 180);
  }

  /**
   * Smart Barge-In: immediately halts Radha's active voice output and re-opens the microphone cleanly.
   */
  public interruptAndListen() {
    this.stopPlayback();
    this.echoCooldownUntil = Date.now() + 80;
    if (this.isLiveReady && !this.isStopping) {
      this.onStateChange("listening");
    }
  }

  public stopPlayback() {
    if (this.finishPlaybackTimer) {
      window.clearTimeout(this.finishPlaybackTimer);
      this.finishPlaybackTimer = null;
    }
    if (this.playbackWatchdogTimer) {
      window.clearTimeout(this.playbackWatchdogTimer);
      this.playbackWatchdogTimer = null;
    }
    this.activeSources.forEach((source) => {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
      } catch {}
    });
    this.activeSources.clear();
    this.isPlaying = false;
    this.isModelGenerating = false;
    if (this.playbackContext) {
      this.nextPlayTime = this.playbackContext.currentTime;
    }
    this.echoCooldownUntil = Date.now() + 180;
    this.onPlaybackEnd();
  }

  stop() {
    if (this.isStopping) return;
    this.isStopping = true;
    this.isLiveReady = false;
    this.isReconnecting = false;
    this.pendingFarewell = false;

    if (activeLiveInstance === this) {
      activeLiveInstance = null;
    }

    if (this.reconnectTimer) {
      window.clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.keepAliveTimer) {
      window.clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
    if (this.farewellFallbackTimer) {
      window.clearTimeout(this.farewellFallbackTimer);
      this.farewellFallbackTimer = null;
    }
    if (this.finishPlaybackTimer) {
      window.clearTimeout(this.finishPlaybackTimer);
      this.finishPlaybackTimer = null;
    }
    if (this.playbackWatchdogTimer) {
      window.clearTimeout(this.playbackWatchdogTimer);
      this.playbackWatchdogTimer = null;
    }

    this.stopPlayback();

    if (this.processor) {
      try {
        this.processor.disconnect();
      } catch {}
      this.processor = null;
    }
    if (this.inputAnalyser) {
      try {
        this.inputAnalyser.disconnect();
      } catch {}
      this.inputAnalyser = null;
    }
    if (this.outputGainNode) {
      try {
        this.outputGainNode.disconnect();
      } catch {}
      this.outputGainNode = null;
    }
    if (this.outputAnalyser) {
      try {
        this.outputAnalyser.disconnect();
      } catch {}
      this.outputAnalyser = null;
    }
    if (this.source) {
      try {
        this.source.disconnect();
      } catch {}
      this.source = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {}
      });
      this.mediaStream = null;
    }
    // Keep shared persistent AudioContexts alive & unlocked for future Wake-Word activations (do NOT close them!)
    this.audioContext = null;
    this.playbackContext = null;
    if (this.ws) {
      try {
        this.ws.onclose = null;
        this.ws.onerror = null;
        this.ws.onmessage = null;
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    this.onStateChange("idle");
    this.onClose();
  }

  sendText(text: string) {
    this.sendPrompt(text, true);
  }

  sendPrompt(text: string, showInChatAsUser: boolean = true) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.isLiveReady) {
      if (showInChatAsUser) {
        const mood = detectEmotionFromText(text, "user");
        if (mood) {
          this.setEmotion(mood);
          this.onEmotionChange(mood);
        }
        if (isFarewellPhrase(text)) {
          this.armFarewellAutoSleep();
        }
        this.onMessage("user", text);
        this.onStateChange("processing");
      }
      this.safeSend({
        type: "text",
        data: text,
      });
    }
  }

  sendVideoFrame(base64Data: string) {
    if (
      this.ws &&
      this.ws.readyState === WebSocket.OPEN &&
      this.isLiveReady &&
      !this.isReconnecting
    ) {
      this.safeSend({
        type: "video",
        data: base64Data,
      });
    }
  }
}
