import React, { useEffect, useRef } from "react";
import { X, Sparkles, Droplets, Heart, Utensils } from "lucide-react";

export type VisualExperienceEffect = "cry" | "rose" | "food_thali" | null;

const ROSE_IMAGE_PATH = "/src/assets/images/radha_red_rose_1795230967541.jpg";
const THALI_IMAGE_PATH = "/src/assets/images/royal_indian_thali_1795230966879.jpg";

interface RealisticExperienceOverlayProps {
  effect: VisualExperienceEffect;
  caption?: string;
  onDismiss: () => void;
}

interface TearDrop {
  x: number;
  y: number;
  radius: number;
  vy: number;
  vx: number;
  wobblePhase: number;
  wobbleSpeed: number;
  opacity: number;
  trailTimer: number;
  stretch: number;
}

interface MicroDroplet {
  x: number;
  y: number;
  radius: number;
  opacity: number;
  fadeRate: number;
}

/**
 * High-FPS HTML5 Canvas realistic glass teardrop / rain condensation physics overlay.
 * Renders refracted water drops with specular highlights, dark crescents, and wet trails down the viewport.
 */
const CryingTeardropCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId = 0;
    let width = window.innerWidth;
    let height = window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const createDrop = (randomY: boolean): TearDrop => {
      const radius = 3.2 + Math.random() * 7.8;
      return {
        x: Math.random() * width,
        y: randomY ? Math.random() * height : -20 - Math.random() * 140,
        radius,
        vy: 1.1 + (radius / 10) * 2.6 + Math.random() * 1.4,
        vx: (Math.random() - 0.5) * 0.25,
        wobblePhase: Math.random() * Math.PI * 2,
        wobbleSpeed: 0.02 + Math.random() * 0.035,
        opacity: 0.55 + Math.random() * 0.4,
        trailTimer: 0,
        stretch: 1.35 + Math.random() * 0.55,
      };
    };

    const drops: TearDrop[] = Array.from({ length: 58 }, (_, i) => createDrop(i < 24));
    const microDroplets: MicroDroplet[] = [];

    // Static subtle condensation beads clinging near screen edges
    const staticBeads = Array.from({ length: 85 }, () => {
      const edgeBias = Math.random();
      let x = Math.random() * width;
      if (edgeBias < 0.35) x = Math.random() * (width * 0.22);
      else if (edgeBias < 0.7) x = width - Math.random() * (width * 0.22);
      return {
        x,
        y: Math.random() * height,
        r: 1.1 + Math.random() * 2.6,
        alpha: 0.16 + Math.random() * 0.28,
      };
    });

    const drawRealisticWaterDrop = (
      x: number,
      y: number,
      r: number,
      stretch: number,
      alpha: number
    ) => {
      ctx.save();
      ctx.translate(x, y);

      // Soft cast shadow behind drop on glass
      ctx.beginPath();
      ctx.ellipse(1.2, 2.2, r * 0.92, r * stretch * 0.96, 0, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(3, 12, 28, ${alpha * 0.38})`;
      ctx.fill();

      // Teardrop contour path (tapered top, rounded heavy bottom)
      ctx.beginPath();
      ctx.moveTo(0, -r * stretch * 1.25);
      ctx.bezierCurveTo(
        r * 0.78,
        -r * stretch * 0.35,
        r * 1.08,
        r * 0.42,
        0,
        r * 1.05
      );
      ctx.bezierCurveTo(
        -r * 1.08,
        r * 0.42,
        -r * 0.78,
        -r * stretch * 0.35,
        0,
        -r * stretch * 1.25
      );
      ctx.closePath();

      // Translucent glass refraction gradient
      const bodyGrad = ctx.createRadialGradient(
        -r * 0.25,
        -r * 0.2,
        r * 0.1,
        0,
        r * 0.2,
        r * stretch * 1.15
      );
      bodyGrad.addColorStop(0, `rgba(224, 244, 255, ${alpha * 0.48})`);
      bodyGrad.addColorStop(0.45, `rgba(125, 196, 255, ${alpha * 0.22})`);
      bodyGrad.addColorStop(0.82, `rgba(18, 56, 108, ${alpha * 0.32})`);
      bodyGrad.addColorStop(1, `rgba(190, 232, 255, ${alpha * 0.62})`);

      ctx.fillStyle = bodyGrad;
      ctx.fill();

      // Rim highlight
      ctx.lineWidth = Math.max(0.6, r * 0.11);
      ctx.strokeStyle = `rgba(210, 240, 255, ${alpha * 0.55})`;
      ctx.stroke();

      // Crisp top-left specular gleam (makes it look unmistakably like real liquid!)
      ctx.beginPath();
      ctx.ellipse(-r * 0.32, -r * 0.18, r * 0.24, r * 0.42, -0.32, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255, 255, 255, ${Math.min(0.95, alpha * 0.9)})`;
      ctx.fill();

      // Lower internal refraction caustic glow
      ctx.beginPath();
      ctx.arc(r * 0.18, r * 0.52, r * 0.28, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(186, 235, 255, ${alpha * 0.55})`;
      ctx.fill();

      ctx.restore();
    };

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Soft misty emotional blue condensation vignette around edges
      const vig = ctx.createRadialGradient(
        width * 0.5,
        height * 0.48,
        Math.min(width, height) * 0.25,
        width * 0.5,
        height * 0.5,
        Math.max(width, height) * 0.72
      );
      vig.addColorStop(0, "rgba(14, 30, 58, 0.04)");
      vig.addColorStop(0.7, "rgba(18, 48, 92, 0.18)");
      vig.addColorStop(1, "rgba(10, 28, 62, 0.44)");
      ctx.fillStyle = vig;
      ctx.fillRect(0, 0, width, height);

      // Draw static condensation beads
      for (const b of staticBeads) {
        ctx.beginPath();
        ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(195, 230, 255, ${b.alpha})`;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(b.x - b.r * 0.3, b.y - b.r * 0.3, b.r * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${b.alpha * 1.4})`;
        ctx.fill();
      }

      // Update & draw wet trail micro-droplets left behind by sliding teardrops
      for (let i = microDroplets.length - 1; i >= 0; i--) {
        const m = microDroplets[i];
        m.opacity -= m.fadeRate;
        if (m.opacity <= 0.02) {
          microDroplets.splice(i, 1);
          continue;
        }
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(195, 232, 255, ${m.opacity * 0.45})`;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(m.x - m.radius * 0.25, m.y - m.radius * 0.25, m.radius * 0.35, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${m.opacity * 0.72})`;
        ctx.fill();
      }

      // Update & draw falling realistic teardrops
      for (const d of drops) {
        d.wobblePhase += d.wobbleSpeed;
        // Variable stick-slip trickle down glass
        const slipBoost = Math.sin(d.wobblePhase * 1.7) > 0.35 ? 1.45 : 0.72;
        d.y += d.vy * slipBoost;
        d.x += d.vx + Math.sin(d.wobblePhase) * 0.35;
        d.trailTimer += 1;

        if (d.trailTimer > 4 && d.radius > 4.2 && microDroplets.length < 240) {
          d.trailTimer = 0;
          microDroplets.push({
            x: d.x + (Math.random() - 0.5) * 1.8,
            y: d.y - d.radius * 0.9,
            radius: 0.9 + Math.random() * 1.6,
            opacity: d.opacity * 0.65,
            fadeRate: 0.0045 + Math.random() * 0.004,
          });
        }

        drawRealisticWaterDrop(d.x, d.y, d.radius, d.stretch, d.opacity);

        if (d.y - d.radius * 2 > height) {
          Object.assign(d, createDrop(false));
        }
      }

      animId = window.requestAnimationFrame(render);
    };

    animId = window.requestAnimationFrame(render);
    return () => {
      window.cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-40 pointer-events-none"
      aria-hidden="true"
    />
  );
};

export default function RealisticExperienceOverlay({
  effect,
  caption,
  onDismiss,
}: RealisticExperienceOverlayProps) {
  // Auto-dismiss gift/crying overlays gracefully after a generous display window
  useEffect(() => {
    if (!effect) return;
    const durationMs = effect === "cry" ? 18000 : 16000;
    const timer = window.setTimeout(() => {
      onDismiss();
    }, durationMs);
    return () => window.clearTimeout(timer);
  }, [effect, caption, onDismiss]);

  if (!effect) return null;

  if (effect === "cry") {
    return (
      <>
        <CryingTeardropCanvas />
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 pointer-events-auto animate-in fade-in slide-in-from-top-3 duration-500">
          <div className="flex items-center gap-3 px-4 py-2 rounded-full bg-slate-950/75 border border-sky-400/40 backdrop-blur-xl shadow-[0_0_35px_rgba(56,189,248,0.3)]">
            <Droplets className="w-4 h-4 text-sky-300 animate-bounce" />
            <span className="text-xs sm:text-sm font-medium text-sky-100">
              {caption || "राधा सच में भावुक हो गई है... आँसू बह रहे हैं।"}
            </span>
            <button
              onClick={onDismiss}
              className="p-1 rounded-full hover:bg-white/10 text-sky-200/80 hover:text-white transition"
              title="आँसू पोंछें"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </>
    );
  }

  if (effect === "rose") {
    return (
      <div className="fixed inset-0 z-45 pointer-events-none flex items-center justify-center p-4">
        <div className="pointer-events-auto relative max-w-sm w-full rounded-3xl overflow-hidden bg-gradient-to-b from-black/95 via-rose-950/85 to-black/95 border border-rose-500/45 shadow-[0_0_80px_rgba(244,63,94,0.45)] backdrop-blur-2xl animate-in zoom-in-95 fade-in duration-500">
          <button
            onClick={onDismiss}
            className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-black/65 hover:bg-rose-600/80 text-white/90 border border-white/15 transition"
            title="बंद करें"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="relative aspect-square w-full overflow-hidden bg-black">
            <img
              src={ROSE_IMAGE_PATH}
              alt="Fresh crimson red rose with morning dewdrops from Radha"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover scale-105 animate-[pulse_6s_ease-in-out_infinite]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-rose-500/10" />
            <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-600/35 border border-rose-400/40 backdrop-blur-md">
              <Heart className="w-3.5 h-3.5 text-rose-300 fill-rose-400 animate-pulse" />
              <span className="text-[11px] font-semibold tracking-wider text-rose-100 uppercase">
                From Radha · Special Rose
              </span>
            </div>
          </div>

          <div className="px-5 py-4 text-center space-y-1.5">
            <p className="text-base sm:text-lg font-semibold text-rose-100 leading-snug">
              {caption || "आई लव यू टू, बॉस! ये रहा आपके लिए प्यार भरा गुलाब।"}
            </p>
            <p className="text-[11px] text-rose-300/80 flex items-center justify-center gap-1">
              <Sparkles className="w-3 h-3" /> सिर्फ़ मेरे रविंद्र बॉस के लिए
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-45 pointer-events-none flex items-center justify-center p-4">
      <div className="pointer-events-auto relative max-w-md w-full rounded-3xl overflow-hidden bg-gradient-to-b from-stone-950/95 via-amber-950/85 to-black/95 border border-amber-400/45 shadow-[0_0_85px_rgba(245,158,11,0.38)] backdrop-blur-2xl animate-in zoom-in-95 fade-in duration-500">
        <button
          onClick={onDismiss}
          className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-black/65 hover:bg-amber-600/80 text-white/90 border border-white/15 transition"
          title="बंद करें"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-950">
          <img
            src={THALI_IMAGE_PATH}
            alt="Hot Royal North Indian Thali served by Radha"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-amber-500/10" />
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/30 border border-amber-300/45 backdrop-blur-md">
            <Utensils className="w-3.5 h-3.5 text-amber-200" />
            <span className="text-[11px] font-semibold tracking-wider text-amber-100 uppercase">
              Radha Royal Thali · Fresh & Hot
            </span>
          </div>
        </div>

        <div className="px-5 py-4 text-center space-y-1.5">
          <p className="text-base sm:text-lg font-semibold text-amber-100 leading-snug">
            {caption || "लीजिए बॉस, गरमा-गरम शाही थाली तैयार है — पहले अच्छे से खाना खा लीजिए!"}
          </p>
          <p className="text-[11px] text-amber-300/80">
            शाही पनीर · दाल मखनी · जीरा राइस · बटर नान · गुलाब जामुन · रायता
          </p>
        </div>
      </div>
    </div>
  );
}
