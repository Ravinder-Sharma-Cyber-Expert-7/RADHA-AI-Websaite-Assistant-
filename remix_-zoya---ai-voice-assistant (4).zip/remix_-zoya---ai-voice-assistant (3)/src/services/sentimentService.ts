import { ChatMessage } from "./memoryService";

export type SentimentPolarity = "positive" | "neutral" | "negative" | "intense";

export interface BossSentimentRecord {
  id: string;
  polarity: SentimentPolarity;
  score: number; // -100 to +100
  stressLevel: number; // 0 to 100
  energyLevel: number; // 0 to 100
  warmthLevel: number; // 0 to 100
  dominantMood: string;
  triggers: string[];
  insight: string;
  radhaGuidance: string;
  sourceText: string;
  createdAt: number;
}

const SENTIMENT_STORAGE_KEY = "radha_boss_sentiments_v1";

export function loadLocalSentiments(): BossSentimentRecord[] {
  try {
    const raw = localStorage.getItem(SENTIMENT_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

export function saveLocalSentiments(records: BossSentimentRecord[]): void {
  try {
    localStorage.setItem(SENTIMENT_STORAGE_KEY, JSON.stringify(records.slice(0, 50)));
  } catch {}
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

const POSITIVE_PATTERNS = [
  /खुश|मजा|मज़ा|बढ़िया|शाबाश|कमाल|वाह|प्यार|अच्छा|मस्त|धांसू|जबरदस्त|ज़बरदस्त/i,
  /\b(happy|awesome|great|amazing|love|nice|good|superb|best|win|thanks|thank you|mast|badhiya|shabaash|kamaal|khush|haha|hehe|lol)\b/i,
];

const ANGRY_INTENSE_PATTERNS = [
  /गुस्सा|चुप|बकवास|पागल|बेवकूफ|दिमाग खराब|प्रॉब्लम|खराब|गलत|फालतू|डांट|नाराज़|परेशान|बंद कर|बेकार/i,
  /\b(angry|mad|furious|stupid|idiot|shut up|broken|problem|issue|bug|error|annoying|hate|worst|bakwas|pagal|bewakoof|faltu|bekar|gussa|dimag kharab)\b/i,
];

const STRESS_SAD_PATTERNS = [
  /टेंशन|उदास|दुखी|थक|रोना|रो रहा|अकेला|तन्हा|दर्द|समस्या|डर|चिंता|नींद नहीं/i,
  /\b(stress|stressed|tension|sad|tired|exhausted|lonely|hurt|cry|crying|worried|anxious|depressed|pareshan|udaas|dukhi|thak)\b/i,
];

const WARM_PLAYFUL_PATTERNS = [
  /यार|सुनो|मेरी|प्यारी|राधा|दोस्त|मस्ती|मज़ाक|खेल|स्वीट/i,
  /\b(yaar|suno|radha|sweet|cute|friend|masti|mazak|joke|dear|boss|please|pls)\b/i,
];

/**
 * Instant zero-latency sentiment analyzer for Hindi / Hinglish / English Boss utterances.
 */
export function analyzeBossSentimentInstant(text: string): BossSentimentRecord {
  const clean = text.trim();
  let score = 8;
  let stressLevel = 22;
  let energyLevel = 52;
  let warmthLevel = 60;
  const triggers: string[] = [];

  const hasExclamation = /[!！]{1,}/.test(clean);
  const hasQuestion = /[?？]/.test(clean);
  const isAllCaps = clean.length >= 6 && clean === clean.toUpperCase() && /[A-Z]/.test(clean);

  if (hasExclamation) energyLevel += 16;
  if (isAllCaps) {
    energyLevel += 20;
    stressLevel += 18;
    triggers.push("HIGH_INTENSITY");
  }
  if (hasQuestion) energyLevel += 6;

  let posHits = 0;
  POSITIVE_PATTERNS.forEach((rx) => {
    const m = clean.match(rx);
    if (m) {
      posHits += 1;
      triggers.push(m[0].slice(0, 18));
    }
  });

  let angryHits = 0;
  ANGRY_INTENSE_PATTERNS.forEach((rx) => {
    const m = clean.match(rx);
    if (m) {
      angryHits += 1;
      triggers.push(m[0].slice(0, 18));
    }
  });

  let stressHits = 0;
  STRESS_SAD_PATTERNS.forEach((rx) => {
    const m = clean.match(rx);
    if (m) {
      stressHits += 1;
      triggers.push(m[0].slice(0, 18));
    }
  });

  let warmHits = 0;
  WARM_PLAYFUL_PATTERNS.forEach((rx) => {
    const m = clean.match(rx);
    if (m) {
      warmHits += 1;
    }
  });

  score += posHits * 28 + warmHits * 10 - angryHits * 34 - stressHits * 26;
  stressLevel += angryHits * 28 + stressHits * 30 - posHits * 12;
  energyLevel += posHits * 14 + angryHits * 18 - stressHits * 14;
  warmthLevel += posHits * 16 + warmHits * 15 - angryHits * 22;

  score = clamp(Math.round(score), -100, 100);
  stressLevel = clamp(Math.round(stressLevel), 5, 98);
  energyLevel = clamp(Math.round(energyLevel), 15, 98);
  warmthLevel = clamp(Math.round(warmthLevel), 10, 98);

  let polarity: SentimentPolarity = "neutral";
  let dominantMood = "Focused & Calm";
  let insight = "Boss normal, focused aur clear tone me baat kar rahe hain.";
  let radhaGuidance = "Respond sharply, warmly, and directly with confident Hinglish.";

  if (angryHits > 0 && score <= -20) {
    polarity = "intense";
    dominantMood = "Frustrated / Intense";
    insight = "Boss ki tone me frustration ya urgency detect hui hai.";
    radhaGuidance =
      "Acknowledge the issue directly; if scolded personally react naturally with human emotion, otherwise stay laser-focused and solve fast.";
  } else if (stressHits > 0 && score < 0) {
    polarity = "negative";
    dominantMood = "Stressed / Low";
    insight = "Boss thode tense, thake hue ya pareshan lag rahe hain.";
    radhaGuidance =
      "Switch immediately to deeply caring, reassuring, comforting Hindi/Hinglish tone and offer practical help.";
  } else if (score >= 28) {
    polarity = "positive";
    dominantMood = energyLevel >= 70 ? "Energetic & Happy" : "Warm & Positive";
    insight = "Boss ka mood kaafi positive aur upbeat hai!";
    radhaGuidance =
      "Match his cheerful energy, smile in your voice, and be lively and playful.";
  } else if (score <= -15) {
    polarity = "negative";
    dominantMood = "Concerned / Critical";
    insight = "Boss kisi problem ko lekar serious ya dissatisfied hain.";
    radhaGuidance = "Stay attentive, respectful, and solution-oriented.";
  }

  return {
    id: `sent-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    polarity,
    score,
    stressLevel,
    energyLevel,
    warmthLevel,
    dominantMood,
    triggers: Array.from(new Set(triggers)).slice(0, 4),
    insight,
    radhaGuidance,
    sourceText: clean.slice(0, 180),
    createdAt: Date.now(),
  };
}

/**
 * Server-backed Deep Gemini Sentiment Analysis + SQLite Persistence
 */
export async function analyzeBossSentimentDeep(
  text: string,
  recentMessages: ChatMessage[] = []
): Promise<BossSentimentRecord> {
  const instantFallback = analyzeBossSentimentInstant(text);
  try {
    const res = await fetch("/api/sentiment/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text,
        recentMessages: recentMessages.slice(-8),
        fallback: instantFallback,
      }),
    });
    if (!res.ok) return instantFallback;
    const data = await res.json();
    if (data.sentiment && typeof data.sentiment === "object") {
      return { ...instantFallback, ...data.sentiment };
    }
    return instantFallback;
  } catch {
    return instantFallback;
  }
}

export function buildBossSentimentContext(
  latest?: BossSentimentRecord | null,
  history: BossSentimentRecord[] = []
): string {
  const current = latest || history[0];
  if (!current) {
    return "No Boss sentiment reading recorded yet — monitor his live voice tone and words closely.";
  }

  const recentScores = history.slice(0, 5).map((r) => r.score);
  const avgScore =
    recentScores.length > 0
      ? Math.round(recentScores.reduce((a, b) => a + b, 0) / recentScores.length)
      : current.score;

  return [
    `- Live Polarity: ${current.polarity.toUpperCase()} (Score: ${current.score > 0 ? `+${current.score}` : current.score}/100, Trend Avg: ${avgScore > 0 ? `+${avgScore}` : avgScore})`,
    `- Dominant Mood: ${current.dominantMood}`,
    `- Stress: ${current.stressLevel}% | Energy: ${current.energyLevel}% | Warmth: ${current.warmthLevel}%`,
    `- Insight: ${current.insight}`,
    `- Adaptive Response Guidance: ${current.radhaGuidance}`,
  ].join("\n");
}
