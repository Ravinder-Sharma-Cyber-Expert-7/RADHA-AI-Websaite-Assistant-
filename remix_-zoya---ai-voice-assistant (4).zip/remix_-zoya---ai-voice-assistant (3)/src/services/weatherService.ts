export interface LiveWeatherData {
  city: string;
  country?: string;
  tempC: number;
  feelsLikeC: number;
  humidity: number;
  windKmh: number;
  weatherCode: number;
  conditionEn: string;
  conditionHi: string;
  iconKey: "sun" | "cloud-sun" | "cloud" | "fog" | "rain" | "storm" | "snow";
  isDay: boolean;
  lat: number;
  lon: number;
  fetchedAt: number;
}

const WEATHER_STORAGE_KEY = "radha_live_weather_v1";

export function decodeWmoWeatherCode(code: number): {
  conditionEn: string;
  conditionHi: string;
  iconKey: LiveWeatherData["iconKey"];
} {
  if (code === 0) return { conditionEn: "Clear Sky", conditionHi: "साफ़ आसमान", iconKey: "sun" };
  if (code === 1 || code === 2)
    return { conditionEn: "Partly Cloudy", conditionHi: "हल्के बादल", iconKey: "cloud-sun" };
  if (code === 3) return { conditionEn: "Overcast", conditionHi: "घने बादल", iconKey: "cloud" };
  if (code === 45 || code === 48)
    return { conditionEn: "Foggy", conditionHi: "कोहरा", iconKey: "fog" };
  if (code >= 51 && code <= 67)
    return { conditionEn: "Rainy", conditionHi: "बारिश", iconKey: "rain" };
  if (code >= 71 && code <= 77)
    return { conditionEn: "Snowfall", conditionHi: "बर्फ़बारी", iconKey: "snow" };
  if (code >= 80 && code <= 82)
    return { conditionEn: "Rain Showers", conditionHi: "तेज़ बौछारें", iconKey: "rain" };
  if (code >= 95)
    return { conditionEn: "Thunderstorm", conditionHi: "आंधी-तूफ़ान", iconKey: "storm" };
  return { conditionEn: "Clear", conditionHi: "सुहावना मौसम", iconKey: "cloud-sun" };
}

export function loadCachedWeather(): LiveWeatherData | null {
  try {
    const raw = localStorage.getItem(WEATHER_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as LiveWeatherData;
    if (typeof parsed?.tempC === "number" && parsed?.city) {
      syncGlobalWeatherContext(parsed);
      return parsed;
    }
  } catch {}
  return null;
}

function saveCachedWeather(data: LiveWeatherData) {
  try {
    localStorage.setItem(WEATHER_STORAGE_KEY, JSON.stringify(data));
  } catch {}
  syncGlobalWeatherContext(data);
}

export function syncGlobalWeatherContext(data: LiveWeatherData | null) {
  if (!data) return;
  (window as any).currentWeatherText = `${data.city}: ${data.tempC}°C (${data.conditionEn}, Humidity ${data.humidity}%, Wind ${data.windKmh} km/h)`;
}

export async function fetchWeatherByCoords(
  lat: number,
  lon: number,
  explicitCity?: string,
  explicitCountry?: string
): Promise<LiveWeatherData> {
  const weatherRes = await fetch(
    `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(
      lon
    )}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m&timezone=auto`
  );
  if (!weatherRes.ok) {
    throw new Error(`Weather forecast unavailable (${weatherRes.status})`);
  }
  const weatherJson = await weatherRes.json();
  const current = weatherJson?.current;
  if (!current || typeof current.temperature_2m !== "number") {
    throw new Error("Incomplete weather data returned.");
  }

  let city = explicitCity || "";
  let country = explicitCountry || "";

  if (!city) {
    try {
      const geoRes = await fetch(
        `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${encodeURIComponent(
          lat
        )}&longitude=${encodeURIComponent(lon)}&localityLanguage=en`
      );
      if (geoRes.ok) {
        const geo = await geoRes.json();
        city = geo.city || geo.locality || geo.principalSubdivision || "Your Location";
        country = geo.countryName || "";
      }
    } catch {
      city = "Your Location";
    }
  }

  const decoded = decodeWmoWeatherCode(Number(current.weather_code ?? 0));
  const data: LiveWeatherData = {
    city: city || "Your Location",
    country,
    tempC: Math.round(Number(current.temperature_2m)),
    feelsLikeC: Math.round(Number(current.apparent_temperature ?? current.temperature_2m)),
    humidity: Math.round(Number(current.relative_humidity_2m ?? 0)),
    windKmh: Math.round(Number(current.wind_speed_10m ?? 0)),
    weatherCode: Number(current.weather_code ?? 0),
    conditionEn: decoded.conditionEn,
    conditionHi: decoded.conditionHi,
    iconKey: decoded.iconKey,
    isDay: current.is_day !== 0,
    lat,
    lon,
    fetchedAt: Date.now(),
  };

  saveCachedWeather(data);
  return data;
}

export async function fetchWeatherByCity(cityQuery: string): Promise<LiveWeatherData> {
  const cleanCity = cityQuery.trim();
  if (!cleanCity) {
    return fetchCurrentLocationWeather();
  }

  const geoRes = await fetch(
    `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
      cleanCity
    )}&count=1&language=en&format=json`
  );
  if (!geoRes.ok) {
    throw new Error("Geocoding service unavailable.");
  }
  const geoJson = await geoRes.json();
  const match = geoJson?.results?.[0];
  if (!match) {
    throw new Error(`City "${cleanCity}" not found.`);
  }

  return fetchWeatherByCoords(
    Number(match.latitude),
    Number(match.longitude),
    match.name,
    match.country || ""
  );
}

export async function fetchCurrentLocationWeather(): Promise<LiveWeatherData> {
  const coords = await new Promise<{ lat: number; lon: number } | null>((resolve) => {
    if (!("geolocation" in navigator)) {
      resolve(null);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      () => resolve(null),
      { enableHighAccuracy: false, timeout: 5500, maximumAge: 300_000 }
    );
  });

  if (coords) {
    return fetchWeatherByCoords(coords.lat, coords.lon);
  }

  // Fallback to live public IP city lookup (100% real Open-Meteo data, never fabricated)
  try {
    const ipRes = await fetch("https://ipapi.co/json/");
    if (ipRes.ok) {
      const ipData = await ipRes.json();
      if (typeof ipData?.latitude === "number" && typeof ipData?.longitude === "number") {
        return fetchWeatherByCoords(
          ipData.latitude,
          ipData.longitude,
          ipData.city || ipData.region || "India",
          ipData.country_name || ""
        );
      }
    }
  } catch {}

  // Last resort real Open-Meteo lookup for New Delhi
  return fetchWeatherByCoords(28.6139, 77.209, "New Delhi", "India");
}

/**
 * Detects Hindi, Hinglish, and English voice queries asking for live weather.
 * Returns `{ matched: true, city?: string }` when Boss asks about the weather.
 */
export function detectWeatherVoiceQuery(text: string): { matched: boolean; city?: string } {
  const clean = text.trim();
  if (!clean) return { matched: false };

  const hasWeatherKeyword =
    /\b(weather|mausam|mosam|temperature|temp|forecast|baarish|barish|rain|garmi|sardi)\b|मौसम|तापमान|बारिश|ठंड|गर्मी/i.test(
      clean
    );
  if (!hasWeatherKeyword) return { matched: false };

  // Avoid catching unrelated emotional sentences like "mera mood kharab hai"
  // Extract explicit city name if Boss asked e.g. "Delhi ka weather batao", "weather in Mumbai", "जयपुर का मौसम"
  const cityPatterns: RegExp[] = [
    /(?:weather|mausam|mosam|temperature|temp)\s+(?:in|of|at|for)\s+([a-zA-Z\s]{2,28})/i,
    /([a-zA-Z]{2,24}(?:\s+[a-zA-Z]{2,18})?)\s+(?:ka|ki|ke|mein|me)\s+(?:weather|mausam|mosam|temperature|temp|haal)/i,
    /([\u0900-\u097F]{2,24})\s+(?:का|की|के|में)\s+(?:मौसम|तापमान)/i,
  ];

  const stopWords = new Set([
    "aaj",
    "abhi",
    "kal",
    "yahan",
    "yaha",
    "bahar",
    "mera",
    "mere",
    "radha",
    "boss",
    "today",
    "now",
    "here",
    "current",
    "live",
    "आज",
    "अभी",
    "यहाँ",
    "बाहर",
    "राधा",
  ]);

  for (const regex of cityPatterns) {
    const m = clean.match(regex);
    if (m?.[1]) {
      const candidate = m[1]
        .replace(/^(?:radha|राधा|hey|please|batao|bata|tell me|what is|kaisa hai)\s+/i, "")
        .trim();
      const lowerCand = candidate.toLowerCase();
      if (candidate.length >= 2 && !stopWords.has(lowerCand)) {
        return { matched: true, city: candidate };
      }
    }
  }

  return { matched: true };
}

export function formatWeatherHindiReply(weather: LiveWeatherData, ownerName: string = "बॉस"): string {
  const rainTip =
    weather.iconKey === "rain" || weather.iconKey === "storm"
      ? " बाहर निकलते वक्त छाता साथ रख लीजिएगा।"
      : weather.tempC >= 36
      ? " आज धूप तेज़ है, पानी ज़्यादा पीजिएगा।"
      : weather.tempC <= 14
      ? " थोड़ा ठंडा मौसम है, गर्म कपड़े पहन कर रखिएगा।"
      : "";

  return `${ownerName}, अभी ${weather.city} का मौसम ${weather.conditionHi} है। तापमान ${weather.tempC}°C है (महसूस ${weather.feelsLikeC}°C), नमी ${weather.humidity}% और हवा ${weather.windKmh} किलोमीटर प्रति घंटा चल रही है।${rainTip}`;
}
