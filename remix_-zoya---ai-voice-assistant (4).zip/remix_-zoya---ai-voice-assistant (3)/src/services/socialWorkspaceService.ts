import {
  fetchRecentEmails,
  getWorkspaceAccessToken,
  GmailMessageSummary,
} from "./workspaceService";

export interface SocialWorkspaceConfig {
  instagramHandle: string;
  instagramAccountId: string;
  instagramAccessToken: string;
  instagramWebhookUrl: string;
  facebookPageName: string;
  facebookPageId: string;
  facebookAccessToken: string;
  facebookWebhookUrl: string;
  gmailWebhookUrl: string;
}

export interface InstagramInsights {
  mode: "live" | "demo";
  handle: string;
  followers: number;
  recentVideoViews: number;
  lastUploadAt: string;
  engagementRate: string;
  summary: string;
  error?: string;
}

export interface FacebookInboxInsights {
  mode: "live" | "demo";
  pageName: string;
  unreadCount: number;
  notifications: Array<{ id: string; sender: string; text: string; time: string }>;
  error?: string;
}

export interface GmailInboxInsights {
  mode: "live" | "demo";
  unreadCount: number;
  messages: Array<{ id: string; from: string; subject: string; snippet: string; date: string }>;
  error?: string;
}

export interface SocialWorkspaceSnapshot {
  updatedAt: number;
  instagram: InstagramInsights;
  gmail: GmailInboxInsights;
  facebook: FacebookInboxInsights;
}

const CONFIG_STORAGE_KEY = "radha_social_workspace_cfg_v1";

export const DEFAULT_SOCIAL_WORKSPACE_CONFIG: SocialWorkspaceConfig = {
  instagramHandle: "@ravinder_boss",
  instagramAccountId: "",
  instagramAccessToken: "",
  instagramWebhookUrl: "",
  facebookPageName: "Ravindra Boss Official",
  facebookPageId: "",
  facebookAccessToken: "",
  facebookWebhookUrl: "",
  gmailWebhookUrl: "",
};

export function loadSocialWorkspaceConfig(): SocialWorkspaceConfig {
  try {
    const raw = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (!raw) return DEFAULT_SOCIAL_WORKSPACE_CONFIG;
    return { ...DEFAULT_SOCIAL_WORKSPACE_CONFIG, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SOCIAL_WORKSPACE_CONFIG;
  }
}

export function saveSocialWorkspaceConfig(cfg: SocialWorkspaceConfig): void {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(cfg));
  } catch {}
}

export function getDemoSocialWorkspaceSnapshot(
  cfg: SocialWorkspaceConfig = loadSocialWorkspaceConfig()
): SocialWorkspaceSnapshot {
  return {
    updatedAt: Date.now(),
    instagram: {
      mode: "demo",
      handle: cfg.instagramHandle || "@ravinder_boss",
      followers: 14820,
      recentVideoViews: 9430,
      lastUploadAt: "Yesterday · 8:40 PM",
      engagementRate: "6.4%",
      summary: "Reel reach trending +18% vs last week (Connect Instagram Graph API for live metrics).",
    },
    gmail: {
      mode: "demo",
      unreadCount: 3,
      messages: [
        {
          id: "demo-g1",
          from: "Hardware Lab Supplier",
          subject: "ESP32-S3 DevKit Shipment Dispatched",
          snippet: "Your hardware prototyping modules are scheduled for delivery tomorrow.",
          date: "Today",
        },
        {
          id: "demo-g2",
          from: "Cloud Security Digest",
          subject: "Weekly API & Workspace Activity Summary",
          snippet: "All endpoints healthy with zero unauthorized login attempts.",
          date: "Today",
        },
        {
          id: "demo-g3",
          from: "Creator Studio",
          subject: "Audience Growth Milestone Unlocked",
          snippet: "Connect Gmail OAuth in Setup to view your live unread inbox here.",
          date: "Yesterday",
        },
      ],
    },
    facebook: {
      mode: "demo",
      pageName: cfg.facebookPageName || "Ravindra Boss Official",
      unreadCount: 2,
      notifications: [
        {
          id: "demo-f1",
          sender: "Page Messenger",
          text: "New collaboration inquiry received on your creator page.",
          time: "42m ago",
        },
        {
          id: "demo-f2",
          sender: "Community Comment",
          text: "14 new comments on your latest tech reel (Connect Graph Token for live sync).",
          time: "2h ago",
        },
      ],
    },
  };
}

export async function fetchSocialWorkspaceSnapshot(
  cfg: SocialWorkspaceConfig = loadSocialWorkspaceConfig()
): Promise<SocialWorkspaceSnapshot> {
  const demo = getDemoSocialWorkspaceSnapshot(cfg);

  // 1. Instagram (Live Graph API / Webhook via server proxy, or Ready-to-Connect demo)
  let instagram: InstagramInsights = demo.instagram;
  if ((cfg.instagramAccountId && cfg.instagramAccessToken) || cfg.instagramWebhookUrl) {
    try {
      const res = await fetch("/api/social/instagram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accountId: cfg.instagramAccountId,
          accessToken: cfg.instagramAccessToken,
          webhookUrl: cfg.instagramWebhookUrl,
          handle: cfg.instagramHandle,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.mode === "live") {
          instagram = data;
        }
      }
    } catch {
      instagram = {
        ...demo.instagram,
        error: "Live Instagram sync temporarily unreachable — showing preview.",
      };
    }
  }

  // 2. Gmail (Reuses Radha's real Google Workspace OAuth token automatically when signed in!)
  let gmail: GmailInboxInsights = demo.gmail;
  if (getWorkspaceAccessToken()) {
    try {
      const liveEmails: GmailMessageSummary[] = await fetchRecentEmails(5);
      gmail = {
        mode: "live",
        unreadCount: liveEmails.length,
        messages: liveEmails.map((m) => ({
          id: m.id,
          from: m.from.replace(/<[^>]+>/g, "").trim() || m.from,
          subject: m.subject,
          snippet: m.snippet,
          date: m.date,
        })),
      };
    } catch {
      gmail = {
        ...demo.gmail,
        error: "Gmail OAuth token expired — reconnect Gmail for live sync.",
      };
    }
  }

  // 3. Facebook (Live Graph API / Webhook via server proxy, or Ready-to-Connect demo)
  let facebook: FacebookInboxInsights = demo.facebook;
  if ((cfg.facebookPageId && cfg.facebookAccessToken) || cfg.facebookWebhookUrl) {
    try {
      const res = await fetch("/api/social/facebook", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pageId: cfg.facebookPageId,
          accessToken: cfg.facebookAccessToken,
          webhookUrl: cfg.facebookWebhookUrl,
          pageName: cfg.facebookPageName,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data && data.mode === "live") {
          facebook = data;
        }
      }
    } catch {
      facebook = {
        ...demo.facebook,
        error: "Live Facebook sync temporarily unreachable — showing preview.",
      };
    }
  }

  return {
    updatedAt: Date.now(),
    instagram,
    gmail,
    facebook,
  };
}

export function buildSocialWorkspaceVoiceBriefing(
  snapshot: SocialWorkspaceSnapshot,
  platform: "all" | "instagram" | "gmail" | "facebook" = "all"
): string {
  const ig = snapshot.instagram;
  const gm = snapshot.gmail;
  const fb = snapshot.facebook;

  const igLine =
    ig.mode === "live"
      ? `इंस्टाग्राम (${ig.handle}) पर आपके कुल ${ig.followers.toLocaleString("en-IN")} फॉलोअर्स हैं, हाल की वीडियो पर ${ig.recentVideoViews.toLocaleString("en-IN")} व्यूज़ आए हैं, लास्ट अपलोड ${ig.lastUploadAt} का है और एंगेजमेंट ${ig.engagementRate} चल रहा है।`
      : `इंस्टाग्राम अभी रेडी-टू-कनेक्ट प्रीव्यू मोड में है — प्रीव्यू में ${ig.followers.toLocaleString("en-IN")} फॉलोअर्स और ${ig.recentVideoViews.toLocaleString("en-IN")} वीडियो व्यूज़ दिख रहे हैं; आप Insights पैनल में अपना Instagram ID और टोकन डालकर लाइव डेटा चालू कर सकते हैं।`;

  const gmTop = gm.messages[0] ? ` सबसे नया ईमेल "${gm.messages[0].subject}" है।` : "";
  const gmLine =
    gm.mode === "live"
      ? `जीमेल इनबॉक्स लाइव कनेक्ट है, जिसमें ${gm.unreadCount} महत्वपूर्ण मैसेज दिख रहे हैं।${gmTop}`
      : `जीमेल अभी प्रीव्यू मोड में है (${gm.unreadCount} सैंपल अलर्ट) — लाइव ईमेल पढ़ने के लिए Google Workspace कनेक्ट करें।`;

  const fbLine =
    fb.mode === "live"
      ? `फेसबुक पेज (${fb.pageName}) पर ${fb.unreadCount} नए नोटिफिकेशन या मैसेज आए हुए हैं।`
      : `फेसबुक मॉनिटर अभी प्रीव्यू मोड में है (${fb.unreadCount} सैंपल नोटिफिकेशन) — Insights सेटअप में पेज टोकन जोड़ते ही लाइव अपडेट शुरू हो जाएगा।`;

  if (platform === "instagram") return `बॉस, ${igLine}`;
  if (platform === "gmail") return `बॉस, ${gmLine}`;
  if (platform === "facebook") return `बॉस, ${fbLine}`;

  return `बॉस, आपका डिजिटल वर्कस्पेस ब्रीफिंग तैयार है। ${igLine} ${gmLine} ${fbLine}`;
}

export function buildSocialWorkspaceContext(snapshot?: SocialWorkspaceSnapshot | null): string {
  if (!snapshot) return "Digital Workspace Monitor: Ready (open Insights side-panel to connect Instagram/Gmail/Facebook).";
  const { instagram: ig, gmail: gm, facebook: fb } = snapshot;
  return `SOCIAL MEDIA & WORKSPACE INSIGHTS SNAPSHOT:
- Instagram (${ig.handle}, ${ig.mode.toUpperCase()}): ${ig.followers} followers, ${ig.recentVideoViews} recent video views, last upload: ${ig.lastUploadAt}, engagement: ${ig.engagementRate}. ${ig.summary}
- Gmail (${gm.mode.toUpperCase()}): ${gm.unreadCount} important messages. Top subject: "${gm.messages[0]?.subject || "None"}".
- Facebook (${fb.pageName}, ${fb.mode.toUpperCase()}): ${fb.unreadCount} unread notifications/messages. Latest: "${fb.notifications[0]?.text || "None"}".
- If Boss asks for Instagram, Gmail, Facebook, or daily digital briefing updates, read these stats clearly in natural Hindi (and mention if a channel is in Preview/Ready-to-Connect mode).`;
}

export function detectSocialBriefingQuery(
  text: string
): "all" | "instagram" | "gmail" | "facebook" | null {
  const lower = text.toLowerCase();
  const asksUpdate =
    /\b(update|status|report|briefing|check|kitne|followers|views|unread|notifications|messages|summary|kya haal|batao)\b|अपडेट|स्टेटस|बताओ|चेक|फॉलोअर्स|व्यूज|मैसेज|ब्रीफिंग/i.test(
      lower
    );
  if (!asksUpdate) return null;

  const hasIg = /\b(instagram|insta|ig|reel|reels|followers)\b|इंस्टाग्राम|इंस्टा/i.test(lower);
  const hasGmail = /\b(gmail|email|mail|inbox)\b|जीमेल|ईमेल|मेल/i.test(lower);
  const hasFb = /\b(facebook|fb)\b|फेसबुक/i.test(lower);
  const hasBriefing =
    /\b(social media|workspace briefing|morning briefing|evening briefing|digital briefing|insights)\b|सोशल मीडिया|ब्रीफिंग/i.test(
      lower
    );

  if (hasBriefing || (hasIg && (hasGmail || hasFb))) return "all";
  if (hasIg) return "instagram";
  if (hasGmail) return "gmail";
  if (hasFb) return "facebook";
  return null;
}
