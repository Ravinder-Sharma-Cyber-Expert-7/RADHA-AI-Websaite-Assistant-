import React, { useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Activity,
  AlarmClock,
  Battery,
  BatteryCharging,
  Cloud,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Flame,
  Footprints,
  HeartPulse,
  Link2,
  MapPin,
  Mic,
  MicOff,
  NotebookPen,
  Plus,
  Power,
  Radio,
  RefreshCw,
  Search,
  ShieldCheck,
  Smartphone,
  Sun,
  Trash2,
  Upload,
  Volume2,
  VolumeX,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { RadhaConfig, ReminderItem } from "../services/memoryService";
import { LiveWeatherData } from "../services/weatherService";
import { DeviceBatteryStatus, VoiceNoteItem } from "../services/deviceCareService";
import { BiologicalStatusData } from "../services/fitnessService";

interface CommandDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  config: RadhaConfig;
  isSystemActive: boolean;
  onToggleSystemActive: () => void;
  weather: LiveWeatherData | null;
  isWeatherLoading: boolean;
  onRefreshWeather: (city?: string) => void;
  onSpeakWeather: () => void;
  voiceNotes: VoiceNoteItem[];
  onAddVoiceNote: (content: string) => void;
  onDeleteVoiceNote: (id: string) => void;
  reminders: ReminderItem[];
  onCreateQuickReminder: (title: string, delayMinutes: number) => void;
  onDeleteReminder: (id: string) => void;
  battery: DeviceBatteryStatus;
  isOnline: boolean;
  wakeLockActive: boolean;
  wakeWordEnabled: boolean;
  onToggleWakeWord: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  isMicMuted: boolean;
  onToggleMicMute: () => void;
  biologicalStatus: BiologicalStatusData;
  isSyncingBio: boolean;
  onConnectGoogleFit: () => void;
  onImportAppleHealthFile: (file: File) => void;
  onSyncHealthWebhook: (url: string) => void;
  onDisconnectBio: () => void;
  onUpdateConfig: (next: RadhaConfig) => void;
}

type DrawerSection = "weather" | "notes" | "device" | "bio";

function WeatherGlyph({ iconKey, size = 18 }: { iconKey?: LiveWeatherData["iconKey"]; size?: number }) {
  switch (iconKey) {
    case "sun":
      return <Sun size={size} className="text-amber-400" />;
    case "cloud":
      return <Cloud size={size} className="text-slate-300" />;
    case "fog":
      return <CloudFog size={size} className="text-slate-300" />;
    case "rain":
      return <CloudRain size={size} className="text-sky-400" />;
    case "storm":
      return <CloudLightning size={size} className="text-yellow-400" />;
    case "snow":
      return <CloudSnow size={size} className="text-cyan-200" />;
    default:
      return <CloudSun size={size} className="text-amber-300" />;
  }
}

export default function CommandDrawer({
  isOpen,
  onClose,
  config,
  isSystemActive,
  onToggleSystemActive,
  weather,
  isWeatherLoading,
  onRefreshWeather,
  onSpeakWeather,
  voiceNotes,
  onAddVoiceNote,
  onDeleteVoiceNote,
  reminders,
  onCreateQuickReminder,
  onDeleteReminder,
  battery,
  isOnline,
  wakeLockActive,
  wakeWordEnabled,
  onToggleWakeWord,
  isMuted,
  onToggleMute,
  isMicMuted,
  onToggleMicMute,
  biologicalStatus,
  isSyncingBio,
  onConnectGoogleFit,
  onImportAppleHealthFile,
  onSyncHealthWebhook,
  onDisconnectBio,
  onUpdateConfig,
}: CommandDrawerProps) {
  const [section, setSection] = useState<DrawerSection>("weather");
  const [cityQuery, setCityQuery] = useState("");
  const [noteDraft, setNoteDraft] = useState("");
  const [reminderTitle, setReminderTitle] = useState("");
  const [reminderMins, setReminderMins] = useState("10");
  const [webhookUrl, setWebhookUrl] = useState("");
  const appleFileInputRef = useRef<HTMLInputElement | null>(null);

  const primary = config.primaryColor || "#00ff9d";
  const secondary = config.secondaryColor || "#00e5ff";

  const activeReminders = reminders.filter((r) => !r.completed);

  const handleCitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cityQuery.trim()) return;
    onRefreshWeather(cityQuery.trim());
    setCityQuery("");
  };

  const handleAddNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteDraft.trim()) return;
    onAddVoiceNote(noteDraft.trim());
    setNoteDraft("");
  };

  const handleAddReminderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mins = Math.max(1, Number(reminderMins) || 10);
    if (!reminderTitle.trim()) return;
    onCreateQuickReminder(reminderTitle.trim(), mins);
    setReminderTitle("");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Soft backdrop for mobile / APK tap-to-close */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/55 backdrop-blur-sm z-40"
          />

          <motion.aside
            initial={{ x: "-100%", opacity: 0.4 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "-100%", opacity: 0.4 }}
            transition={{ type: "spring", damping: 28, stiffness: 240 }}
            className="fixed top-0 left-0 h-[100dvh] w-[92vw] max-w-[390px] bg-[#040c10]/95 backdrop-blur-2xl border-r z-50 flex flex-col shadow-2xl font-mono text-white"
            style={{ borderColor: `${primary}35` }}
          >
            {/* Drawer Header */}
            <div
              className="flex items-center justify-between px-4 py-3.5 border-b shrink-0"
              style={{ borderColor: `${primary}25`, backgroundColor: `${primary}0c` }}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div
                  className="w-2.5 h-2.5 rounded-full shrink-0"
                  style={{
                    backgroundColor: isSystemActive ? primary : "#64748b",
                    boxShadow: isSystemActive ? `0 0 12px ${primary}` : "none",
                  }}
                />
                <div className="min-w-0">
                  <h2 className="text-xs font-bold uppercase tracking-widest truncate" style={{ color: primary }}>
                    Command Drawer
                  </h2>
                  <p className="text-[10px] text-white/50 truncate">
                    {isSystemActive ? "System Active · Ready" : "Standby · Tap Start to Activate"}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-colors cursor-pointer"
                aria-label="Close Command Drawer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Section Tabs */}
            <div className="grid grid-cols-4 gap-1 p-2 border-b border-white/10 bg-black/30 shrink-0">
              {(
                [
                  { id: "weather", label: "Weather", icon: CloudSun },
                  { id: "notes", label: "Notes", icon: NotebookPen },
                  { id: "bio", label: "Bio Fit", icon: HeartPulse },
                  { id: "device", label: "Device", icon: Smartphone },
                ] as const
              ).map((tab) => {
                const Icon = tab.icon;
                const active = section === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setSection(tab.id)}
                    className={`flex flex-col items-center justify-center gap-1 py-2 px-1 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                      active ? "text-black" : "text-white/60 hover:text-white bg-white/[0.03]"
                    }`}
                    style={active ? { backgroundColor: primary } : undefined}
                  >
                    <Icon size={13} />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin">
              {section === "weather" && (
                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="p-2 rounded-lg bg-black/50 border border-white/10 shrink-0">
                          <WeatherGlyph iconKey={weather?.iconKey} size={22} />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1 text-xs font-bold text-white truncate">
                            <MapPin size={11} style={{ color: secondary }} />
                            <span>{weather?.city || "Detecting Location..."}</span>
                          </div>
                          <div className="text-[11px] text-white/60">
                            {weather ? `${weather.conditionHi} · ${weather.conditionEn}` : "Live Open-Meteo Feed"}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onRefreshWeather()}
                        disabled={isWeatherLoading}
                        className="p-2 rounded-lg bg-white/5 hover:bg-white/15 text-white/75 cursor-pointer disabled:opacity-40"
                        title="Refresh GPS Weather"
                      >
                        <RefreshCw size={13} className={isWeatherLoading ? "animate-spin" : ""} />
                      </button>
                    </div>

                    {weather ? (
                      <>
                        <div className="flex items-baseline justify-between pt-1">
                          <div className="text-3xl font-bold tabular-nums" style={{ color: primary }}>
                            {weather.tempC}°C
                          </div>
                          <div className="text-[11px] text-white/60 tabular-nums">
                            Feels like {weather.feelsLikeC}°C
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10 text-[11px] tabular-nums">
                          <div className="p-2 rounded-lg bg-black/40 border border-white/[0.06]">
                            <div className="text-[9.5px] text-white/45">Humidity</div>
                            <div className="font-bold text-cyan-300">{weather.humidity}%</div>
                          </div>
                          <div className="p-2 rounded-lg bg-black/40 border border-white/[0.06]">
                            <div className="text-[9.5px] text-white/45">Wind Speed</div>
                            <div className="font-bold text-emerald-300">{weather.windKmh} km/h</div>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={onSpeakWeather}
                          className="w-full py-2 px-3 rounded-lg text-[11px] font-bold text-black flex items-center justify-center gap-2 cursor-pointer"
                          style={{ backgroundColor: secondary }}
                        >
                          <Volume2 size={13} />
                          <span>Radha se Mausam Suno</span>
                        </button>
                      </>
                    ) : (
                      <div className="text-xs text-white/55 py-2">
                        {isWeatherLoading
                          ? "Fetching real live weather..."
                          : "Tap refresh or search any city below."}
                      </div>
                    )}
                  </div>

                  {/* City Weather Search */}
                  <form onSubmit={handleCitySubmit} className="flex gap-2">
                    <div className="flex-1 flex items-center gap-2 px-3 py-2 rounded-xl bg-black/60 border border-white/15">
                      <Search size={13} className="text-white/45 shrink-0" />
                      <input
                        type="text"
                        value={cityQuery}
                        onChange={(e) => setCityQuery(e.target.value)}
                        placeholder="Search city (e.g. Delhi, Mumbai)..."
                        className="w-full bg-transparent outline-none text-xs text-white placeholder:text-white/35"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={!cityQuery.trim() || isWeatherLoading}
                      className="px-3 py-2 rounded-xl text-xs font-bold text-black disabled:opacity-40 cursor-pointer"
                      style={{ backgroundColor: primary }}
                    >
                      Go
                    </button>
                  </form>
                </div>
              )}

              {section === "notes" && (
                <div className="space-y-4">
                  {/* Voice Notes */}
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-white/85 flex items-center gap-1.5">
                        <NotebookPen size={13} style={{ color: primary }} />
                        <span>Voice Notes ({voiceNotes.length})</span>
                      </span>
                      <span className="text-[9.5px] text-white/45">Saved locally</span>
                    </div>

                    <form onSubmit={handleAddNoteSubmit} className="flex gap-1.5">
                      <input
                        type="text"
                        value={noteDraft}
                        onChange={(e) => setNoteDraft(e.target.value)}
                        placeholder='Say "नोट लिखो..." or type note'
                        className="flex-1 px-2.5 py-2 rounded-lg bg-black/60 border border-white/15 text-xs outline-none text-white placeholder:text-white/35"
                      />
                      <button
                        type="submit"
                        disabled={!noteDraft.trim()}
                        className="p-2 rounded-lg text-black disabled:opacity-40 cursor-pointer"
                        style={{ backgroundColor: primary }}
                        aria-label="Add note"
                      >
                        <Plus size={14} />
                      </button>
                    </form>

                    {voiceNotes.length === 0 ? (
                      <p className="text-[11px] text-white/45 py-2 text-center">
                        No voice notes yet. Say &ldquo;राधा, नोट लिखो...&rdquo;
                      </p>
                    ) : (
                      <div className="space-y-1.5 max-h-48 overflow-y-auto scrollbar-thin pr-1">
                        {voiceNotes.map((note) => (
                          <div
                            key={note.id}
                            className="p-2 rounded-lg bg-black/45 border border-white/10 flex items-start justify-between gap-2"
                          >
                            <div className="min-w-0">
                              <p className="text-xs text-white/90 break-words">{note.content}</p>
                              <p className="text-[9px] text-white/40 mt-0.5">
                                {new Date(note.createdAt).toLocaleString("hi-IN", {
                                  day: "numeric",
                                  month: "short",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => onDeleteVoiceNote(note.id)}
                              className="p-1 text-white/40 hover:text-red-400 cursor-pointer shrink-0"
                              aria-label="Delete note"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Quick Voice Reminders / Alarms */}
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-white/85 flex items-center gap-1.5">
                        <AlarmClock size={13} style={{ color: secondary }} />
                        <span>Active Alarms ({activeReminders.length})</span>
                      </span>
                    </div>

                    <form onSubmit={handleAddReminderSubmit} className="flex gap-1.5">
                      <input
                        type="text"
                        value={reminderTitle}
                        onChange={(e) => setReminderTitle(e.target.value)}
                        placeholder="Reminder title..."
                        className="flex-1 min-w-0 px-2.5 py-2 rounded-lg bg-black/60 border border-white/15 text-xs outline-none text-white placeholder:text-white/35"
                      />
                      <input
                        type="number"
                        min={1}
                        max={720}
                        value={reminderMins}
                        onChange={(e) => setReminderMins(e.target.value)}
                        className="w-14 px-2 py-2 rounded-lg bg-black/60 border border-white/15 text-xs text-center outline-none text-white tabular-nums"
                        title="Minutes from now"
                      />
                      <button
                        type="submit"
                        disabled={!reminderTitle.trim()}
                        className="px-2.5 py-2 rounded-lg text-[11px] font-bold text-black disabled:opacity-40 cursor-pointer shrink-0"
                        style={{ backgroundColor: secondary }}
                      >
                        Set
                      </button>
                    </form>

                    {activeReminders.length === 0 ? (
                      <p className="text-[11px] text-white/45 py-1 text-center">
                        Say &ldquo;10 मिनट बाद याद दिलाना...&rdquo;
                      </p>
                    ) : (
                      <div className="space-y-1.5 max-h-40 overflow-y-auto scrollbar-thin pr-1">
                        {activeReminders.map((rem) => (
                          <div
                            key={rem.id}
                            className="p-2 rounded-lg bg-black/45 border border-white/10 flex items-center justify-between gap-2"
                          >
                            <div className="min-w-0">
                              <div className="text-xs text-white/90 truncate">{rem.title}</div>
                              <div className="text-[9.5px] text-cyan-300/80 tabular-nums">
                                {new Date(rem.triggerAt).toLocaleTimeString([], {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </div>
                            </div>
                            <button
                              type="button"
                              onClick={() => onDeleteReminder(rem.id)}
                              className="p-1 text-white/40 hover:text-red-400 cursor-pointer"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {section === "bio" && (
                <div className="space-y-3">
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                        <Activity size={14} style={{ color: primary }} />
                        <span>Biological Status</span>
                      </span>
                      <span
                        className="text-[10px] font-bold"
                        style={{
                          color:
                            biologicalStatus.source !== "disconnected"
                              ? primary
                              : "rgba(255,255,255,0.45)",
                        }}
                      >
                        {biologicalStatus.source !== "disconnected"
                          ? biologicalStatus.connectedLabel
                          : "Not Connected"}
                      </span>
                    </div>

                    {biologicalStatus.source !== "disconnected" ? (
                      <div className="grid grid-cols-2 gap-2 tabular-nums">
                        <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                          <div className="text-[10px] text-white/50 flex items-center gap-1">
                            <Footprints size={11} style={{ color: primary }} />
                            <span>Steps</span>
                          </div>
                          <div className="text-base font-bold mt-0.5" style={{ color: primary }}>
                            {biologicalStatus.steps !== null
                              ? biologicalStatus.steps.toLocaleString()
                              : "--"}
                          </div>
                        </div>
                        <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                          <div className="text-[10px] text-white/50 flex items-center gap-1">
                            <HeartPulse size={11} className="text-rose-400" />
                            <span>Heart Rate</span>
                          </div>
                          <div className="text-base font-bold mt-0.5 text-rose-300">
                            {biologicalStatus.heartRateBpm !== null
                              ? `${biologicalStatus.heartRateBpm} BPM`
                              : "--"}
                          </div>
                        </div>
                        <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                          <div className="text-[10px] text-white/50 flex items-center gap-1">
                            <Flame size={11} className="text-amber-400" />
                            <span>Calories</span>
                          </div>
                          <div className="text-base font-bold mt-0.5 text-amber-300">
                            {biologicalStatus.caloriesKcal !== null
                              ? `${biologicalStatus.caloriesKcal} kcal`
                              : "--"}
                          </div>
                        </div>
                        <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                          <div className="text-[10px] text-white/50">Active / Dist</div>
                          <div className="text-base font-bold mt-0.5 text-cyan-300">
                            {biologicalStatus.activeMinutes !== null
                              ? `${biologicalStatus.activeMinutes} min`
                              : biologicalStatus.distanceKm !== null
                              ? `${biologicalStatus.distanceKm} km`
                              : "--"}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-[11px] text-white/55 leading-relaxed">
                        Connect your real Google Fit account or import an Apple Health export file (.xml / .json) to monitor real activity metrics with zero mock data.
                      </p>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={onConnectGoogleFit}
                        disabled={isSyncingBio}
                        className="py-2 px-2.5 rounded-lg text-[11px] font-bold text-black flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                        style={{ backgroundColor: primary }}
                      >
                        <Link2 size={13} />
                        <span>{isSyncingBio ? "Syncing..." : "Google Fit"}</span>
                      </button>

                      <input
                        ref={appleFileInputRef}
                        type="file"
                        accept=".xml,.json"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            onImportAppleHealthFile(file);
                            e.target.value = "";
                          }
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => appleFileInputRef.current?.click()}
                        disabled={isSyncingBio}
                        className="py-2 px-2.5 rounded-lg text-[11px] font-semibold bg-white/10 hover:bg-white/15 border border-white/15 text-white flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <Upload size={13} />
                        <span>Apple Health</span>
                      </button>
                    </div>

                    {/* Optional Real HTTPS Apple Health Webhook Feed */}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (webhookUrl.trim()) {
                          onSyncHealthWebhook(webhookUrl.trim());
                          setWebhookUrl("");
                        }
                      }}
                      className="flex gap-1.5 pt-1"
                    >
                      <input
                        type="url"
                        value={webhookUrl}
                        onChange={(e) => setWebhookUrl(e.target.value)}
                        placeholder="https://... Health Auto Export JSON"
                        className="flex-1 min-w-0 px-2.5 py-1.5 rounded-lg bg-black/60 border border-white/15 text-[11px] outline-none text-white placeholder:text-white/35"
                      />
                      <button
                        type="submit"
                        disabled={!webhookUrl.trim() || isSyncingBio}
                        className="px-2.5 py-1.5 rounded-lg text-[10px] font-bold bg-white/10 hover:bg-white/20 text-white disabled:opacity-40 cursor-pointer"
                      >
                        Sync
                      </button>
                    </form>

                    {biologicalStatus.source !== "disconnected" && (
                      <button
                        type="button"
                        onClick={onDisconnectBio}
                        className="w-full py-1.5 rounded-lg text-[10px] text-red-300 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 cursor-pointer"
                      >
                        Clear Synced Health Data
                      </button>
                    )}
                  </div>
                </div>
              )}

              {section === "device" && (
                <div className="space-y-3">
                  {/* Live Hardware Telemetry */}
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 space-y-2.5">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-white/80">
                      Real Device Telemetry
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs tabular-nums">
                      <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                        <div className="text-[10px] text-white/45 flex items-center gap-1">
                          {battery.charging ? (
                            <BatteryCharging size={12} className="text-emerald-400" />
                          ) : (
                            <Battery
                              size={12}
                              className={
                                battery.level !== null && battery.level < 20
                                  ? "text-red-400"
                                  : "text-emerald-400"
                              }
                            />
                          )}
                          <span>Battery</span>
                        </div>
                        <div className="font-bold mt-0.5">
                          {battery.supported && battery.level !== null
                            ? `${battery.level}% ${battery.charging ? "(Charging)" : ""}`
                            : "AC / N/A"}
                        </div>
                      </div>

                      <div className="p-2.5 rounded-lg bg-black/50 border border-white/10">
                        <div className="text-[10px] text-white/45 flex items-center gap-1">
                          {isOnline ? (
                            <Wifi size={12} className="text-emerald-400" />
                          ) : (
                            <WifiOff size={12} className="text-red-400" />
                          )}
                          <span>Network</span>
                        </div>
                        <div
                          className={`font-bold mt-0.5 ${
                            isOnline ? "text-emerald-300" : "text-red-400"
                          }`}
                        >
                          {isOnline ? "Online" : "Offline"}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/50 border border-white/10 text-[11px]">
                      <span className="flex items-center gap-1.5 text-white/70">
                        <ShieldCheck size={13} style={{ color: wakeLockActive ? primary : "#64748b" }} />
                        <span>Screen Wake Lock</span>
                      </span>
                      <span className={wakeLockActive ? "text-emerald-400 font-bold" : "text-white/45"}>
                        {wakeLockActive ? "ACTIVE" : "RELEASED"}
                      </span>
                    </div>
                  </div>

                  {/* Master Gate & Quick Audio / Display Controls */}
                  <div className="p-3.5 rounded-xl bg-white/[0.04] border border-white/10 space-y-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-white/80 mb-1">
                      Quick Controls
                    </div>

                    <button
                      type="button"
                      onClick={onToggleSystemActive}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border text-xs font-bold cursor-pointer transition-colors"
                      style={
                        isSystemActive
                          ? {
                              backgroundColor: "rgba(239,68,68,0.16)",
                              borderColor: "rgba(239,68,68,0.5)",
                              color: "#fca5a5",
                            }
                          : {
                              backgroundColor: `${primary}1f`,
                              borderColor: `${primary}66`,
                              color: primary,
                            }
                      }
                    >
                      <span className="flex items-center gap-2">
                        <Power size={14} />
                        <span>{isSystemActive ? "Stop Radha System" : "Start / Activate Radha"}</span>
                      </span>
                      <span>{isSystemActive ? "ON" : "OFF"}</span>
                    </button>

                    <button
                      type="button"
                      onClick={onToggleWakeWord}
                      disabled={!isSystemActive}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-lg bg-black/50 border border-white/10 text-xs hover:bg-white/10 disabled:opacity-40 cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <Radio size={13} style={{ color: wakeWordEnabled ? primary : "#94a3b8" }} />
                        <span>Wake-Word (&ldquo;{config.wakeWordText || "राधा"}&rdquo;)</span>
                      </span>
                      <span className={wakeWordEnabled && isSystemActive ? "text-emerald-400 font-bold" : "text-white/45"}>
                        {wakeWordEnabled && isSystemActive ? "ON" : "OFF"}
                      </span>
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={onToggleMicMute}
                        className="flex items-center justify-center gap-1.5 py-2 rounded-lg bg-black/50 border border-white/10 text-xs hover:bg-white/10 cursor-pointer"
                      >
                        {isMicMuted ? <MicOff size={13} className="text-red-400" /> : <Mic size={13} />}
                        <span>{isMicMuted ? "Mic Muted" : "Mic Live"}</span>
                      </button>
                      <button
                        type="button"
                        onClick={onToggleMute}
                        className="flex items-center justify-center gap-1.5 py-2 rounded-lg bg-black/50 border border-white/10 text-xs hover:bg-white/10 cursor-pointer"
                      >
                        {isMuted ? <VolumeX size={13} className="text-red-400" /> : <Volume2 size={13} />}
                        <span>{isMuted ? "Muted" : "Voice On"}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateConfig({
                            ...config,
                            showTelemetryPanel: config.showTelemetryPanel === false,
                          })
                        }
                        className="py-2 px-2 rounded-lg bg-black/50 border border-white/10 text-[10.5px] text-white/75 hover:text-white cursor-pointer"
                      >
                        Telemetry: {config.showTelemetryPanel === false ? "Hidden" : "Shown"}
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateConfig({
                            ...config,
                            compactChatPosition:
                              config.compactChatPosition === "hidden" ? "right" : "hidden",
                          })
                        }
                        className="py-2 px-2 rounded-lg bg-black/50 border border-white/10 text-[10.5px] text-white/75 hover:text-white cursor-pointer"
                      >
                        Mini Chat: {config.compactChatPosition === "hidden" ? "Hidden" : "Shown"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
