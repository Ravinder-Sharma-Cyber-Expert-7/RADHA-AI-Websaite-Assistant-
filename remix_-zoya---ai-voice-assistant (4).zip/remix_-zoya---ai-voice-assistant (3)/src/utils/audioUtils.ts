import type { RadhaEmotion } from "../services/memoryService";

export interface EmotionVoiceProfile {
  emotion: RadhaEmotion;
  pitchMultiplier: number; // Applied subtly to PCM/WAV playbackRate alongside user voicePitch
  speechRate: number; // Applied to Web Speech API utterance.rate
  gain: number; // Dynamic loudness/softness curve via Web Audio GainNode
  browserPitchOffset: number; // Offset added to voicePitch for SpeechSynthesisUtterance
  browserVolume: number; // 0..1 volume for SpeechSynthesisUtterance
  ttsStyle: string; // Gemini 3.8 TTS speechMetadata.style prompt
}

export const EMOTION_VOICE_PROFILES: Record<RadhaEmotion, EmotionVoiceProfile> = {
  neutral: {
    emotion: "neutral",
    pitchMultiplier: 1.0,
    speechRate: 1.0,
    gain: 1.0,
    browserPitchOffset: 0.0,
    browserVolume: 0.96,
    ttsStyle: "Warm, natural, clear Indian female Hindi voice with poised conversational cadence",
  },
  happy: {
    emotion: "happy",
    pitchMultiplier: 1.045,
    speechRate: 1.06,
    gain: 1.06,
    browserPitchOffset: 0.1,
    browserVolume: 1.0,
    ttsStyle: "Bright, cheerful, smiling Indian female Hindi voice full of genuine joy and warmth",
  },
  excited: {
    emotion: "excited",
    pitchMultiplier: 1.07,
    speechRate: 1.12,
    gain: 1.1,
    browserPitchOffset: 0.16,
    browserVolume: 1.0,
    ttsStyle: "Energetic, enthusiastic, animated Indian female Hindi voice bursting with excitement",
  },
  playful: {
    emotion: "playful",
    pitchMultiplier: 1.05,
    speechRate: 1.08,
    gain: 1.05,
    browserPitchOffset: 0.12,
    browserVolume: 0.98,
    ttsStyle: "Playful, teasing, lighthearted Indian female Hindi voice with witty charm and subtle smile",
  },
  caring: {
    emotion: "caring",
    pitchMultiplier: 0.975,
    speechRate: 0.92,
    gain: 0.92,
    browserPitchOffset: -0.04,
    browserVolume: 0.9,
    ttsStyle: "Soft, gentle, deeply empathetic and comforting Indian female Hindi voice speaking tenderly",
  },
  sad: {
    emotion: "sad",
    pitchMultiplier: 0.94,
    speechRate: 0.86,
    gain: 0.84,
    browserPitchOffset: -0.14,
    browserVolume: 0.85,
    ttsStyle: "Quiet, tender, melancholic Indian female Hindi voice with slower heartfelt cadence",
  },
  hurt: {
    emotion: "hurt",
    pitchMultiplier: 0.955,
    speechRate: 0.89,
    gain: 0.88,
    browserPitchOffset: -0.09,
    browserVolume: 0.88,
    ttsStyle: "Emotionally hurt, sensitive, offended Indian female Hindi voice with gentle vulnerability",
  },
  angry: {
    emotion: "angry",
    pitchMultiplier: 1.025,
    speechRate: 1.09,
    gain: 1.12,
    browserPitchOffset: -0.05,
    browserVolume: 1.0,
    ttsStyle: "Sharp, assertive, genuinely annoyed and spirited Indian female Hindi voice with firm emphasis",
  },
};

export function getEmotionVoiceProfile(emotion?: RadhaEmotion): EmotionVoiceProfile {
  if (emotion && emotion in EMOTION_VOICE_PROFILES) {
    return EMOTION_VOICE_PROFILES[emotion];
  }
  return EMOTION_VOICE_PROFILES.neutral;
}

let sharedAudioContext: AudioContext | null = null;
let sharedLiveInputContext: AudioContext | null = null;
let sharedAnalyser: AnalyserNode | null = null;
let sharedGainNode: GainNode | null = null;
let activePcmSource: AudioBufferSourceNode | null = null;
let activeStreamSources: Set<AudioBufferSourceNode> = new Set();
let activeStreamAbort: AbortController | null = null;
let activeResolve: (() => void) | null = null;
let activePlaybackSafetyTimer: number | null = null;
let activeUtteranceRef: SpeechSynthesisUtterance | null = null;
let activeSpeechKeepAliveTimer: number | null = null;
let isTtsPlaying = false;
let playbackGenerationId = 0;

function clearPlaybackTimers(): void {
  if (activePlaybackSafetyTimer !== null) {
    window.clearTimeout(activePlaybackSafetyTimer);
    activePlaybackSafetyTimer = null;
  }
  if (activeSpeechKeepAliveTimer !== null) {
    window.clearInterval(activeSpeechKeepAliveTimer);
    activeSpeechKeepAliveTimer = null;
  }
}

// Pre-fetched in-memory audio cache for instant <50ms wake-word greetings and repeated short phrases
const prefetchedAudioCache = new Map<string, string>();
const prefetchInFlight = new Set<string>();
let serverTtsCooldownUntil = 0;

export function isServerTtsCoolingDown(): boolean {
  if (serverTtsCooldownUntil > Date.now()) return true;
  if (serverTtsCooldownUntil > 0) serverTtsCooldownUntil = 0;
  return false;
}

export function markServerTtsCooldown(durationMs: number = 5 * 60 * 1000): void {
  const clamped = Math.max(30_000, Math.min(15 * 60 * 1000, durationMs));
  serverTtsCooldownUntil = Math.max(serverTtsCooldownUntil, Date.now() + clamped);
}

function getCacheKey(text: string, voiceName: string, emotion: RadhaEmotion): string {
  return `${voiceName}::${emotion}::${text.trim()}`;
}

/**
 * Pre-fetches and caches short greeting audio in the background so Wake-Word responses play instantly.
 */
export async function prefetchRadhaGreeting(
  text: string,
  voiceName: string = "Kore",
  emotion: RadhaEmotion = "excited"
): Promise<void> {
  const clean = text.trim();
  if (!clean || isServerTtsCoolingDown()) return;
  const key = getCacheKey(clean, voiceName, emotion);
  if (prefetchedAudioCache.has(key) || prefetchInFlight.has(key)) return;
  prefetchInFlight.add(key);
  try {
    const res = await fetch("/api/gemini/audio", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: clean, voiceName, emotion }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data?.quotaExhausted) {
        markServerTtsCooldown(data.retryAfterMs || 5 * 60 * 1000);
      } else if (data?.audio) {
        if (prefetchedAudioCache.size >= 16) {
          const oldest = prefetchedAudioCache.keys().next().value;
          if (oldest) prefetchedAudioCache.delete(oldest);
        }
        prefetchedAudioCache.set(key, data.audio);
      }
    }
  } catch {
    // Non-fatal background pre-fetch
  } finally {
    prefetchInFlight.delete(key);
  }
}

export function getCachedPrefetchedAudio(
  text: string,
  voiceName: string = "Kore",
  emotion: RadhaEmotion = "neutral"
): string | null {
  return prefetchedAudioCache.get(getCacheKey(text, voiceName, emotion)) || null;
}

export function getTtsAnalyser(): AnalyserNode | null {
  return isTtsPlaying ? sharedAnalyser : null;
}

export function isTtsAudioPlaying(): boolean {
  return isTtsPlaying;
}

function ensureSharedAudioGraph(): AudioContext | null {
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!sharedAudioContext || sharedAudioContext.state === "closed") {
    sharedAudioContext = new AudioContextClass();
    sharedGainNode = sharedAudioContext.createGain();
    sharedGainNode.gain.value = 1.0;
    sharedAnalyser = sharedAudioContext.createAnalyser();
    sharedAnalyser.fftSize = 128;
    sharedAnalyser.smoothingTimeConstant = 0.72;
    sharedGainNode.connect(sharedAnalyser);
    sharedAnalyser.connect(sharedAudioContext.destination);
  }
  return sharedAudioContext;
}

/**
 * Returns a persistent AudioContext unlocked during the user's START/click gesture
 * so Wake-Word activation (which fires outside a click gesture) NEVER starts suspended.
 */
export function getUnlockedLivePlaybackContext(): AudioContext | null {
  const ctx = ensureSharedAudioGraph();
  if (ctx && ctx.state === "suspended") {
    ctx.resume().catch(() => {});
  }
  return ctx;
}

export function getUnlockedLiveInputContext(): AudioContext | null {
  const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!sharedLiveInputContext || sharedLiveInputContext.state === "closed") {
    sharedLiveInputContext = new AudioContextClass();
  }
  if (sharedLiveInputContext.state === "suspended") {
    sharedLiveInputContext.resume().catch(() => {});
  }
  return sharedLiveInputContext;
}

/**
 * Unlock BOTH persistent Web Audio contexts (playback + live mic input) & warm up SpeechSynthesis
 * on first user tap/click or START button so hands-free Wake-Word always captures mic & plays audibly.
 */
export function unlockAudioPlayback(): void {
  try {
    const playCtx = ensureSharedAudioGraph();
    if (playCtx) {
      if (playCtx.state === "suspended") {
        playCtx.resume().catch(() => {});
      }
      // Play 1-sample silent buffer to permanently unlock audio output on Chrome / iOS / Android WebView
      try {
        const silentBuf = playCtx.createBuffer(1, 1, 22050);
        const src = playCtx.createBufferSource();
        src.buffer = silentBuf;
        src.connect(playCtx.destination);
        src.start(0);
      } catch {}
    }
  } catch {}
  try {
    const inCtx = getUnlockedLiveInputContext();
    if (inCtx && inCtx.state === "suspended") {
      inCtx.resume().catch(() => {});
    }
  } catch {}
  try {
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.getVoices();
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
  } catch {}
}

export function stopActivePCM(): void {
  playbackGenerationId += 1;
  isTtsPlaying = false;
  clearPlaybackTimers();
  activeUtteranceRef = null;
  if (activeStreamAbort) {
    try {
      activeStreamAbort.abort();
    } catch {}
    activeStreamAbort = null;
  }
  if (activePcmSource) {
    try {
      activePcmSource.onended = null;
      activePcmSource.stop();
      activePcmSource.disconnect();
    } catch {}
    activePcmSource = null;
  }
  if (activeStreamSources.size > 0) {
    activeStreamSources.forEach((src) => {
      try {
        src.onended = null;
        src.stop();
        src.disconnect();
      } catch {}
    });
    activeStreamSources.clear();
  }
  if (typeof window !== "undefined" && "speechSynthesis" in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {}
  }
  if (activeResolve) {
    const done = activeResolve;
    activeResolve = null;
    done();
  }
}

/**
 * Bulletproof browser Hindi TTS with:
 * - speechSynthesis.cancel() + 60ms micro-delay (prevents Chrome stuck-queue drop bug)
 * - Chrome keep-alive resume() loop (prevents Chrome 15s pause/mute bug)
 * - Module-level utterance ref (prevents GC killing onend)
 * - Guaranteed safety fallback timeout (e.g. 2500ms for short greetings) if Chrome/WebView swallows onend
 */
export function speakBrowserHindiFallback(
  text: string,
  voicePitch: number = 1.0,
  emotion: RadhaEmotion = "neutral",
  safetyTimeoutMs?: number
): Promise<void> {
  return new Promise((resolve) => {
    const clean = text.trim();
    if (typeof window === "undefined" || !("speechSynthesis" in window) || !clean) {
      resolve();
      return;
    }

    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      isTtsPlaying = false;
      activeUtteranceRef = null;
      clearPlaybackTimers();
      if (activeResolve === finish) {
        activeResolve = null;
      }
      resolve();
    };

    try {
      stopActivePCM();
      const myGen = playbackGenerationId;
      window.speechSynthesis.cancel();
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }

      const profile = getEmotionVoiceProfile(emotion);
      const clipped = clean.slice(0, 520);
      const utterance = new SpeechSynthesisUtterance(clipped);
      utterance.lang = "hi-IN";
      utterance.pitch = Math.max(
        0.75,
        Math.min(1.4, (voicePitch || 1.02) + profile.browserPitchOffset)
      );
      utterance.rate = Math.max(0.8, Math.min(1.25, profile.speechRate));
      utterance.volume = Math.max(0.5, Math.min(1.0, profile.browserVolume));

      const voices = window.speechSynthesis.getVoices();
      const hindiFemale =
        voices.find(
          (v) =>
            /hi[-_]?in/i.test(v.lang) &&
            /female|swara|lekha|kalpana|google हिन्दी/i.test(v.name)
        ) ||
        voices.find((v) => /hi[-_]?in/i.test(v.lang)) ||
        voices.find((v) => /en[-_]?in/i.test(v.lang));
      if (hindiFemale) {
        utterance.voice = hindiFemale;
      }

      activeUtteranceRef = utterance;
      activeResolve = finish;
      isTtsPlaying = true;

      utterance.onend = () => finish();
      utterance.onerror = () => finish();

      // Chrome TTS keep-alive: resume automatically if browser pauses speech mid-sentence
      activeSpeechKeepAliveTimer = window.setInterval(() => {
        try {
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }
        } catch {}
      }, 250);

      // Guaranteed safety fallback timeout in case Chrome/WebView fails to fire onend
      const computedTimeout =
        typeof safetyTimeoutMs === "number"
          ? Math.max(1800, safetyTimeoutMs)
          : Math.max(3500, Math.min(28000, Math.round(clipped.length * 115 + 2500)));

      activePlaybackSafetyTimer = window.setTimeout(() => {
        try {
          if (window.speechSynthesis.speaking) {
            window.speechSynthesis.cancel();
          }
        } catch {}
        finish();
      }, computedTimeout);

      // 60ms delay after cancel() prevents Chromium from silently swallowing the new utterance
      window.setTimeout(() => {
        if (settled || myGen !== playbackGenerationId) {
          finish();
          return;
        }
        try {
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }
          window.speechSynthesis.speak(utterance);
        } catch {
          finish();
        }
      }, 60);
    } catch {
      finish();
    }
  });
}

function decodePcmChunkToBuffer(
  ctx: AudioContext,
  base64Chunk: string,
  sampleRate: number = 24000
): AudioBuffer | null {
  try {
    const binaryString = atob(base64Chunk);
    const isWav = binaryString.length > 44 && binaryString.startsWith("RIFF");
    const offset = isWav ? 44 : 0;
    const len = binaryString.length - offset;
    const sampleCount = Math.floor(len / 2);
    if (sampleCount <= 0) return null;

    const audioBuffer = ctx.createBuffer(1, sampleCount, sampleRate);
    const channelData = audioBuffer.getChannelData(0);
    for (let i = 0; i < sampleCount; i++) {
      const byte1 = binaryString.charCodeAt(offset + i * 2);
      const byte2 = binaryString.charCodeAt(offset + i * 2 + 1);
      let val = (byte2 << 8) | byte1;
      if (val >= 0x8000) val -= 0x10000;
      channelData[i] = val / 32768.0;
    }
    return audioBuffer;
  } catch {
    return null;
  }
}

/**
 * Pre-fetch streaming audio player:
 * Starts downloading AI-generated PCM stream chunks from /api/gemini/audio/stream and immediately
 * schedules & plays from the very first received chunk while subsequent chunks buffer in parallel,
 * drastically cutting 'time to first word' latency.
 */
export async function streamAndPlayRadhaAudio(
  text: string,
  voiceName: string = "Kore",
  voicePitch: number = 1.0,
  emotion: RadhaEmotion = "neutral",
  safetyTimeoutMs?: number
): Promise<boolean> {
  const clean = text.trim().slice(0, 700);
  if (!clean) return false;

  // Instant hit from pre-fetch cache (e.g., wake-word greetings)
  const cached = getCachedPrefetchedAudio(clean, voiceName, emotion);
  if (cached) {
    const played = await playPCM(cached, voicePitch, emotion, safetyTimeoutMs);
    return played;
  }

  // Skip network hop immediately while server TTS is in quota cooldown
  if (isServerTtsCoolingDown()) {
    return false;
  }

  stopActivePCM();
  const myGen = playbackGenerationId;

  const ctx = ensureSharedAudioGraph();
  if (!ctx) return false;
  if (ctx.state === "suspended") {
    await ctx.resume().catch(() => {});
  }
  if (myGen !== playbackGenerationId) return false;
  // If browser autoplay policy kept Web Audio suspended, return false so Browser TTS speaks cleanly instead of hanging!
  if (ctx.state !== "running") {
    return false;
  }

  const controller = new AbortController();
  activeStreamAbort = controller;
  const maxFetchWaitMs =
    typeof safetyTimeoutMs === "number"
      ? Math.min(5500, Math.max(1200, Math.floor(safetyTimeoutMs * 0.6)))
      : 5500;
  const fetchTimeout = window.setTimeout(() => {
    try {
      controller.abort();
    } catch {}
  }, maxFetchWaitMs);

  // Keep Radha's exact original Gemini TTS voice pure (speechMetadata.style already renders authentic emotion)
  const effectivePitch = Math.max(0.85, Math.min(1.2, voicePitch || 1.0));

  if (sharedGainNode) {
    sharedGainNode.gain.setTargetAtTime(1.0, ctx.currentTime, 0.02);
  }

  try {
    const response = await fetch("/api/gemini/audio/stream", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: clean, voiceName, emotion }),
      signal: controller.signal,
    });
    window.clearTimeout(fetchTimeout);

    if (!response.ok || !response.body || myGen !== playbackGenerationId) {
      return false;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let lineBuffer = "";
    let scheduledChunks = 0;
    let nextPlayTime = ctx.currentTime + 0.03;
    let streamFinished = false;

    const scheduleAudioChunk = (base64Data: string) => {
      if (controller.signal.aborted || myGen !== playbackGenerationId) return;
      const audioBuffer = decodePcmChunkToBuffer(ctx, base64Data, 24000);
      if (!audioBuffer) return;

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = effectivePitch;

      if (sharedGainNode) {
        source.connect(sharedGainNode);
      } else if (sharedAnalyser) {
        source.connect(sharedAnalyser);
      } else {
        source.connect(ctx.destination);
      }

      const now = ctx.currentTime;
      if (scheduledChunks === 0 || nextPlayTime < now + 0.01) {
        nextPlayTime = now + 0.025;
      }

      activeStreamSources.add(source);
      isTtsPlaying = true;
      source.start(nextPlayTime);
      nextPlayTime += audioBuffer.duration / effectivePitch;
      scheduledChunks++;

      source.onended = () => {
        activeStreamSources.delete(source);
        if (streamFinished && activeStreamSources.size === 0) {
          isTtsPlaying = false;
          if (activeResolve) {
            const done = activeResolve;
            activeResolve = null;
            done();
          }
        }
      };
    };

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      lineBuffer += decoder.decode(value, { stream: true });
      const lines = lineBuffer.split("\n");
      lineBuffer = lines.pop() || "";

      for (const rawLine of lines) {
        const trimmed = rawLine.trim();
        if (!trimmed) continue;
        try {
          const pkt = JSON.parse(trimmed);
          if (pkt.type === "chunk" && pkt.data) {
            scheduleAudioChunk(pkt.data);
          } else if (
            (pkt.type === "fallback" && pkt.reason === "quota_exhausted") ||
            pkt.quotaExhausted
          ) {
            markServerTtsCooldown(pkt.retryAfterMs || 5 * 60 * 1000);
          }
        } catch {}
      }
    }

    if (lineBuffer.trim()) {
      try {
        const pkt = JSON.parse(lineBuffer.trim());
        if (pkt.type === "chunk" && pkt.data) {
          scheduleAudioChunk(pkt.data);
        } else if (
          (pkt.type === "fallback" && pkt.reason === "quota_exhausted") ||
          pkt.quotaExhausted
        ) {
          markServerTtsCooldown(pkt.retryAfterMs || 5 * 60 * 1000);
        }
      } catch {}
    }

    streamFinished = true;
    if (activeStreamAbort === controller) {
      activeStreamAbort = null;
    }

    if (scheduledChunks === 0) {
      isTtsPlaying = false;
      return false;
    }

    if (activeStreamSources.size > 0) {
      const remainingMs = Math.max(800, Math.round((nextPlayTime - ctx.currentTime) * 1000) + 1500);
      const maxWait =
        typeof safetyTimeoutMs === "number" ? Math.min(remainingMs, safetyTimeoutMs) : remainingMs;
      await new Promise<void>((resolve) => {
        const done = () => {
          clearPlaybackTimers();
          if (activeResolve === done) activeResolve = null;
          resolve();
        };
        activeResolve = done;
        activePlaybackSafetyTimer = window.setTimeout(done, maxWait);
      });
    }
    isTtsPlaying = false;
    return true;
  } catch (err: any) {
    window.clearTimeout(fetchTimeout);
    isTtsPlaying = false;
    if (activeStreamAbort === controller) {
      activeStreamAbort = null;
    }
    if (err?.name === "AbortError") {
      // If aborted due to timeout before audio played, return false so fallback TTS still speaks!
      return false;
    }
    return false;
  }
}

export async function playPCM(
  base64Data: string,
  voicePitch: number = 1.0,
  emotion: RadhaEmotion = "neutral",
  safetyTimeoutMs?: number
): Promise<boolean> {
  if (!base64Data) return false;
  try {
    // Prevent overlapping/double audio by cleanly stopping any previous clip
    stopActivePCM();
    const myGen = playbackGenerationId;

    const ctx = ensureSharedAudioGraph();
    if (!ctx) {
      return false;
    }
    if (ctx.state === "suspended") {
      await ctx.resume().catch(() => {});
    }
    if (myGen !== playbackGenerationId) {
      return false;
    }
    // If browser kept AudioContext suspended, return false so Web Speech TTS handles playback cleanly
    if (ctx.state !== "running") {
      return false;
    }

    const binaryString = atob(base64Data);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    let audioBuffer: AudioBuffer | null = null;

    // Check if the data is a WAV/container audio format (starts with "RIFF")
    const isWav = binaryString.length > 12 && binaryString.startsWith("RIFF");
    if (isWav) {
      try {
        audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
      } catch {
        // Fallback to raw PCM parser below
      }
    }

    if (myGen !== playbackGenerationId) {
      return false;
    }

    // Fallback: Parse as raw 24kHz 16-bit mono PCM (Gemini format)
    if (!audioBuffer) {
      const offset = isWav ? 44 : 0;
      const len = binaryString.length - offset;
      const sampleCount = Math.floor(len / 2);
      if (sampleCount <= 0) return false;

      audioBuffer = ctx.createBuffer(1, sampleCount, 24000);
      const channelData = audioBuffer.getChannelData(0);
      for (let i = 0; i < sampleCount; i++) {
        const byte1 = bytes[offset + i * 2];
        const byte2 = bytes[offset + i * 2 + 1];
        let val = (byte2 << 8) | byte1;
        if (val >= 0x8000) val -= 0x10000;
        channelData[i] = val / 32768.0;
      }
    }

    const source = ctx.createBufferSource();
    source.buffer = audioBuffer;

    // Keep Radha's original voice natural (zero artificial pitch warping)
    const effectivePitch = Math.max(0.85, Math.min(1.2, voicePitch || 1.0));
    source.playbackRate.value = effectivePitch;

    if (sharedGainNode) {
      sharedGainNode.gain.setTargetAtTime(1.0, ctx.currentTime, 0.02);
      source.connect(sharedGainNode);
    } else if (sharedAnalyser) {
      source.connect(sharedAnalyser);
    } else {
      source.connect(ctx.destination);
    }

    activePcmSource = source;
    isTtsPlaying = true;
    source.start();

    const expectedMs = Math.ceil((audioBuffer.duration / effectivePitch) * 1000) + 1200;
    const maxWait =
      typeof safetyTimeoutMs === "number" ? Math.min(expectedMs, Math.max(2000, safetyTimeoutMs)) : expectedMs;

    await new Promise<void>((resolve) => {
      const done = () => {
        clearPlaybackTimers();
        if (activePcmSource === source) {
          activePcmSource = null;
          isTtsPlaying = false;
        }
        if (activeResolve === done) activeResolve = null;
        resolve();
      };
      activeResolve = done;
      source.onended = done;
      activePlaybackSafetyTimer = window.setTimeout(done, maxWait);
    });
    return true;
  } catch (error) {
    isTtsPlaying = false;
    console.warn("Audio playback skipped:", error);
    return false;
  }
}
