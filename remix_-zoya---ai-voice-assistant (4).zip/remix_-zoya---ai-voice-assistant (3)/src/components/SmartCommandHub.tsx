import React, { useEffect, useRef, useState } from "react";
import {
  AlarmClock,
  Brain,
  Calendar,
  CheckCircle2,
  Circle,
  ExternalLink,
  FileSearch,
  Globe,
  Heart,
  Loader2,
  LogOut,
  Mail,
  Play,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Sparkles,
  Square,
  Trash2,
  Upload,
  Volume2,
  CheckSquare,
  AlertTriangle,
} from "lucide-react";
import BossSentimentPanel from "./BossSentimentPanel";
import { BossSentimentRecord } from "../services/sentimentService";
import {
  BondingState,
  EMOTION_META,
  MoodEntry,
  RadhaConfig,
  RadhaEmotion,
  ReminderItem,
  TaskItem,
  WebSearchResult,
  UploadedVaultFile,
  analyzeAndStoreUploadedFile,
  getBondingRank,
  searchLiveWeb,
  uploadFileToSystemVault,
} from "../services/memoryService";
import {
  CalendarEventItem,
  GmailMessageSummary,
  createGoogleCalendarEvent,
  fetchRecentEmails,
  fetchUpcomingCalendarEvents,
  getWorkspaceAccessToken,
  initWorkspaceAuth,
  signInWithGoogleWorkspace,
  signOutGoogleWorkspace,
} from "../services/workspaceService";

export type SmartHubSection = "sentiment" | "alarms" | "tasks" | "web" | "scanner" | "workspace" | "mood";

interface SmartCommandHubProps {
  config: RadhaConfig;
  initialSection?: SmartHubSection;
  reminders: ReminderItem[];
  tasks: TaskItem[];
  moods: MoodEntry[];
  sentiments: BossSentimentRecord[];
  latestSentiment: BossSentimentRecord | null;
  bonding: BondingState;
  currentEmotion: RadhaEmotion;
  onCreateReminder: (title: string, triggerAt: number) => Promise<void>;
  onDeleteReminder: (id: string) => Promise<void>;
  onCreateTask: (title: string, priority: "low" | "medium" | "high") => Promise<void>;
  onToggleTask: (id: string, completed: boolean) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  onLogMood: (emotion: RadhaEmotion, note: string) => Promise<void>;
  onRunDeepSentiment: (customText?: string) => Promise<void>;
  onSpeakText: (text: string) => Promise<void>;
  onAskRadha: (prompt: string) => void;
  onCyberLog: (msg: string) => void;
  onVaultFileSynced?: (file: UploadedVaultFile, rawBase64?: string) => void;
}

export default function SmartCommandHub({
  config,
  initialSection = "sentiment",
  reminders,
  tasks,
  moods,
  sentiments,
  latestSentiment,
  bonding,
  currentEmotion,
  onCreateReminder,
  onDeleteReminder,
  onCreateTask,
  onToggleTask,
  onDeleteTask,
  onLogMood,
  onRunDeepSentiment,
  onSpeakText,
  onAskRadha,
  onCyberLog,
  onVaultFileSynced,
}: SmartCommandHubProps) {
  const [section, setSection] = useState<SmartHubSection>(initialSection);

  useEffect(() => {
    setSection(initialSection);
  }, [initialSection]);

  const primary = config.primaryColor || "#00ff9d";
  const secondary = config.secondaryColor || "#00e5ff";

  // --- #1 Reminders & Focus Pomodoro ---
  const [remTitle, setRemTitle] = useState("");
  const [remMinutes, setRemMinutes] = useState("15");
  const [focusSec, setFocusSec] = useState(25 * 60);
  const [focusRunning, setFocusRunning] = useState(false);

  useEffect(() => {
    if (!focusRunning) return;
    const timer = window.setInterval(() => {
      setFocusSec((prev) => {
        if (prev <= 1) {
          setFocusRunning(false);
          onCyberLog("POMODORO FOCUS SESSION COMPLETED");
          onSpeakText(
            `${config.creatorName || "Ravindra Boss"}, aapka 25 minute ka focus session complete ho gaya hai! Thoda break le lijiye.`
          );
          return 25 * 60;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [focusRunning, config.creatorName, onCyberLog, onSpeakText]);

  const handleAddReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!remTitle.trim()) return;
    const mins = Math.max(1, parseInt(remMinutes, 10) || 5);
    await onCreateReminder(remTitle.trim(), Date.now() + mins * 60_000);
    setRemTitle("");
  };

  // --- #2 Tasks & Daily Briefing ---
  const [taskTitle, setTaskTitle] = useState("");
  const [taskPriority, setTaskPriority] = useState<"low" | "medium" | "high">("medium");

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim()) return;
    await onCreateTask(taskTitle.trim(), taskPriority);
    setTaskTitle("");
  };

  const handleDailyBriefing = () => {
    const pendingTasks = tasks.filter((t) => !t.completed);
    const activeRems = reminders.filter((r) => !r.completed && r.triggerAt > Date.now());
    const nowStr = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    onCyberLog("EXECUTING INSTANT DAILY BRIEFING");
    onAskRadha(
      `Radha, mujhe mera instant daily briefing do. Abhi samay ${nowStr} hai. Mere ${pendingTasks.length} pending tasks hain (${
        pendingTasks.slice(0, 4).map((t) => t.title).join(", ") || "koi pending task nahi"
      }) aur ${activeRems.length} upcoming reminders hain. Short, smart aur energetic Hinglish me brief karo.`
    );
  };

  // --- #4 Real-Time Internet Search ---
  const [searchQuery, setSearchQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<WebSearchResult | null>(null);
  const [searchError, setSearchError] = useState("");

  const runLiveSearch = async (queryText: string) => {
    const q = queryText.trim();
    if (!q) return;
    setSearchQuery(q);
    setSearching(true);
    setSearchError("");
    onCyberLog(`LIVE WEB SEARCH: "${q.slice(0, 32)}"`);
    try {
      const res = await searchLiveWeb(q);
      setSearchResult(res);
    } catch (err: any) {
      setSearchError(err?.message || "Live search failed.");
    } finally {
      setSearching(false);
    }
  };

  // --- #6 Photo / File / Code Scanner ---
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    mimeType: string;
    base64Data: string;
    previewUrl?: string;
  } | null>(null);
  const [scanQuestion, setScanQuestion] = useState("");
  const [scanning, setScanning] = useState(false);
  const [scanOutput, setScanOutput] = useState("");
  const [scanError, setScanError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [vaultSyncNotice, setVaultSyncNotice] = useState("");

  const handleFilePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setScanError("");
    setScanOutput("");
    setVaultSyncNotice("राधा के लाइव ब्रेन में फ़ाइल सिंक हो रही है...");
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = String(reader.result || "");
      const base64Data = dataUrl.includes(",") ? dataUrl.split(",")[1] : dataUrl;
      const mimeType = file.type || "text/plain";
      setSelectedFile({
        name: file.name,
        mimeType,
        base64Data,
        previewUrl: file.type.startsWith("image/") ? dataUrl : undefined,
      });

      // Immediately upload & analyze into Radha's System Vault so Live Voice Call sees it right away!
      try {
        const res = await uploadFileToSystemVault({
          base64Data,
          mimeType,
          fileName: file.name,
        });
        if (res?.file) {
          onVaultFileSynced?.(res.file, file.type.startsWith("image/") ? base64Data : undefined);
          setVaultSyncNotice(`✓ "${file.name}" राधा के लाइव सिस्टम में पहुँच गई (SHA256:${(res.file.sha256 || "").slice(0, 8)})`);
          setScanOutput(res.file.summary);
          onCyberLog(`LIVE VAULT SYNCED: ${file.name}`);
        } else {
          setVaultSyncNotice("");
        }
      } catch {
        setVaultSyncNotice("");
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRunScan = async () => {
    if (!selectedFile) return;
    setScanning(true);
    setScanError("");
    onCyberLog(`AI FILE SCANNER: ${selectedFile.name}`);
    try {
      const { analysis, vaultFile } = await analyzeAndStoreUploadedFile({
        base64Data: selectedFile.base64Data,
        mimeType: selectedFile.mimeType,
        fileName: selectedFile.name,
        question: scanQuestion.trim() || undefined,
      });
      setScanOutput(analysis);
      if (vaultFile) {
        onVaultFileSynced?.(
          vaultFile,
          selectedFile.mimeType.startsWith("image/") ? selectedFile.base64Data : undefined
        );
        setVaultSyncNotice(`✓ "${selectedFile.name}" राधा के लाइव सिस्टम में अपडेट हो गई`);
      }
    } catch (err: any) {
      setScanError(err?.message || "File analysis failed.");
    } finally {
      setScanning(false);
    }
  };

  // --- #7 Google Workspace (Gmail & Calendar) ---
  const [wsEmail, setWsEmail] = useState<string | null>(null);
  const [wsSignedIn, setWsSignedIn] = useState<boolean>(!!getWorkspaceAccessToken());
  const [wsLoading, setWsLoading] = useState(false);
  const [wsError, setWsError] = useState("");
  const [emails, setEmails] = useState<GmailMessageSummary[]>([]);
  const [calEvents, setCalEvents] = useState<CalendarEventItem[]>([]);

  // Calendar event creation with MANDATORY user confirmation modal
  const [evSummary, setEvSummary] = useState("");
  const [evDateTime, setEvDateTime] = useState(() => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    d.setMinutes(0, 0, 0);
    const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
    return local.toISOString().slice(0, 16);
  });
  const [evDurationMins, setEvDurationMins] = useState("60");
  const [pendingConfirmEvent, setPendingConfirmEvent] = useState<{
    summary: string;
    startIso: string;
    endIso: string;
    displayTime: string;
  } | null>(null);
  const [creatingEvent, setCreatingEvent] = useState(false);

  const loadWorkspaceData = async () => {
    setWsLoading(true);
    setWsError("");
    try {
      const [inbox, events] = await Promise.all([
        fetchRecentEmails(6),
        fetchUpcomingCalendarEvents(8),
      ]);
      setEmails(inbox);
      setCalEvents(events);
      onCyberLog(`WORKSPACE SYNC: ${inbox.length} EMAILS · ${events.length} EVENTS`);
    } catch (err: any) {
      if (err?.message === "AUTH_REQUIRED") {
        setWsSignedIn(false);
      } else {
        setWsError(err?.message || "Could not load Gmail / Calendar.");
      }
    } finally {
      setWsLoading(false);
    }
  };

  useEffect(() => {
    const unsub = initWorkspaceAuth(
      (user) => {
        setWsEmail(user.email || user.displayName || "Google Account");
        setWsSignedIn(true);
      },
      () => {
        setWsSignedIn(false);
        setWsEmail(null);
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    if (section === "workspace" && wsSignedIn && emails.length === 0 && calEvents.length === 0 && !wsLoading) {
      loadWorkspaceData();
    }
  }, [section, wsSignedIn]);

  const handleWorkspaceSignIn = async () => {
    setWsError("");
    setWsLoading(true);
    try {
      const res = await signInWithGoogleWorkspace();
      if (res) {
        setWsEmail(res.user.email || res.user.displayName || "Google Account");
        setWsSignedIn(true);
        onCyberLog("GOOGLE WORKSPACE OAUTH VERIFIED");
        await loadWorkspaceData();
      }
    } catch (err: any) {
      setWsError(err?.message || "Google Sign-In cancelled or failed.");
    } finally {
      setWsLoading(false);
    }
  };

  const handleWorkspaceSignOut = async () => {
    await signOutGoogleWorkspace();
    setWsSignedIn(false);
    setWsEmail(null);
    setEmails([]);
    setCalEvents([]);
    onCyberLog("GOOGLE WORKSPACE DISCONNECTED");
  };

  const handleRequestCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!evSummary.trim() || !evDateTime) return;
    const startDate = new Date(evDateTime);
    const dur = Math.max(15, parseInt(evDurationMins, 10) || 60);
    const endDate = new Date(startDate.getTime() + dur * 60_000);
    setPendingConfirmEvent({
      summary: evSummary.trim(),
      startIso: startDate.toISOString(),
      endIso: endDate.toISOString(),
      displayTime: `${startDate.toLocaleString()} (${dur} min)`,
    });
  };

  const handleConfirmCreateEvent = async () => {
    if (!pendingConfirmEvent) return;
    setCreatingEvent(true);
    setWsError("");
    try {
      const created = await createGoogleCalendarEvent({
        summary: pendingConfirmEvent.summary,
        startIso: pendingConfirmEvent.startIso,
        endIso: pendingConfirmEvent.endIso,
      });
      setCalEvents((prev) => [created, ...prev]);
      setEvSummary("");
      setPendingConfirmEvent(null);
      onCyberLog(`CALENDAR EVENT CREATED: ${created.summary}`);
    } catch (err: any) {
      setWsError(err?.message || "Failed to create Calendar event.");
      setPendingConfirmEvent(null);
    } finally {
      setCreatingEvent(false);
    }
  };

  const handleSummarizeEmails = () => {
    if (emails.length === 0) return;
    const digest = emails
      .slice(0, 5)
      .map((m, i) => `${i + 1}. From: ${m.from} | Subject: ${m.subject} | Preview: ${m.snippet}`)
      .join("\n");
    onAskRadha(
      `Radha, mere Gmail inbox ke ye recent emails Hinglish me crisp bullet summary me batao:\n${digest}`
    );
  };

  // --- #5 Mood Diary & Bonding ---
  const [moodNote, setMoodNote] = useState("");
  const xpIntoLevel = bonding.xp % 100;
  const rankName = getBondingRank(bonding.level);

  const subTabs: Array<{ id: SmartHubSection; label: string; icon: any }> = [
    { id: "sentiment", label: "Sentiment", icon: Brain },
    { id: "alarms", label: "Alarms", icon: AlarmClock },
    { id: "tasks", label: "Tasks", icon: CheckSquare },
    { id: "web", label: "Web Intel", icon: Globe },
    { id: "scanner", label: "File Scan", icon: FileSearch },
    { id: "workspace", label: "Google", icon: Mail },
    { id: "mood", label: "Bond", icon: Heart },
  ];

  return (
    <div className="flex flex-col h-full min-h-0 font-mono text-xs">
      {/* Sub-navigation bar */}
      <div className="grid grid-cols-4 gap-1.5 mb-3 shrink-0">
        {subTabs.map((t) => {
          const Icon = t.icon;
          const active = section === t.id;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setSection(t.id)}
              className={`flex items-center justify-center gap-1 py-2 px-1.5 rounded-lg text-[9.5px] font-semibold uppercase tracking-wider border transition-all cursor-pointer ${
                active
                  ? "text-black font-bold"
                  : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white hover:bg-white/[0.08]"
              } ${t.id === "sentiment" ? "col-span-2" : ""}`}
              style={
                active
                  ? { backgroundColor: primary, borderColor: primary }
                  : undefined
              }
            >
              <Icon size={12} />
              <span className="truncate">{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Scrollable Body */}
      <div className="flex-1 overflow-y-auto pr-1 space-y-3 scrollbar-thin">
        {/* SECTION 0: BOSS SENTIMENT ANALYSIS */}
        {section === "sentiment" && (
          <BossSentimentPanel
            config={config}
            sentiments={sentiments}
            latestSentiment={latestSentiment}
            onRunDeepAnalyze={onRunDeepSentiment}
          />
        )}

        {/* SECTION 1: ALARMS, REMINDERS & FOCUS POMODORO */}
        {section === "alarms" && (
          <>
            {/* Focus Pomodoro Timer */}
            <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-white/60">
                  DEEP FOCUS POMODORO
                </span>
                <span className="text-lg font-bold tracking-wider" style={{ color: primary }}>
                  {String(Math.floor(focusSec / 60)).padStart(2, "0")}:
                  {String(focusSec % 60).padStart(2, "0")}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setFocusRunning((r) => !r)}
                  className="flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[11px] font-bold text-black cursor-pointer"
                  style={{ backgroundColor: focusRunning ? "#fbbf24" : primary }}
                >
                  {focusRunning ? <Square size={12} /> : <Play size={12} />}
                  <span>{focusRunning ? "PAUSE" : "START 25M FOCUS"}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFocusRunning(false);
                    setFocusSec(25 * 60);
                  }}
                  className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-white/70 hover:text-white cursor-pointer"
                  title="Reset Timer"
                >
                  <RotateCcw size={14} />
                </button>
              </div>
            </div>

            {/* Add Voice Alarm / Reminder */}
            <form onSubmit={handleAddReminder} className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2.5">
              <div className="text-[10px] uppercase tracking-widest text-white/60">
                SET VOICE ALARM / REMINDER
              </div>
              <input
                type="text"
                value={remTitle}
                onChange={(e) => setRemTitle(e.target.value)}
                placeholder="e.g., Paani peena / Client call / Medicine..."
                className="w-full bg-white/5 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/35 outline-none focus:border-emerald-400"
              />
              <div className="flex items-center gap-2">
                <select
                  value={remMinutes}
                  onChange={(e) => setRemMinutes(e.target.value)}
                  className="bg-[#091217] border border-white/15 rounded-lg px-2.5 py-2 text-xs text-white outline-none"
                >
                  <option value="1">In 1 min</option>
                  <option value="5">In 5 min</option>
                  <option value="15">In 15 min</option>
                  <option value="30">In 30 min</option>
                  <option value="60">In 1 hour</option>
                  <option value="120">In 2 hours</option>
                </select>
                <button
                  type="submit"
                  disabled={!remTitle.trim()}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold text-black disabled:opacity-40 cursor-pointer"
                  style={{ backgroundColor: primary }}
                >
                  <Plus size={13} />
                  <span>ARM ALARM</span>
                </button>
              </div>
            </form>

            {/* Reminder List */}
            <div className="space-y-2">
              {reminders.length === 0 ? (
                <div className="text-center py-6 text-white/40 text-[11px]">
                  Koi reminder set nahi hai. Voice me bolo: &quot;Radha 10 minute baad yaad dilana...&quot;
                </div>
              ) : (
                reminders.map((rem) => (
                  <div
                    key={rem.id}
                    className={`flex items-center justify-between gap-2 p-2.5 rounded-lg border ${
                      rem.completed
                        ? "bg-white/[0.02] border-white/5 opacity-55"
                        : "bg-black/45 border-white/15"
                    }`}
                  >
                    <div className="min-w-0">
                      <div className={`text-xs text-white truncate ${rem.completed ? "line-through" : ""}`}>
                        {rem.title}
                      </div>
                      <div className="text-[10px] text-white/45">
                        {new Date(rem.triggerAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}{" "}
                        · {rem.completed ? "RINGED" : "ARMED"}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onDeleteReminder(rem.id)}
                      className="p-1.5 rounded text-white/40 hover:text-red-400 hover:bg-red-500/10 cursor-pointer shrink-0"
                      title="Delete Reminder"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </>
        )}

        {/* SECTION 2: PERSONAL TASKS & INSTANT BRIEFING */}
        {section === "tasks" && (
          <>
            <button
              type="button"
              onClick={handleDailyBriefing}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl font-bold text-xs text-black transition-opacity hover:opacity-90 cursor-pointer"
              style={{
                background: `linear-gradient(90deg, ${primary}, ${secondary})`,
              }}
            >
              <Sparkles size={14} />
              <span>BRIEF ME, RADHA (DAILY STATUS)</span>
            </button>

            <form onSubmit={handleAddTask} className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2">
              <div className="text-[10px] uppercase tracking-widest text-white/60">
                ADD NEW MISSION / TASK
              </div>
              <input
                type="text"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                placeholder="Write a task or note..."
                className="w-full bg-white/5 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/35 outline-none focus:border-emerald-400"
              />
              <div className="flex items-center gap-2">
                <select
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value as any)}
                  className="bg-[#091217] border border-white/15 rounded-lg px-2.5 py-2 text-xs text-white outline-none"
                >
                  <option value="high">HIGH</option>
                  <option value="medium">MEDIUM</option>
                  <option value="low">LOW</option>
                </select>
                <button
                  type="submit"
                  disabled={!taskTitle.trim()}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold text-black disabled:opacity-40 cursor-pointer"
                  style={{ backgroundColor: primary }}
                >
                  <Plus size={13} />
                  <span>ADD TASK</span>
                </button>
              </div>
            </form>

            <div className="space-y-1.5">
              {tasks.length === 0 ? (
                <div className="text-center py-6 text-white/40 text-[11px]">
                  Abhi koi task nahi hai. Voice me bolo: &quot;Radha mere tasks me add karo...&quot;
                </div>
              ) : (
                tasks.map((task) => (
                  <div
                    key={task.id}
                    className={`flex items-center justify-between gap-2 p-2.5 rounded-lg border transition-colors ${
                      task.completed
                        ? "bg-white/[0.02] border-white/5 opacity-55"
                        : "bg-black/45 border-white/15"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => onToggleTask(task.id, !task.completed)}
                      className="flex items-center gap-2 text-left min-w-0 flex-1 cursor-pointer"
                    >
                      {task.completed ? (
                        <CheckCircle2 size={15} style={{ color: primary }} className="shrink-0" />
                      ) : (
                        <Circle size={15} className="text-white/40 shrink-0" />
                      )}
                      <div className="min-w-0">
                        <div className={`text-xs text-white break-words ${task.completed ? "line-through" : ""}`}>
                          {task.title}
                        </div>
                        <div
                          className={`text-[9px] uppercase ${
                            task.priority === "high"
                              ? "text-red-400"
                              : task.priority === "low"
                              ? "text-cyan-300"
                              : "text-amber-300"
                          }`}
                        >
                          PRIORITY: {task.priority}
                        </div>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteTask(task.id)}
                      className="p-1.5 rounded text-white/40 hover:text-red-400 cursor-pointer shrink-0"
                      title="Delete Task"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))
              )}
            </div>
          </>
        )}

        {/* SECTION 3: LIVE WEB INTEL & REAL-TIME NEWS */}
        {section === "web" && (
          <>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                runLiveSearch(searchQuery);
              }}
              className="flex gap-1.5"
            >
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search live news, BTC price, cricket..."
                className="flex-1 min-w-0 bg-white/5 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/35 outline-none focus:border-emerald-400"
              />
              <button
                type="submit"
                disabled={searching || !searchQuery.trim()}
                className="px-3 py-2 rounded-lg text-black font-bold flex items-center gap-1 disabled:opacity-40 cursor-pointer shrink-0"
                style={{ backgroundColor: primary }}
              >
                {searching ? <Loader2 size={13} className="animate-spin" /> : <Search size={13} />}
              </button>
            </form>

            {/* Quick Live Intel Presets */}
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { label: "India Top News", q: "Latest breaking top news in India today" },
                { label: "Bitcoin & Crypto", q: "Live Bitcoin and Ethereum price today in INR and USD" },
                { label: "Live Cricket", q: "Latest India cricket live score and match update today" },
                { label: "Cyber & Tech", q: "Latest cybersecurity and AI technology news today" },
              ].map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => runLiveSearch(preset.q)}
                  className="py-1.5 px-2.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-[10px] text-white/80 text-left truncate cursor-pointer"
                >
                  &gt; {preset.label}
                </button>
              ))}
            </div>

            {searchError && (
              <div className="p-2.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-[11px]">
                {searchError}
              </div>
            )}

            {searchResult && (
              <div className="p-3 rounded-xl bg-black/60 border border-white/15 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider" style={{ color: primary }}>
                    LIVE GROUNDED INTEL
                  </span>
                  <button
                    type="button"
                    onClick={() => onSpeakText(searchResult.answer)}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[10px] text-white cursor-pointer"
                  >
                    <Volume2 size={11} />
                    <span>SPEAK</span>
                  </button>
                </div>
                <p className="text-xs text-white/90 whitespace-pre-wrap leading-relaxed font-sans">
                  {searchResult.answer}
                </p>
                {searchResult.sources.length > 0 && (
                  <div className="pt-2 border-t border-white/10 space-y-1">
                    <div className="text-[9px] text-white/45 uppercase">SOURCES</div>
                    {searchResult.sources.map((src, i) => (
                      <a
                        key={i}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1.5 text-[10px] hover:underline truncate"
                        style={{ color: secondary }}
                      >
                        <ExternalLink size={10} className="shrink-0" />
                        <span className="truncate">{src.title || src.uri}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}

        {/* SECTION 4: DOCUMENT / PHOTO / SCREENSHOT / CODE SCANNER */}
        {section === "scanner" && (
          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-black/50 border border-dashed border-white/20 space-y-2.5 text-center">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.pdf,.txt,.js,.ts,.tsx,.py,.json,.md,.html,.css,.log"
                onChange={handleFilePick}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 px-3 rounded-lg bg-white/[0.04] hover:bg-white/[0.09] border border-white/10 flex flex-col items-center gap-1.5 cursor-pointer"
              >
                <Upload size={18} style={{ color: primary }} />
                <span className="text-xs text-white/90 font-semibold">
                  {selectedFile ? selectedFile.name : "Upload Photo, Screenshot, PDF or Code"}
                </span>
                <span className="text-[10px] text-white/45">
                  PNG · JPG · PDF · PY · TS · TXT · LOG
                </span>
              </button>

              {selectedFile?.previewUrl && (
                <img
                  src={selectedFile.previewUrl}
                  alt="Uploaded preview"
                  className="max-h-36 mx-auto rounded-lg border border-white/15 object-contain"
                />
              )}

              <input
                type="text"
                value={scanQuestion}
                onChange={(e) => setScanQuestion(e.target.value)}
                placeholder="Optional question (e.g., Is error ko fix kaise karu?)"
                className="w-full bg-white/5 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/35 outline-none"
              />

              <button
                type="button"
                disabled={!selectedFile || scanning}
                onClick={handleRunScan}
                className="w-full py-2 rounded-lg text-xs font-bold text-black flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
                style={{ backgroundColor: primary }}
              >
                {scanning ? <Loader2 size={13} className="animate-spin" /> : <FileSearch size={13} />}
                <span>{scanning ? "ANALYZING..." : "SCAN WITH RADHA AI"}</span>
              </button>
            </div>

            {vaultSyncNotice && (
              <div className="p-2 rounded-lg bg-emerald-500/15 border border-emerald-500/35 text-emerald-300 text-[11px]">
                {vaultSyncNotice}
              </div>
            )}

            {scanError && (
              <div className="p-2.5 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-[11px]">
                {scanError}
              </div>
            )}

            {scanOutput && (
              <div className="p-3 rounded-xl bg-black/60 border border-white/15 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider" style={{ color: primary }}>
                    SCAN REPORT
                  </span>
                  <button
                    type="button"
                    onClick={() => onSpeakText(scanOutput)}
                    className="flex items-center gap-1 px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-[10px] text-white cursor-pointer"
                  >
                    <Volume2 size={11} />
                    <span>SPEAK</span>
                  </button>
                </div>
                <p className="text-xs text-white/90 whitespace-pre-wrap leading-relaxed font-sans">
                  {scanOutput}
                </p>
              </div>
            )}
          </div>
        )}

        {/* SECTION 5: GOOGLE WORKSPACE (GMAIL + CALENDAR) */}
        {section === "workspace" && (
          <div className="space-y-3">
            {!wsSignedIn ? (
              <div className="p-4 rounded-xl bg-black/55 border border-white/15 text-center space-y-3">
                <div className="text-xs text-white/85 font-sans">
                  Apna Google Account connect karein taaki Radha aapke <strong className="text-white">Gmail Inbox</strong> aur <strong className="text-white">Google Calendar</strong> manage kar sake.
                </div>

                {/* Official Google Sign-In Button Styling */}
                <button
                  type="button"
                  onClick={handleWorkspaceSignIn}
                  disabled={wsLoading}
                  className="mx-auto flex items-center justify-center gap-3 px-4 py-2.5 rounded-lg bg-white text-[#1f1f1f] hover:bg-gray-100 font-sans font-medium text-xs shadow-md transition-colors cursor-pointer disabled:opacity-50"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
                    />
                    <path
                      fill="#34A853"
                      d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.565 24 12.255 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 000 10.76l3.98-3.09z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.69 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
                    />
                  </svg>
                  <span>{wsLoading ? "Connecting..." : "Sign in with Google"}</span>
                </button>

                {wsError && <p className="text-[11px] text-red-400">{wsError}</p>}
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between p-2.5 rounded-lg bg-black/55 border border-white/15">
                  <div className="min-w-0">
                    <div className="text-[9px] text-emerald-300 uppercase">CONNECTED</div>
                    <div className="text-[11px] text-white truncate">{wsEmail || "Google Account"}</div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={loadWorkspaceData}
                      className="p-1.5 rounded bg-white/5 hover:bg-white/15 text-white/80 cursor-pointer"
                      title="Refresh Gmail & Calendar"
                    >
                      <RefreshCw size={13} className={wsLoading ? "animate-spin" : ""} />
                    </button>
                    <button
                      type="button"
                      onClick={handleWorkspaceSignOut}
                      className="p-1.5 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 cursor-pointer"
                      title="Sign out"
                    >
                      <LogOut size={13} />
                    </button>
                  </div>
                </div>

                {wsError && (
                  <div className="p-2 rounded-lg bg-red-500/15 border border-red-500/30 text-red-300 text-[11px]">
                    {wsError}
                  </div>
                )}

                {/* Gmail Section */}
                <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-white/75">
                      <Mail size={12} style={{ color: primary }} />
                      GMAIL INBOX ({emails.length})
                    </span>
                    {emails.length > 0 && (
                      <button
                        type="button"
                        onClick={handleSummarizeEmails}
                        className="px-2 py-0.5 rounded text-[10px] font-bold text-black cursor-pointer"
                        style={{ backgroundColor: primary }}
                      >
                        RADHA SUMMARIZE
                      </button>
                    )}
                  </div>
                  {emails.length === 0 ? (
                    <div className="text-[11px] text-white/40 py-2">
                      {wsLoading ? "Loading emails..." : "No recent inbox messages found."}
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-44 overflow-y-auto scrollbar-thin pr-1">
                      {emails.map((mail) => (
                        <div
                          key={mail.id}
                          className="p-2 rounded-lg bg-white/[0.03] border border-white/10 space-y-0.5"
                        >
                          <div className="text-[11px] font-semibold text-white truncate">
                            {mail.subject}
                          </div>
                          <div className="text-[9.5px] text-white/50 truncate">{mail.from}</div>
                          <div className="text-[10px] text-white/65 line-clamp-2 font-sans">
                            {mail.snippet}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Google Calendar Section */}
                <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2.5">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider text-white/75">
                    <Calendar size={12} style={{ color: secondary }} />
                    GOOGLE CALENDAR ({calEvents.length})
                  </div>

                  {/* Add Calendar Event Form */}
                  <form onSubmit={handleRequestCreateEvent} className="space-y-2 border-b border-white/10 pb-2.5">
                    <input
                      type="text"
                      value={evSummary}
                      onChange={(e) => setEvSummary(e.target.value)}
                      placeholder="New meeting / event title..."
                      className="w-full bg-white/5 border border-white/15 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-white/35 outline-none"
                    />
                    <div className="flex gap-1.5">
                      <input
                        type="datetime-local"
                        value={evDateTime}
                        onChange={(e) => setEvDateTime(e.target.value)}
                        className="flex-1 min-w-0 bg-[#091217] border border-white/15 rounded-lg px-2 py-1.5 text-[11px] text-white outline-none"
                      />
                      <select
                        value={evDurationMins}
                        onChange={(e) => setEvDurationMins(e.target.value)}
                        className="bg-[#091217] border border-white/15 rounded-lg px-2 py-1.5 text-[11px] text-white outline-none"
                      >
                        <option value="30">30m</option>
                        <option value="60">1h</option>
                        <option value="120">2h</option>
                      </select>
                    </div>
                    <button
                      type="submit"
                      disabled={!evSummary.trim()}
                      className="w-full py-1.5 rounded-lg text-[11px] font-bold text-black disabled:opacity-40 cursor-pointer"
                      style={{ backgroundColor: secondary }}
                    >
                      SCHEDULE CALENDAR EVENT
                    </button>
                  </form>

                  {/* Upcoming Events List */}
                  <div className="space-y-1.5 max-h-40 overflow-y-auto scrollbar-thin pr-1">
                    {calEvents.length === 0 ? (
                      <div className="text-[11px] text-white/40 py-1">
                        {wsLoading ? "Loading calendar..." : "No upcoming events."}
                      </div>
                    ) : (
                      calEvents.map((ev) => (
                        <div
                          key={ev.id}
                          className="p-2 rounded-lg bg-white/[0.03] border border-white/10 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="text-[11px] text-white font-semibold truncate">
                              {ev.summary}
                            </div>
                            <div className="text-[9.5px] text-white/50">
                              {ev.start ? new Date(ev.start).toLocaleString() : ""}
                            </div>
                          </div>
                          {ev.htmlLink && (
                            <a
                              href={ev.htmlLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 text-cyan-300 hover:text-white shrink-0"
                            >
                              <ExternalLink size={12} />
                            </a>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* SECTION 6: MOOD DIARY & BONDING LEVEL */}
        {section === "mood" && (
          <div className="space-y-3">
            {/* Bonding Card */}
            <div
              className="p-3.5 rounded-xl bg-black/55 border space-y-2.5"
              style={{ borderColor: `${primary}40` }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-white/50 uppercase">BONDING RANK</div>
                  <div className="text-sm font-bold text-white">{rankName}</div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold" style={{ color: primary }}>
                    LVL {bonding.level}
                  </div>
                  <div className="text-[9px] text-white/45">{bonding.xp} TOTAL XP</div>
                </div>
              </div>
              <div className="space-y-1">
                <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${xpIntoLevel}%`,
                      background: `linear-gradient(90deg, ${primary}, ${secondary})`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[9px] text-white/45">
                  <span>{xpIntoLevel}/100 XP TO NEXT LEVEL</span>
                  <span>CURRENT MOOD: {EMOTION_META[currentEmotion].hindiLabel}</span>
                </div>
              </div>
            </div>

            {/* Quick Mood Check-In */}
            <div className="p-3 rounded-xl bg-black/50 border border-white/10 space-y-2">
              <div className="text-[10px] text-white/60 uppercase tracking-wider">
                LOG DAILY MOOD CHECK-IN (+20 XP)
              </div>
              <input
                type="text"
                value={moodNote}
                onChange={(e) => setMoodNote(e.target.value)}
                placeholder="Aaj kaisa feel ho raha hai Boss?"
                className="w-full bg-white/5 border border-white/15 rounded-lg px-3 py-2 text-xs text-white placeholder:text-white/35 outline-none"
              />
              <div className="grid grid-cols-4 gap-1.5">
                {(["happy", "caring", "playful", "excited", "angry", "sad", "hurt", "neutral"] as RadhaEmotion[]).map(
                  (em) => (
                    <button
                      key={em}
                      type="button"
                      onClick={async () => {
                        await onLogMood(em, moodNote.trim() || `Feeling ${EMOTION_META[em].label}`);
                        setMoodNote("");
                      }}
                      className="py-1.5 px-1 rounded-lg bg-white/[0.04] hover:bg-white/[0.12] border border-white/10 text-[10px] text-white/85 cursor-pointer truncate"
                      style={{ borderColor: `${EMOTION_META[em].color}45` }}
                    >
                      {EMOTION_META[em].hindiLabel}
                    </button>
                  )
                )}
              </div>
            </div>

            {/* Mood Diary Timeline */}
            <div className="space-y-1.5">
              <div className="text-[10px] text-white/50 uppercase tracking-wider">
                MOOD DIARY HISTORY
              </div>
              {moods.length === 0 ? (
                <div className="text-center py-5 text-white/40 text-[11px]">
                  Jaise-jaise aap Radha se baat karenge, aapki mood diary aur bonding XP badhti jayegi.
                </div>
              ) : (
                moods.slice(0, 20).map((entry) => {
                  const meta = EMOTION_META[entry.emotion] || EMOTION_META.neutral;
                  return (
                    <div
                      key={entry.id}
                      className="p-2.5 rounded-lg bg-black/45 border border-white/10 flex items-start justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-2 h-2 rounded-full shrink-0"
                            style={{ backgroundColor: meta.color }}
                          />
                          <span className="text-[11px] font-bold" style={{ color: meta.color }}>
                            {meta.hindiLabel} · {meta.label}
                          </span>
                        </div>
                        <p className="text-[11px] text-white/80 mt-0.5 font-sans break-words">
                          {entry.note}
                        </p>
                      </div>
                      <span className="text-[9px] text-white/35 shrink-0">
                        {new Date(entry.createdAt).toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}
      </div>

      {/* MANDATORY Explicit Confirmation Modal before creating Google Calendar Event */}
      {pendingConfirmEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-[#061015] border border-cyan-400/40 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-300">
                <AlertTriangle size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Confirm Calendar Event</h3>
                <p className="text-[11px] text-white/55 font-sans">
                  Kya aap is event ko apne Google Calendar me save karna chahte hain?
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-white/5 border border-white/10 space-y-1 text-xs">
              <div className="text-white font-semibold">{pendingConfirmEvent.summary}</div>
              <div className="text-cyan-300 text-[11px]">{pendingConfirmEvent.displayTime}</div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                disabled={creatingEvent}
                onClick={() => setPendingConfirmEvent(null)}
                className="px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-xs text-white/80 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={creatingEvent}
                onClick={handleConfirmCreateEvent}
                className="px-4 py-2 rounded-lg text-xs font-bold text-black flex items-center gap-1.5 cursor-pointer"
                style={{ backgroundColor: primary }}
              >
                {creatingEvent && <Loader2 size={12} className="animate-spin" />}
                <span>Confirm &amp; Create</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
