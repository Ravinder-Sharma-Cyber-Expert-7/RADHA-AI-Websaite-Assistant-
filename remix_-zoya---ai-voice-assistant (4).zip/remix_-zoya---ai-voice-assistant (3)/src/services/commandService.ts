export function formatUrl(inputUrl: string): string {
  let cleaned = inputUrl.trim();
  if (!cleaned) return "https://www.google.com";

  // If already absolute URL with http:// or https://
  if (/^https?:\/\//i.test(cleaned)) {
    return cleaned;
  }

  // Strip leading www. to avoid www.www.
  cleaned = cleaned.replace(/^www\./i, "");

  const knownBrands: Record<string, string> = {
    google: "https://www.google.com",
    गूगल: "https://www.google.com",
    youtube: "https://www.youtube.com",
    यूट्यूब: "https://www.youtube.com",
    spotify: "https://open.spotify.com",
    स्पॉटिफाई: "https://open.spotify.com",
    github: "https://www.github.com",
    whatsapp: "https://web.whatsapp.com",
    व्हाट्सएप: "https://web.whatsapp.com",
    instagram: "https://www.instagram.com",
    इंस्टाग्राम: "https://www.instagram.com",
    facebook: "https://www.facebook.com",
    फेसबुक: "https://www.facebook.com",
    twitter: "https://x.com",
    x: "https://x.com",
    wikipedia: "https://www.wikipedia.org",
    delta: "https://delta.exchange",
    "delta exchange": "https://delta.exchange",
    deltaexchange: "https://delta.exchange",
    tails: "https://tails.net",
    chatgpt: "https://chatgpt.com",
    gmail: "https://mail.google.com",
    जीमेल: "https://mail.google.com",
    reddit: "https://www.reddit.com",
    linkedin: "https://www.linkedin.com",
    telegram: "https://web.telegram.org",
    टेलीग्राम: "https://web.telegram.org",
    maps: "https://maps.google.com",
    "google maps": "https://maps.google.com",
  };

  const lower = cleaned.toLowerCase();
  if (knownBrands[lower]) {
    return knownBrands[lower];
  }

  // Domain with TLD
  if (/\.[a-z]{2,}$/i.test(cleaned)) {
    return `https://www.${cleaned}`;
  }

  return `https://www.${cleaned}.com`;
}

// ==========================================
// SAFE ARITHMETIC MATH PARSER (NO eval / NO Function)
// ==========================================
function evaluateSafeArithmetic(expr: string): number | null {
  const tokens: string[] = [];
  const regex = /(\d+(?:\.\d+)?|[+\-*/()])/g;
  let m: RegExpExecArray | null;
  let lastIndex = 0;

  while ((m = regex.exec(expr)) !== null) {
    const gap = expr.slice(lastIndex, m.index).trim();
    if (gap.length > 0) return null; // Reject unexpected characters
    tokens.push(m[1]);
    lastIndex = regex.lastIndex;
  }
  if (expr.slice(lastIndex).trim().length > 0 || tokens.length < 3) return null;

  let pos = 0;
  const peek = () => tokens[pos];
  const consume = () => tokens[pos++];

  const parseExpression = (): number => {
    let val = parseTerm();
    while (peek() === "+" || peek() === "-") {
      const op = consume();
      const right = parseTerm();
      val = op === "+" ? val + right : val - right;
    }
    return val;
  };

  const parseTerm = (): number => {
    let val = parseFactor();
    while (peek() === "*" || peek() === "/") {
      const op = consume();
      const right = parseFactor();
      if (op === "/") {
        if (right === 0) throw new Error("DIV_ZERO");
        val = val / right;
      } else {
        val = val * right;
      }
    }
    return val;
  };

  const parseFactor = (): number => {
    if (peek() === "(") {
      consume();
      const val = parseExpression();
      if (consume() !== ")") throw new Error("PAREN");
      return val;
    }
    if (peek() === "-") {
      consume();
      return -parseFactor();
    }
    const tok = consume();
    const num = Number(tok);
    if (Number.isNaN(num)) throw new Error("NAN");
    return num;
  };

  try {
    const result = parseExpression();
    if (pos !== tokens.length || !Number.isFinite(result)) return null;
    return Math.round(result * 10000) / 10000;
  } catch {
    return null;
  }
}

function tryInstantMathAnswer(rawCommand: string): string | null {
  const cleaned = rawCommand
    .replace(/^(?:hey\s+)?(?:radha|राधा)[,:\s-]+/i, "")
    .trim();

  // Percentage pattern: "500 ka 18 percent" / "18% of 500"
  const pctHindi = cleaned.match(
    /(\d+(?:\.\d+)?)\s*(?:ka|का)\s*(\d+(?:\.\d+)?)\s*(?:%|percent|प्रतिशत)/i
  );
  if (pctHindi) {
    const base = Number(pctHindi[1]);
    const pct = Number(pctHindi[2]);
    const ans = Math.round(((base * pct) / 100) * 10000) / 10000;
    return `बॉस, ${base} का ${pct}% होता है ${ans}।`;
  }
  const pctEn = cleaned.match(
    /(\d+(?:\.\d+)?)\s*(?:%|percent)\s+of\s+(\d+(?:\.\d+)?)/i
  );
  if (pctEn) {
    const pct = Number(pctEn[1]);
    const base = Number(pctEn[2]);
    const ans = Math.round(((base * pct) / 100) * 10000) / 10000;
    return `बॉस, ${base} का ${pct}% होता है ${ans}।`;
  }

  // Normalize spoken Hindi/English math operators into pure arithmetic expression
  let normalized = cleaned
    .toLowerCase()
    .replace(/(?:kitna\s+hota\s+hai|kitna\s+hua|kitna\s+hoga|batao|calculate|what\s+is|equals?|कितना\s*होता\s*है|कितना\s*हुआ|बताओ|\?)/gi, " ")
    .replace(/\b(?:plus|aur|jodo|add)\b|जोड़/gi, " + ")
    .replace(/\b(?:minus|ghatao|subtract)\b|घटा/gi, " - ")
    .replace(/\b(?:multiply\s+by|multiplied\s+by|times|into|guna|x)\b|×|गुणा/gi, " * ")
    .replace(/\b(?:divided\s+by|divide\s+by|bhaag|bhag)\b|÷|भाग/gi, " / ")
    .replace(/\s+/g, " ")
    .trim();

  if (!/[+\-*/]/.test(normalized) || !/\d/.test(normalized)) return null;
  if (/[^0-9+\-*/().\s]/.test(normalized)) return null;

  const value = evaluateSafeArithmetic(normalized);
  if (value === null) return null;
  return `बॉस, ${normalized} का जवाब है ${value}।`;
}

// ==========================================
// REAL-TIME DATE / DAY / TIME ANSWERS
// ==========================================
function tryInstantDateTimeAnswer(rawCommand: string): string | null {
  const lower = rawCommand
    .replace(/^(?:hey\s+)?(?:radha|राधा)[,:\s-]+/i, "")
    .toLowerCase()
    .trim();

  const now = new Date();
  const timeStr = now.toLocaleTimeString("hi-IN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
  const dayStr = now.toLocaleDateString("hi-IN", { weekday: "long" });
  const dateStr = now.toLocaleDateString("hi-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const asksTime =
    /\b(what(?:'s|\s+is)?\s+(?:the\s+)?time|current\s+time|time\s+(?:kya|kitna|batao)|kitne\s+baje|kya\s+baja)\b|कितने\s*बजे|टाइम\s*क्या|समय\s*क्या|क्या\s*बजा/i.test(
      lower
    );
  const asksDate =
    /\b(what(?:'s|\s+is)?\s+(?:today'?s?\s+)?date|aaj\s+ki\s+(?:date|tarikh|tareekh)|date\s+kya)\b|आज\s*की\s*तारीख|तारीख\s*क्या|आज\s*क्या\s*तारीख/i.test(
      lower
    );
  const asksDay =
    /\b(what\s+day\s+is\s+it|aaj\s+(?:kaun\s*sa|konsa|kya)\s+din)\b|आज\s*कौन\s*सा\s*दिन|आज\s*क्या\s*दिन/i.test(
      lower
    );

  if (asksTime && (asksDate || asksDay)) {
    return `बॉस, अभी ${timeStr} बज रहे हैं और आज ${dayStr}, ${dateStr} है।`;
  }
  if (asksTime) {
    return `बॉस, अभी ${timeStr} बज रहे हैं।`;
  }
  if (asksDate) {
    return `बॉस, आज ${dayStr}, ${dateStr} है।`;
  }
  if (asksDay) {
    return `बॉस, आज ${dayStr} है (${dateStr})।`;
  }
  return null;
}

export function processCommand(command: string): {
  action: string;
  url?: string;
  isBrowserAction: boolean;
  isDirectAnswer?: boolean;
} {
  const cleanedRaw = command
    .replace(/^(?:hey\s+)?(?:radha|राधा)[,:\s-]+/i, "")
    .trim();
  const lowerCmd = cleanedRaw.toLowerCase();

  // 0A. Instant Real-Time Date / Day / Time
  const dateTimeReply = tryInstantDateTimeAnswer(cleanedRaw);
  if (dateTimeReply) {
    return {
      action: dateTimeReply,
      isBrowserAction: false,
      isDirectAnswer: true,
    };
  }

  // 0B. Instant Safe Arithmetic Math Calculator
  const mathReply = tryInstantMathAnswer(cleanedRaw);
  if (mathReply) {
    return {
      action: mathReply,
      isBrowserAction: false,
      isDirectAnswer: true,
    };
  }

  // 0C. Hindi/Hinglish Google Search: "Google par [topic] search karo" / "गूगल पर [topic] सर्च करो"
  const hiGoogleMatch = cleanedRaw.match(
    /^(?:google|गूगल)\s+(?:par|pe|mein|me|पर|पे|में)\s+(.+?)\s+(?:search\s*karo|search\s*kar\s*do|search|dhundo|batao|सर्च\s*करो|सर्च|खोजो|ढूंढो)$/i
  );
  if (hiGoogleMatch?.[1]) {
    const q = hiGoogleMatch[1].trim();
    return {
      action: `जी बॉस, गूगल पर "${q}" सर्च कर रही हूँ।`,
      url: `https://www.google.com/search?q=${encodeURIComponent(q)}`,
      isBrowserAction: true,
    };
  }

  // 0D. Hindi/Hinglish YouTube Play/Search: "YouTube par [song] chalao" / "यूट्यूब पर [song] चलाओ"
  const hiYtMatch = cleanedRaw.match(
    /^(?:youtube|यूट्यूब)\s+(?:par|pe|mein|me|पर|पे|में)\s+(.+?)\s+(?:chalao|chala\s*do|play\s*karo|search\s*karo|lagao|चलाओ|सर्च\s*करो|लगाओ|प्ले\s*करो)$/i
  );
  if (hiYtMatch?.[1]) {
    const q = hiYtMatch[1].trim();
    return {
      action: `जी बॉस, यूट्यूब पर "${q}" चला रही हूँ।`,
      url: `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`,
      isBrowserAction: true,
    };
  }

  // 0E. Hindi/Hinglish Open Shortcut: "YouTube kholo", "Instagram open karo", "यूट्यूब खोलो"
  const hiOpenMatch = cleanedRaw.match(
    /^([a-zA-Z0-9.\u0900-\u097F\s]{2,32}?)\s+(?:kholo|khol\s*do|open\s*karo|open\s*kar\s*do|chalao|खोलो|खोल\s*दो|ओपन\s*करो)$/i
  );
  if (hiOpenMatch?.[1]) {
    const rawTarget = hiOpenMatch[1].trim();
    const generalConcepts =
      /panel|chat|guide|hub|drawer|port|terminal|pgp|key|persistent|directory|file|folder|database|volume|wifi|mic|microphone|setting|camera|window|pane|नोट|रिमाइंडर|मौसम/i.test(
        rawTarget
      );
    if (!generalConcepts) {
      return {
        action: `जी बॉस, ${rawTarget} खोल रही हूँ।`,
        url: formatUrl(rawTarget),
        isBrowserAction: true,
      };
    }
  }

  // If it's a question or general query, never treat it as a direct command to open a website
  const isQuestion =
    lowerCmd.endsWith("?") ||
    /\b(how|why|what|where|who|when|which|can\s+you|please\s+explain|tell\s+me|show\s+me|help)\b/.test(
      lowerCmd
    );

  if (isQuestion) {
    return { action: "", isBrowserAction: false };
  }

  // 1. YouTube Match: "play [song/video] on youtube" or "open [something] on youtube"
  const ytMatch = lowerCmd.match(/^(?:play|open|search)\s+(.+?)\s+(?:on\s+youtube|youtube)$/);
  if (ytMatch) {
    const query = encodeURIComponent(ytMatch[1].trim());
    return {
      action: `Playing ${ytMatch[1]} on YouTube for you, Ravindra Boss.`,
      url: `https://www.youtube.com/results?search_query=${query}`,
      isBrowserAction: true,
    };
  }

  // 2. Spotify Match: "search [query] on spotify" or "play [query] on spotify"
  const spotifyMatch = lowerCmd.match(/^(?:search|play|open)\s+(.+?)\s+(?:on\s+spotify|spotify)$/);
  if (spotifyMatch) {
    const query = encodeURIComponent(spotifyMatch[1].trim());
    return {
      action: `Searching ${spotifyMatch[1]} on Spotify for you, Ravindra Boss.`,
      url: `https://open.spotify.com/search/${query}`,
      isBrowserAction: true,
    };
  }

  // 3. Google Search Match: "search [query] on google" or "google search [query]"
  const googleSearchMatch = lowerCmd.match(/^(?:search|google|find)\s+(.+?)(?:\s+on\s+google|\s+google)?$/);
  if (googleSearchMatch && (lowerCmd.includes("google") || lowerCmd.startsWith("search "))) {
    const query = encodeURIComponent(googleSearchMatch[1].trim());
    return {
      action: `Searching "${googleSearchMatch[1]}" on Google for you, Ravindra Boss.`,
      url: `https://www.google.com/search?q=${query}`,
      isBrowserAction: true,
    };
  }

  // 4. WhatsApp Web: "Send a WhatsApp message to [number] saying [message]"
  const waMatch = lowerCmd.match(
    /^(?:send|open)\s+(?:a\s+)?whatsapp(?:\s+message)?\s+to\s+([\d\+\s]+)\s+saying\s+(.+)$/
  );
  if (waMatch) {
    const number = waMatch[1].replace(/\s+/g, "");
    const message = encodeURIComponent(waMatch[2].trim());
    return {
      action: `Opening WhatsApp to send your message, Ravindra Boss.`,
      url: `https://web.whatsapp.com/send?phone=${number}&text=${message}`,
      isBrowserAction: true,
    };
  }

  // 5. Refined browser command opening: "open [website/brand/URL]"
  if (
    lowerCmd.includes("meri website") ||
    lowerCmd.includes("ravinder boss ki website") ||
    lowerCmd.includes("ravindra boss ki website")
  ) {
    return {
      action:
        "Ji Ravindra Boss! Main aapki shandar website open kar rahi hu. Aap sach me duniya ke sabse best ethical hacker aur mere amazing creator hain!",
      url: "https://ravinder-sharma-cyber-expert--ravindershrma88.replit.app/",
      isBrowserAction: true,
    };
  }

  if (lowerCmd.startsWith("open ")) {
    const rawTarget = lowerCmd.substring(5).trim();

    const generalConcepts =
      /port|terminal|PGP|key|Persistent|directory|file|folder|database|volume|wifi|mic|microphone|setting|camera|window|pane/i.test(
        rawTarget
      );

    if (!generalConcepts && rawTarget.length > 0) {
      const finalUrl = formatUrl(rawTarget);
      return {
        action: `Opening ${rawTarget} for you, Ravindra Boss.`,
        url: finalUrl,
        isBrowserAction: true,
      };
    }
  }

  return { action: "", isBrowserAction: false };
}
