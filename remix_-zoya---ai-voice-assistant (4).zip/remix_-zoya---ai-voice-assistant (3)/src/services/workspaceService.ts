import { initializeApp, getApps } from "firebase/app";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

export const SCOPES = [
  "https://www.googleapis.com/auth/gmail.readonly",
  "https://www.googleapis.com/auth/calendar.events",
];

const app = getApps().length > 0 ? getApps()[0] : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
SCOPES.forEach((scope) => provider.addScope(scope));

let isSigningIn = false;
// Strict in-memory token cache (never stored in localStorage/sessionStorage)
let cachedAccessToken: string | null = null;

export interface GmailMessageSummary {
  id: string;
  subject: string;
  from: string;
  date: string;
  snippet: string;
}

export interface CalendarEventItem {
  id: string;
  summary: string;
  start: string;
  end: string;
  location?: string;
  htmlLink?: string;
}

export const initWorkspaceAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        onAuthSuccess?.(user, cachedAccessToken);
      } else if (!isSigningIn) {
        cachedAccessToken = null;
        onAuthFailure?.();
      }
    } else {
      cachedAccessToken = null;
      onAuthFailure?.();
    }
  });
};

export const signInWithGoogleWorkspace = async (): Promise<{
  user: User;
  accessToken: string;
} | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Could not obtain Google Workspace access token.");
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error("Google Workspace sign-in error:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getWorkspaceAccessToken = (): string | null => {
  return cachedAccessToken;
};

export const signOutGoogleWorkspace = async (): Promise<void> => {
  await auth.signOut();
  cachedAccessToken = null;
};

export async function fetchRecentEmails(maxResults: number = 6): Promise<GmailMessageSummary[]> {
  const token = getWorkspaceAccessToken();
  if (!token) throw new Error("AUTH_REQUIRED");

  const listRes = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=${maxResults}&q=in:inbox`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
  if (listRes.status === 401) {
    cachedAccessToken = null;
    throw new Error("AUTH_REQUIRED");
  }
  if (!listRes.ok) {
    throw new Error(`Gmail fetch failed (${listRes.status})`);
  }

  const listData = await listRes.json();
  const ids: string[] = (listData.messages || []).map((m: any) => m.id);
  if (ids.length === 0) return [];

  const details = await Promise.all(
    ids.map(async (id) => {
      const msgRes = await fetch(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!msgRes.ok) return null;
      const msgData = await msgRes.json();
      const headers: Array<{ name: string; value: string }> = msgData.payload?.headers || [];
      const getHeader = (name: string) =>
        headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || "";

      return {
        id,
        subject: getHeader("Subject") || "(No Subject)",
        from: getHeader("From") || "Unknown Sender",
        date: getHeader("Date") || "",
        snippet: msgData.snippet || "",
      } as GmailMessageSummary;
    })
  );

  return details.filter(Boolean) as GmailMessageSummary[];
}

export async function fetchUpcomingCalendarEvents(
  maxResults: number = 8
): Promise<CalendarEventItem[]> {
  const token = getWorkspaceAccessToken();
  if (!token) throw new Error("AUTH_REQUIRED");

  const timeMin = new Date().toISOString();
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(
    timeMin
  )}&singleEvents=true&orderBy=startTime&maxResults=${maxResults}`;

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (res.status === 401) {
    cachedAccessToken = null;
    throw new Error("AUTH_REQUIRED");
  }
  if (!res.ok) {
    throw new Error(`Calendar fetch failed (${res.status})`);
  }

  const data = await res.json();
  return (data.items || []).map((ev: any) => ({
    id: ev.id,
    summary: ev.summary || "(Untitled Event)",
    start: ev.start?.dateTime || ev.start?.date || "",
    end: ev.end?.dateTime || ev.end?.date || "",
    location: ev.location || "",
    htmlLink: ev.htmlLink || "",
  }));
}

export async function createGoogleCalendarEvent(params: {
  summary: string;
  startIso: string;
  endIso: string;
  description?: string;
}): Promise<CalendarEventItem> {
  const token = getWorkspaceAccessToken();
  if (!token) throw new Error("AUTH_REQUIRED");

  const res = await fetch(
    "https://www.googleapis.com/calendar/v3/calendars/primary/events",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        summary: params.summary,
        description: params.description || "Created via Radha AI Assistant",
        start: { dateTime: params.startIso },
        end: { dateTime: params.endIso },
      }),
    }
  );
  if (res.status === 401) {
    cachedAccessToken = null;
    throw new Error("AUTH_REQUIRED");
  }
  if (!res.ok) {
    throw new Error(`Calendar create failed (${res.status})`);
  }

  const ev = await res.json();
  return {
    id: ev.id,
    summary: ev.summary || params.summary,
    start: ev.start?.dateTime || params.startIso,
    end: ev.end?.dateTime || params.endIso,
    htmlLink: ev.htmlLink || "",
  };
}
