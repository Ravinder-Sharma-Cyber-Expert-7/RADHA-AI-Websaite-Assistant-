import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  AlarmClock,
  BarChart3,
  BookOpen,
  Brain,
  Camera,
  CameraOff,
  CloudSun,
  FileSearch,
  Hand,
  Keyboard,
  Layers,
  Loader2,
  MessageSquare,
  Mic,
  MicOff,
  MonitorOff,
  MonitorUp,
  Power,
  Radio,
  ScanFace,
  Send,
  Shield,
  SlidersHorizontal,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { getRadhaResponse, getRadhaAudio, resetRadhaSession } from "./services/geminiService";
import { processCommand } from "./services/commandService";
import {
  LiveSessionManager,
  isFarewellPhrase,
  isMeaningfulTranscript,
} from "./services/liveService";
import {
  BondingState,
  ChatMessage,
  MemoryItem,
  MoodEntry,
  OwnerFaceVerificationResult,
  RadhaConfig,
  RadhaEmotion,
  ReminderItem,
  SessionContextState,
  TaskItem,
  addPersistentMemory,
  clearServerMessages,
  createDefaultSessionContext,
  createPersistentReminder,
  createPersistentTask,
  deletePersistentMemory,
  deletePersistentReminder,
  deletePersistentTask,
  detectEmotionFromText,
  extractBackgroundMemories,
  fetchPersistentState,
  loadLocalConfig,
  loadLocalMemories,
  loadLocalMessages,
  loadLocalSessionContext,
  logMoodEntry,
  markReminderCompleted,
  persistMessage,
  persistSessionContext,
  refreshSessionContextSummary,
  saveLocalMemories,
  saveLocalMessages,
  saveLocalSessionContext,
  savePersistentConfig,
  togglePersistentTask,
  updateSessionContextFromMessage,
  verifyOwnerFace,
} from "./services/memoryService";
import Visualizer from "./components/Visualizer";
import PermissionModal from "./components/PermissionModal";
import TailsGuide from "./components/TailsGuide";
import WeatherWidget from "./components/WeatherWidget";
import CompactChatBox from "./components/CompactChatBox";
import AdminPanel from "./components/AdminPanel";
import HackerTelemetryPanel from "./components/HackerTelemetryPanel";
import SmartCommandHub, { SmartHubSection } from "./components/SmartCommandHub";
import NeuralConsciousnessField from "./components/NeuralConsciousnessField";
import SocialWorkspacePanel from "./components/SocialWorkspacePanel";
import CommandDrawer from "./components/CommandDrawer";
import {
  LiveWeatherData,
  detectWeatherVoiceQuery,
  fetchCurrentLocationWeather,
  fetchWeatherByCity,
  formatWeatherHindiReply,
  loadCachedWeather,
} from "./services/weatherService";
import {
  DeviceBatteryStatus,
  VoiceNoteItem,
  acquireScreenWakeLock,
  addVoiceNote,
  deleteVoiceNote,
  detectNoteOrReminderCommand,
  loadVoiceNotes,
  releaseScreenWakeLock,
  subscribeRealBattery,
} from "./services/deviceCareService";
import {
  BiologicalStatusData,
  clearBiologicalStatus,
  connectAndSyncGoogleFit,
  loadBiologicalStatus,
  parseAppleHealthFile,
  syncHealthWebhookUrl,
} from "./services/fitnessService";
import {
  BossSentimentRecord,
  analyzeBossSentimentDeep,
  analyzeBossSentimentInstant,
  loadLocalSentiments,
  saveLocalSentiments,
} from "./services/sentimentService";
import {
  DailyRoutineState,
  detectRoutineIntentFromMessage,
  evaluateProactiveRoutineCheck,
  loadDailyRoutineState,
  markRoutineAsked,
  saveDailyRoutineState,
} from "./services/routineCareService";
import {
  SocialWorkspaceConfig,
  SocialWorkspaceSnapshot,
  buildSocialWorkspaceVoiceBriefing,
  detectSocialBriefingQuery,
  fetchSocialWorkspaceSnapshot,
  getDemoSocialWorkspaceSnapshot,
  loadSocialWorkspaceConfig,
  saveSocialWorkspaceConfig,
} from "./services/socialWorkspaceService";
import {
  getUnlockedLivePlaybackContext,
  isServerTtsCoolingDown,
  playPCM,
  speakBrowserHindiFallback,
  stopActivePCM,
  streamAndPlayRadhaAudio,
  unlockAudioPlayback,
} from "./utils/audioUtils";
import { motion, AnimatePresence } from "motion/react";

const WAKE_WORD_GREETINGS = [
  "जी बॉस, बताइए!",
  "हाँ बॉस, सुन रही हूँ!",
  "जी बॉस, क्या हाल है?",
  "बोलिए बॉस, क्या काम है?",
];

type AppState = "idle" | "listening" | "processing" | "speaking";

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

// Synthesize crisp cyber chime on the already-unlocked AudioContext (never starts suspended!)
function playCyberTone(type: "wake" | "alarm") {
  try {
    const ctx = getUnlockedLivePlaybackContext();
    if (!ctx) return;
    if (ctx.state === "suspended") {
      ctx.resume().catch(() => {});
    }
    const now = ctx.currentTime;
    const freqs = type === "alarm" ? [880, 1175, 880, 1318] : [587, 880];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type === "alarm" ? "triangle" : "sine";
      osc.frequency.setValueAtTime(f, now + idx * 0.12);
      gain.gain.setValueAtTime(0.001, now + idx * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.14, now + idx * 0.12 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.11);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.12);
    });
  } catch {}
}

export default function App() {
  const [appState, setAppState] = useState<AppState>("idle");
  const [radhaConfig, setRadhaConfig] = useState<RadhaConfig>(() => loadLocalConfig());
  const radhaConfigRef = useRef(radhaConfig);
  const [memories, setMemories] = useState<MemoryItem[]>(() => loadLocalMemories());
  const memoriesRef = useRef(memories);
  const [sessionContext, setSessionContext] = useState<SessionContextState>(() =>
    loadLocalSessionContext()
  );
  const sessionContextRef = useRef(sessionContext);
  const [radhaEmotion, setRadhaEmotion] = useState<RadhaEmotion>(
    () => loadLocalSessionContext().lastEmotion || "neutral"
  );
  const radhaEmotionRef = useRef(radhaEmotion);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  const [messages, setMessages] = useState<ChatMessage[]>(() => loadLocalMessages());
  const messagesRef = useRef(messages);
  const unsummarizedTurnsRef = useRef(0);
  const sessionSummaryTurnsRef = useRef(0);

  // Stage 2 Smart Features State
  const [reminders, setReminders] = useState<ReminderItem[]>([]);
  const remindersRef = useRef(reminders);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const tasksRef = useRef(tasks);
  const [moods, setMoods] = useState<MoodEntry[]>([]);
  const [sentiments, setSentiments] = useState<BossSentimentRecord[]>(() => loadLocalSentiments());
  const sentimentsRef = useRef(sentiments);
  const [bonding, setBonding] = useState<BondingState>({ xp: 120, level: 2, interactions: 0 });
  const bondingRef = useRef(bonding);
  const [cyberLogs, setCyberLogs] = useState<string[]>([]);
  const [activeAlarmBanner, setActiveAlarmBanner] = useState<ReminderItem | null>(null);
  const [noticeToast, setNoticeToast] = useState<string | null>(null);
  const [wakeWordEnabled, setWakeWordEnabled] = useState(false);
  const [smartHubSection, setSmartHubSection] = useState<SmartHubSection>("sentiment");
  const [ownerFaceStatus, setOwnerFaceStatus] = useState<
    "idle" | "scanning" | "verified" | "guest" | "spoof"
  >("idle");
  const [ownerFaceInfo, setOwnerFaceInfo] = useState<OwnerFaceVerificationResult | null>(null);
  const lastMoodLogTimeRef = useRef<number>(0);
  const isStartingSessionRef = useRef<boolean>(false);
  const deepSentimentCounterRef = useRef<number>(0);
  const faceScanTimerRef = useRef<number | null>(null);
  const faceScanInFlightRef = useRef<boolean>(false);

  // Upgrade 1: Proactive Daily Routine & Anti-Parrot Care State
  const [routineState, setRoutineState] = useState<DailyRoutineState>(() =>
    loadDailyRoutineState()
  );
  const routineStateRef = useRef<DailyRoutineState>(routineState);

  // Upgrade 2: Rotating Wake-Word Instant Greeting Index
  const wakeGreetingIdxRef = useRef<number>(0);

  // Upgrade 4: Modular Social Media & Workspace Monitor State
  const [isInsightsOpen, setIsInsightsOpen] = useState<boolean>(false);
  const [socialConfig, setSocialConfig] = useState<SocialWorkspaceConfig>(() =>
    loadSocialWorkspaceConfig()
  );
  const socialConfigRef = useRef<SocialWorkspaceConfig>(socialConfig);
  const [socialSnapshot, setSocialSnapshot] = useState<SocialWorkspaceSnapshot>(() =>
    getDemoSocialWorkspaceSnapshot(loadSocialWorkspaceConfig())
  );
  const socialSnapshotRef = useRef<SocialWorkspaceSnapshot>(socialSnapshot);
  const [isSocialRefreshing, setIsSocialRefreshing] = useState<boolean>(false);

  // ==============================================================
  // MASTER UPGRADE: STRICT MANUAL START GATE + LIVE REAL MODULES
  // ==============================================================
  // Strict Manual Start Gate: Default FALSE — Zero auto-listening, zero auto-timers, zero ghost responses
  const [isSystemActive, setIsSystemActive] = useState<boolean>(false);
  const isSystemActiveRef = useRef<boolean>(false);
  const systemSessionTokenRef = useRef<number>(0);
  const lastUserInteractionRef = useRef<number>(Date.now());

  // Hidden-by-default glassmorphic Command Drawer
  const [isCommandDrawerOpen, setIsCommandDrawerOpen] = useState<boolean>(false);

  // 100% Real Live Weather Engine (Open-Meteo + Browser GPS)
  const [liveWeather, setLiveWeather] = useState<LiveWeatherData | null>(() => loadCachedWeather());
  const liveWeatherRef = useRef<LiveWeatherData | null>(liveWeather);
  const [isWeatherLoading, setIsWeatherLoading] = useState<boolean>(false);

  // 100% Real Device Care (Battery, Online/Offline, Wake Lock, Voice Notes)
  const [batteryStatus, setBatteryStatus] = useState<DeviceBatteryStatus>({
    supported: false,
    level: null,
    charging: false,
  });
  const hasWarnedLowBatteryRef = useRef<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [wakeLockActive, setWakeLockActive] = useState<boolean>(false);
  const [voiceNotes, setVoiceNotes] = useState<VoiceNoteItem[]>(() => loadVoiceNotes());
  const voiceNotesRef = useRef<VoiceNoteItem[]>(voiceNotes);

  // 100% Real Biological Status (Google Fit REST API & Apple Health Export)
  const [biologicalStatus, setBiologicalStatus] = useState<BiologicalStatusData>(() =>
    loadBiologicalStatus()
  );
  const [isSyncingBio, setIsSyncingBio] = useState<boolean>(false);

  useEffect(() => {
    isSystemActiveRef.current = isSystemActive;
  }, [isSystemActive]);

  useEffect(() => {
    liveWeatherRef.current = liveWeather;
  }, [liveWeather]);

  useEffect(() => {
    voiceNotesRef.current = voiceNotes;
  }, [voiceNotes]);

  useEffect(() => {
    routineStateRef.current = routineState;
  }, [routineState]);

  useEffect(() => {
    socialConfigRef.current = socialConfig;
  }, [socialConfig]);

  useEffect(() => {
    socialSnapshotRef.current = socialSnapshot;
  }, [socialSnapshot]);

  const refreshSocialWorkspace = useCallback(async (overrideCfg?: SocialWorkspaceConfig) => {
    setIsSocialRefreshing(true);
    try {
      const snap = await fetchSocialWorkspaceSnapshot(overrideCfg || socialConfigRef.current);
      setSocialSnapshot(snap);
      socialSnapshotRef.current = snap;
      return snap;
    } finally {
      setIsSocialRefreshing(false);
    }
  }, []);

  useEffect(() => {
    refreshSocialWorkspace();
  }, [refreshSocialWorkspace]);

  const handleSaveSocialConfig = useCallback(
    (nextCfg: SocialWorkspaceConfig) => {
      setSocialConfig(nextCfg);
      socialConfigRef.current = nextCfg;
      saveSocialWorkspaceConfig(nextCfg);
      refreshSocialWorkspace(nextCfg);
    },
    [refreshSocialWorkspace]
  );

  const handleToggleRoutineTask = useCallback(
    (task: "bathed" | "lunchDone" | "dinnerDone" | "water") => {
      setRoutineState((prev) => {
        const base = loadDailyRoutineState();
        const current = prev.date === base.date ? prev : base;
        const next: DailyRoutineState =
          task === "water"
            ? { ...current, waterCount: Math.min(12, current.waterCount + 1) }
            : { ...current, [task]: !current[task] };
        saveDailyRoutineState(next);
        routineStateRef.current = next;
        return next;
      });
    },
    []
  );

  // Unlock browser Web Audio on first tap/click so wake-word & async speech never play silent
  useEffect(() => {
    const unlock = () => unlockAudioPlayback();
    window.addEventListener("pointerdown", unlock, { once: true, passive: true });
    window.addEventListener("keydown", unlock, { once: true, passive: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  const pushCyberLog = useCallback((line: string) => {
    setCyberLogs((prev) => [...prev.slice(-40), line]);
  }, []);

  const showNotice = useCallback((msg: string) => {
    setNoticeToast(msg);
    setTimeout(() => {
      setNoticeToast((curr) => (curr === msg ? null : curr));
    }, 6000);
  }, []);

  // Hydrate persistent state from server SQLite DB
  useEffect(() => {
    let active = true;
    fetchPersistentState().then(
      ({
        messages: loadedMsgs,
        memories: loadedMems,
        config: loadedCfg,
        reminders: loadedRems,
        tasks: loadedTasks,
        moods: loadedMoods,
        sentiments: loadedSentiments,
        bonding: loadedBonding,
        sessionContext: loadedSessionCtx,
      }) => {
        if (!active) return;
        if (loadedMsgs.length > 0) setMessages(loadedMsgs);
        if (loadedMems.length > 0) setMemories(loadedMems);
        setRadhaConfig(loadedCfg);
        setReminders(loadedRems);
        setTasks(loadedTasks);
        setMoods(loadedMoods);
        if (loadedSentiments.length > 0) {
          setSentiments(loadedSentiments);
          sentimentsRef.current = loadedSentiments;
        }
        setBonding(loadedBonding);
        setSessionContext(loadedSessionCtx);
        sessionContextRef.current = loadedSessionCtx;
        if (loadedSessionCtx.lastEmotion && loadedSessionCtx.lastEmotion !== "neutral") {
          setRadhaEmotion(loadedSessionCtx.lastEmotion);
        }
        if (loadedSessionCtx.summary || loadedSessionCtx.activeTopic) {
          pushCyberLog(
            `SESSION CONTEXT RESTORED: ${(loadedSessionCtx.activeTopic || loadedSessionCtx.summary).slice(0, 34)}`
          );
        }
      }
    );
    return () => {
      active = false;
    };
  }, [pushCyberLog]);

  useEffect(() => {
    sentimentsRef.current = sentiments;
    saveLocalSentiments(sentiments);
  }, [sentiments]);

  useEffect(() => {
    messagesRef.current = messages;
    saveLocalMessages(messages);
  }, [messages]);

  useEffect(() => {
    sessionContextRef.current = sessionContext;
    saveLocalSessionContext(sessionContext);
  }, [sessionContext]);

  useEffect(() => {
    radhaEmotionRef.current = radhaEmotion;
    if (liveSessionRef.current) {
      liveSessionRef.current.setEmotion(radhaEmotion);
    }
  }, [radhaEmotion]);

  useEffect(() => {
    memoriesRef.current = memories;
    saveLocalMemories(memories);
  }, [memories]);

  useEffect(() => {
    remindersRef.current = reminders;
  }, [reminders]);

  useEffect(() => {
    tasksRef.current = tasks;
  }, [tasks]);

  useEffect(() => {
    bondingRef.current = bonding;
  }, [bonding]);

  useEffect(() => {
    radhaConfigRef.current = radhaConfig;
    if (liveSessionRef.current) {
      liveSessionRef.current.updateConfig(radhaConfig);
    }
  }, [radhaConfig]);

  const handleUpdateConfig = useCallback((next: RadhaConfig) => {
    setRadhaConfig(next);
    savePersistentConfig(next);
  }, []);

  const recordMoodProgress = useCallback(async (emotion: RadhaEmotion, note: string, xpGain: number = 12) => {
    const res = await logMoodEntry(emotion, note, xpGain);
    if (res) {
      setMoods((prev) => [res.mood, ...prev].slice(0, 60));
      setBonding(res.bonding);
    }
  }, []);

  const appendAndPersistMessage = useCallback(
    (sender: "user" | "radha", text: string, emotion?: RadhaEmotion) => {
      const cleanText = text.trim();
      if (!cleanText) return;

      const detected = emotion || detectEmotionFromText(cleanText, sender) || undefined;
      if (detected) {
        setRadhaEmotion(detected);
        // Log meaningful mood shifts + grow bonding XP (throttled every 25s)
        const now = Date.now();
        if (now - lastMoodLogTimeRef.current > 25_000) {
          lastMoodLogTimeRef.current = now;
          recordMoodProgress(detected, cleanText.slice(0, 80), 10);
        }
      }

      const msg: ChatMessage = {
        id: `${Date.now()}-${sender}-${Math.random().toString(36).slice(2, 6)}`,
        sender,
        text: cleanText,
        emotion: detected,
        timestamp: Date.now(),
      };

      let updatedMessagesSnapshot: ChatMessage[] = [];
      setMessages((prev) => {
        const updated = [...prev, msg];
        messagesRef.current = updated;
        updatedMessagesSnapshot = updated;
        return updated;
      });

      persistMessage(msg);

      // Run instant Boss Sentiment Analysis on every Boss message (0 latency, 0 API quota)
      // and throttle deep Gemini sentiment to every 3rd message to prevent 429 rate-limit floods
      if (sender === "user") {
        // Upgrade 1: Smart Anti-Parrot Routine Confirmation Detector (locks confirmed tasks for today)
        const routineDetection = detectRoutineIntentFromMessage(cleanText, routineStateRef.current);
        if (routineDetection.updated) {
          setRoutineState(routineDetection.nextState);
          routineStateRef.current = routineDetection.nextState;
          if (routineDetection.confirmedTask) {
            pushCyberLog(
              `ROUTINE LOCKED (ANTI-PARROT): ${routineDetection.confirmedTask.toUpperCase()} DONE`
            );
          }
        }

        const instantSentiment = analyzeBossSentimentInstant(cleanText);
        setSentiments((prev) => {
          const next = [instantSentiment, ...prev].slice(0, 50);
          sentimentsRef.current = next;
          return next;
        });
        pushCyberLog(
          `BOSS SENTIMENT: ${instantSentiment.polarity.toUpperCase()} (${instantSentiment.score > 0 ? `+${instantSentiment.score}` : instantSentiment.score})`
        );

        deepSentimentCounterRef.current += 1;
        if (deepSentimentCounterRef.current >= 3) {
          deepSentimentCounterRef.current = 0;
          analyzeBossSentimentDeep(cleanText, messagesRef.current)
            .then((deepRecord) => {
              setSentiments((prev) => {
                const withoutTemp = prev.filter((item) => item.id !== instantSentiment.id);
                const next = [deepRecord, ...withoutTemp].slice(0, 50);
                sentimentsRef.current = next;
                return next;
              });
            })
            .catch(() => {});
        }
      }

      // Immediately update & persist the Session Context JSON blob so full browser reloads retain exact state
      const nextSessionCtx = updateSessionContextFromMessage(
        sessionContextRef.current,
        msg,
        updatedMessagesSnapshot.length > 0 ? updatedMessagesSnapshot : [...messagesRef.current],
        detected || radhaEmotionRef.current
      );
      sessionContextRef.current = nextSessionCtx;
      setSessionContext(nextSessionCtx);
      persistSessionContext(nextSessionCtx);

      // Every 2 turns, distill a crisp LLM Session Context summary in the background
      sessionSummaryTurnsRef.current += 1;
      if (sessionSummaryTurnsRef.current >= 2) {
        sessionSummaryTurnsRef.current = 0;
        const msgsSnap = [...messagesRef.current];
        const ctxSnap = { ...sessionContextRef.current };
        refreshSessionContextSummary(msgsSnap, ctxSnap).then((distilled) => {
          if (distilled && distilled.updatedAt >= sessionContextRef.current.updatedAt) {
            sessionContextRef.current = distilled;
            setSessionContext(distilled);
          }
        });
      }

      // Every 4 turns, extract key long-term memories in the background
      unsummarizedTurnsRef.current += 1;
      if (unsummarizedTurnsRef.current >= 4) {
        unsummarizedTurnsRef.current = 0;
        const snapshotMsgs = [...messagesRef.current];
        const snapshotMems = [...memoriesRef.current];
        extractBackgroundMemories(snapshotMsgs, snapshotMems).then((added) => {
          if (added.length > 0) {
            setMemories((prev) => [...added, ...prev]);
            pushCyberLog(`AUTO-MEMORY SAVED (${added.length} ITEMS)`);
          }
        });
      }
    },
    [recordMoodProgress, pushCyberLog]
  );

  const handleAddMemory = useCallback(async (content: string, category: string) => {
    const saved = await addPersistentMemory(content, category);
    if (saved) {
      setMemories((prev) => [saved, ...prev]);
    }
  }, []);

  const handleDeleteMemory = useCallback(async (id: string) => {
    await deletePersistentMemory(id);
    setMemories((prev) => prev.filter((m) => m.id !== id));
  }, []);

  const handleClearChatHistory = useCallback(async () => {
    setMessages([]);
    saveLocalMessages([]);
    const freshCtx = createDefaultSessionContext();
    setSessionContext(freshCtx);
    sessionContextRef.current = freshCtx;
    persistSessionContext(freshCtx);
    await clearServerMessages();
    resetRadhaSession();
  }, []);

  // Smart Hub CRUD Handlers
  const handleCreateReminder = useCallback(
    async (title: string, triggerAt: number) => {
      const created = await createPersistentReminder(title, triggerAt);
      if (created) {
        setReminders((prev) => [...prev, created].sort((a, b) => a.triggerAt - b.triggerAt));
        pushCyberLog(`ALARM ARMED: ${created.title}`);
      }
    },
    [pushCyberLog]
  );

  const handleDeleteReminder = useCallback(async (id: string) => {
    await deletePersistentReminder(id);
    setReminders((prev) => prev.filter((r) => r.id !== id));
  }, []);

  const handleCreateTask = useCallback(
    async (title: string, priority: "low" | "medium" | "high") => {
      const created = await createPersistentTask(title, priority);
      if (created) {
        setTasks((prev) => [created, ...prev]);
        pushCyberLog(`TASK LOGGED [${priority.toUpperCase()}]: ${created.title}`);
      }
    },
    [pushCyberLog]
  );

  const handleToggleTask = useCallback(async (id: string, completed: boolean) => {
    await togglePersistentTask(id, completed);
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, completed } : t)));
  }, []);

  const handleDeleteTask = useCallback(async (id: string) => {
    await deletePersistentTask(id);
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const [isMuted, setIsMuted] = useState(false);
  const [isMicMuted, setIsMicMuted] = useState(false);

  const liveSessionRef = useRef<LiveSessionManager | null>(null);

  useEffect(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.isMuted = isMuted;
    }
  }, [isMuted]);

  useEffect(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.isMicMuted = isMicMuted;
    }
  }, [isMicMuted]);

  const [showTextInput, setShowTextInput] = useState(false);
  const [textInput, setTextInput] = useState("");
  const [showPermissionModal, setShowPermissionModal] = useState(false);
  const [isSessionActive, setIsSessionActive] = useState(false);
  const isSessionActiveRef = useRef(false);
  useEffect(() => {
    isSessionActiveRef.current = isSessionActive;
  }, [isSessionActive]);

  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isPanelOpen, setIsPanelOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"chat" | "hub" | "guide">("chat");

  const [isCameraActive, setIsCameraActive] = useState(false);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const [openUrlToast, setOpenUrlToast] = useState<string | null>(null);

  const openBrowserUrl = useCallback((url: string) => {
    if (!url) return;
    setOpenUrlToast(url);
    try {
      const win = window.open(url, "_blank", "noopener,noreferrer");
      if (!win || win.closed || typeof win.closed === "undefined") {
        console.warn("Popup blocked or needs direct user click.");
      }
    } catch (err) {
      console.warn("Error launching URL:", err);
    }
    setTimeout(() => {
      setOpenUrlToast((current) => (current === url ? null : current));
    }, 10000);
  }, []);

  const playRadhaVoiceOrFallback = useCallback(
    async (
      text: string,
      voiceName: string,
      voicePitch: number,
      emotion?: RadhaEmotion,
      safetyTimeoutMs?: number
    ) => {
      const clean = text.trim().slice(0, 600);
      if (!clean) return;
      const myToken = systemSessionTokenRef.current;
      const activeEmotion = emotion || radhaEmotionRef.current || "neutral";
      try {
        if (!isServerTtsCoolingDown()) {
          // 1. Low-latency Pre-Fetch Streaming Buffer (with strict AudioContext + timeout verification)
          const streamed = await streamAndPlayRadhaAudio(
            clean,
            voiceName,
            voicePitch,
            activeEmotion,
            safetyTimeoutMs
          );
          if (streamed || myToken !== systemSessionTokenRef.current) return;

          // 2. Unary Gemini PCM fallback (skip if streaming just triggered quota cooldown or on short greetings)
          if (!isServerTtsCoolingDown() && (!safetyTimeoutMs || safetyTimeoutMs > 3000)) {
            const audioBase64 = await getRadhaAudio(clean, voiceName, activeEmotion);
            if (myToken !== systemSessionTokenRef.current) return;
            if (audioBase64) {
              const played = await playPCM(audioBase64, voicePitch, activeEmotion, safetyTimeoutMs);
              if (played || myToken !== systemSessionTokenRef.current) return;
            }
          }
        }
      } catch {
        // Fall through cleanly to guaranteed Browser Hindi TTS
      }

      if (myToken !== systemSessionTokenRef.current) return;

      // 3. Guaranteed Browser Hindi TTS (cancel + 60ms delay + Chrome resume keep-alive + onend & safety timeout)
      await speakBrowserHindiFallback(clean, voicePitch, activeEmotion, safetyTimeoutMs);
    },
    []
  );

  const playRadhaVoiceOrFallbackRef = useRef(playRadhaVoiceOrFallback);
  useEffect(() => {
    playRadhaVoiceOrFallbackRef.current = playRadhaVoiceOrFallback;
  }, [playRadhaVoiceOrFallback]);

  const speakDirectText = useCallback(
    async (text: string, emotion?: RadhaEmotion) => {
      const clean = text.trim();
      // Strict Off-Gate: autonomous voice triggers NEVER speak while system is OFF
      if (!clean || isMuted || (!isSystemActiveRef.current && !isSessionActiveRef.current)) return;
      const myToken = systemSessionTokenRef.current;
      const targetEmotion = emotion || radhaEmotionRef.current || "neutral";
      if (isSessionActiveRef.current && liveSessionRef.current) {
        liveSessionRef.current.setEmotion(targetEmotion);
        liveSessionRef.current.sendPrompt(
          `इसे ${radhaConfigRef.current.ownerNickname || radhaConfigRef.current.creatorName || "रविंद्र बॉस"} को अपने स्वाभाविक हिंदी अंदाज़ में साफ़-साफ़ सुनाओ: ${clean}`,
          false
        );
        return;
      }
      setAppState("speaking");
      await playRadhaVoiceOrFallback(
        clean,
        radhaConfigRef.current.voiceName,
        radhaConfigRef.current.voicePitch,
        targetEmotion
      );
      if (myToken === systemSessionTokenRef.current) {
        setAppState("idle");
      }
    },
    [isMuted, playRadhaVoiceOrFallback]
  );

  // Real Live Weather Refresh Helper (Zero API Key — Open-Meteo + GPS)
  const handleRefreshLiveWeather = useCallback(
    async (city?: string): Promise<LiveWeatherData | null> => {
      setIsWeatherLoading(true);
      try {
        const data = city ? await fetchWeatherByCity(city) : await fetchCurrentLocationWeather();
        setLiveWeather(data);
        liveWeatherRef.current = data;
        pushCyberLog(`WEATHER SYNC: ${data.city} ${data.tempC}°C (${data.conditionEn})`);
        return data;
      } catch (err: any) {
        showNotice(err?.message || "Live weather fetch failed.");
        return null;
      } finally {
        setIsWeatherLoading(false);
      }
    },
    [pushCyberLog, showNotice]
  );

  // Real Biological Status Handlers (Google Fit + Apple Health — Zero Mock Data)
  const handleConnectGoogleFit = useCallback(async () => {
    setIsSyncingBio(true);
    try {
      const data = await connectAndSyncGoogleFit();
      setBiologicalStatus(data);
      pushCyberLog(
        `BIO SYNC (GOOGLE FIT): ${data.steps ?? 0} steps${
          data.heartRateBpm ? ` · ${data.heartRateBpm} BPM` : ""
        }`
      );
      showNotice("Google Fit Biological Status synced live!");
    } catch (err: any) {
      showNotice(err?.message || "Google Fit sign-in was cancelled or unavailable.");
    } finally {
      setIsSyncingBio(false);
    }
  }, [pushCyberLog, showNotice]);

  const handleImportAppleHealthFile = useCallback(
    async (file: File) => {
      setIsSyncingBio(true);
      try {
        const data = await parseAppleHealthFile(file);
        setBiologicalStatus(data);
        pushCyberLog(
          `BIO SYNC (APPLE HEALTH): ${data.steps ?? 0} steps (${data.recordedDate || "latest"})`
        );
        showNotice(`Apple Health imported (${data.recordedDate || "latest"}): ${data.steps ?? 0} steps`);
      } catch (err: any) {
        showNotice(err?.message || "Could not parse Apple Health file.");
      } finally {
        setIsSyncingBio(false);
      }
    },
    [pushCyberLog, showNotice]
  );

  const handleSyncHealthWebhook = useCallback(
    async (url: string) => {
      setIsSyncingBio(true);
      try {
        const data = await syncHealthWebhookUrl(url);
        setBiologicalStatus(data);
        pushCyberLog(`BIO SYNC (HEALTH FEED): ${data.steps ?? "--"} steps`);
        showNotice("Live Health feed synced!");
      } catch (err: any) {
        showNotice(err?.message || "Health feed sync failed.");
      } finally {
        setIsSyncingBio(false);
      }
    },
    [pushCyberLog, showNotice]
  );

  const handleDisconnectBio = useCallback(() => {
    const cleared = clearBiologicalStatus();
    setBiologicalStatus(cleared);
    pushCyberLog("BIOLOGICAL STATUS CLEARED");
  }, [pushCyberLog]);

  // Persistent localStorage Voice Notes Handlers
  const handleAddVoiceNote = useCallback(
    (content: string) => {
      const saved = addVoiceNote(content);
      if (saved) {
        setVoiceNotes((prev) => [saved, ...prev]);
        pushCyberLog(`VOICE NOTE SAVED: ${saved.content.slice(0, 28)}`);
      }
    },
    [pushCyberLog]
  );

  const handleDeleteVoiceNote = useCallback((id: string) => {
    const updated = deleteVoiceNote(id);
    setVoiceNotes(updated);
  }, []);

  // Real Device Battery & Online/Offline Subscriptions (Smart Care ONLY speaks when isSystemActive === true)
  useEffect(() => {
    const unsubBattery = subscribeRealBattery((status) => {
      setBatteryStatus(status);
      if (status.charging || (status.level !== null && status.level >= 25)) {
        hasWarnedLowBatteryRef.current = false;
      }
      if (
        isSystemActiveRef.current &&
        status.supported &&
        status.level !== null &&
        status.level < 20 &&
        !status.charging &&
        !hasWarnedLowBatteryRef.current
      ) {
        hasWarnedLowBatteryRef.current = true;
        const lowBatMsg = "बॉस, बैटरी 20% से कम हो गई है, चार्जर लगा लो।";
        pushCyberLog(`BATTERY CARE ALERT: ${status.level}% (UNPLUGGED)`);
        showNotice(lowBatMsg);
        appendAndPersistMessage("radha", lowBatMsg, "caring");
        speakDirectText(lowBatMsg, "caring");
      }
    });

    const onOnline = () => {
      setIsOnline(true);
      if (isSystemActiveRef.current) {
        showNotice("इंटरनेट कनेक्शन वापस आ गया है, बॉस!");
        pushCyberLog("NETWORK RESTORED: ONLINE");
      }
    };
    const onOffline = () => {
      setIsOnline(false);
      if (isSystemActiveRef.current) {
        const offlineMsg = "बॉस, इंटरनेट ऑफलाइन हो गया है — लोकल नोट्स और बेसिक कमांड्स अभी भी काम करेंगे।";
        showNotice(offlineMsg);
        pushCyberLog("NETWORK STATUS: OFFLINE");
      }
    };

    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    return () => {
      unsubBattery();
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, [appendAndPersistMessage, pushCyberLog, showNotice, speakDirectText]);

  // Screen Wake Lock management (APK / Mobile ready — ONLY held while isSystemActive === true)
  useEffect(() => {
    let mounted = true;
    const syncWakeLock = async () => {
      if (isSystemActive) {
        const ok = await acquireScreenWakeLock();
        if (mounted) setWakeLockActive(ok);
      } else {
        await releaseScreenWakeLock();
        if (mounted) setWakeLockActive(false);
      }
    };
    syncWakeLock();

    const onVisibility = () => {
      if (document.visibilityState === "visible" && isSystemActiveRef.current) {
        acquireScreenWakeLock().then((ok) => {
          if (mounted) setWakeLockActive(ok);
        });
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      mounted = false;
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [isSystemActive]);

  // Reminder Alarm Watcher (STRICTLY GATED: ONLY chimes/speaks when isSystemActive === true)
  const triggeredRemindersRef = useRef<Set<string>>(new Set());
  useEffect(() => {
    if (!isSystemActive) return;
    const interval = window.setInterval(() => {
      if (!isSystemActiveRef.current) return;
      const now = Date.now();
      const due = remindersRef.current.find(
        (r) => !r.completed && r.triggerAt <= now && !triggeredRemindersRef.current.has(r.id)
      );
      if (due) {
        triggeredRemindersRef.current.add(due.id);
        setActiveAlarmBanner(due);
        setReminders((prev) => prev.map((r) => (r.id === due.id ? { ...r, completed: true } : r)));
        markReminderCompleted(due.id, true);
        playCyberTone("alarm");
        pushCyberLog(`ALARM TRIGGERED: ${due.title}`);

        const announcement = `${radhaConfigRef.current.creatorName || "Ravindra Boss"}, aapka reminder baj gaya hai: ${due.title}!`;
        appendAndPersistMessage("radha", announcement, "excited");
        speakDirectText(announcement, "excited");
      }
    }, 1000);
    return () => window.clearInterval(interval);
  }, [isSystemActive, appendAndPersistMessage, pushCyberLog, speakDirectText]);

  // Upgrade 1: Real-Time Daily Routine & Human Care Scheduler
  // STRICTLY LIMITED & NON-INTRUSIVE:
  // - Never runs when system is OFF (isSystemActive === false).
  // - Never randomly speaks out loud during silent Wake-Word standby (shows quiet notice toast instead).
  // - Only speaks gently during an active live session when Boss has been quiet >= 25 seconds.
  useEffect(() => {
    if (!isSystemActive) return;
    const runRoutineCareTick = () => {
      if (!isSystemActiveRef.current) return;
      const latest = loadDailyRoutineState();
      if (latest.date !== routineStateRef.current.date) {
        setRoutineState(latest);
        routineStateRef.current = latest;
      }

      // Never interrupt if Radha is already speaking/processing or Boss spoke in the last 25 seconds
      if (isRadhaSpeakingRef.current || isStartingSessionRef.current) return;
      if (Date.now() - lastUserInteractionRef.current < 25_000) return;

      const check = evaluateProactiveRoutineCheck(routineStateRef.current, new Date());
      if (!check) return;

      const updated = markRoutineAsked(routineStateRef.current, check);
      setRoutineState(updated);
      routineStateRef.current = updated;
      pushCyberLog(`DAILY CARE -> ${check.label.toUpperCase()}`);
      appendAndPersistMessage("radha", check.message, check.emotion);
      showNotice(check.message);

      // Speak aloud ONLY if Boss is already in an active Live Voice session (zero surprise ghost speech on standby!)
      if (isSessionActiveRef.current && liveSessionRef.current) {
        speakDirectText(check.message, check.emotion);
      }
    };

    const initialTimer = window.setTimeout(runRoutineCareTick, 180_000);
    const interval = window.setInterval(runRoutineCareTick, 120_000);
    return () => {
      window.clearTimeout(initialTimer);
      window.clearInterval(interval);
    };
  }, [isSystemActive, appendAndPersistMessage, pushCyberLog, showNotice, speakDirectText]);

  const handleSpeakCurrentWeather = useCallback(async () => {
    const data = liveWeatherRef.current || (await handleRefreshLiveWeather());
    if (!data) return;
    const reply = formatWeatherHindiReply(
      data,
      radhaConfigRef.current.ownerNickname || "बॉस"
    );
    appendAndPersistMessage("radha", reply, "happy");
    await speakDirectText(reply, "happy");
  }, [appendAndPersistMessage, handleRefreshLiveWeather, speakDirectText]);

  const handleSpeakSocialBriefing = useCallback(
    async (platform: "all" | "instagram" | "gmail" | "facebook" = "all") => {
      const snap = await refreshSocialWorkspace();
      const briefing = buildSocialWorkspaceVoiceBriefing(snap, platform);
      pushCyberLog(`VOICE BRIEFING -> ${platform.toUpperCase()}`);
      appendAndPersistMessage("radha", briefing, "happy");
      await speakDirectText(briefing, "happy");
    },
    [appendAndPersistMessage, pushCyberLog, refreshSocialWorkspace, speakDirectText]
  );

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const screenStreamRef = useRef<MediaStream | null>(null);
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);
  const screenCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const screenIntervalRef = useRef<number | null>(null);

  const cameraStreamRef = useRef<MediaStream | null>(null);
  const cameraVideoRef = useRef<HTMLVideoElement | null>(null);
  const cameraCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const cameraIntervalRef = useRef<number | null>(null);

  // Inactivity gentle check-in detector
  const inactivityTimerRef = useRef<any>(null);
  const isRadhaSpeakingRef = useRef<boolean>(false);
  const hasTriggeredInactivityRef = useRef<boolean>(false);
  const checkinIndexRef = useRef<number>(0);

  const DIVERSE_GENTLE_CHECKINS = [
    "Ravindra Boss, sab theek hai na? Main yahan dhyan se sun rahi hoon.",
    "Boss, lagta hai aap kisi gehri soch me hain! Radha yahi haazir hai.",
    "Ravinder Boss, koi sawaal ya naya task ho toh zaroor batayein.",
    "Boss, sab badhiya? Main yahan aapki baat ka intezaar kar rahi hoon.",
    "Ravindra Boss, agar kuch naya discuss karna ho toh batayein, main taiyar hoon!",
  ];

  useEffect(() => {
    isRadhaSpeakingRef.current = appState === "speaking" || appState === "processing";
  }, [appState]);

  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    hasTriggeredInactivityRef.current = false;

    if (
      !isSystemActiveRef.current ||
      !isSessionActive ||
      !radhaConfigRef.current.inactivityCheckinEnabled
    ) {
      return;
    }

    const waitMs = Math.max(45, radhaConfigRef.current.inactivitySeconds || 120) * 1000;
    inactivityTimerRef.current = setTimeout(async () => {
      if (
        !isSystemActiveRef.current ||
        !isSessionActiveRef.current ||
        !radhaConfigRef.current.inactivityCheckinEnabled
      ) {
        return;
      }
      if (isRadhaSpeakingRef.current || hasTriggeredInactivityRef.current) return;
      hasTriggeredInactivityRef.current = true;

      const nudgeText = DIVERSE_GENTLE_CHECKINS[checkinIndexRef.current % DIVERSE_GENTLE_CHECKINS.length];
      checkinIndexRef.current += 1;

      appendAndPersistMessage("radha", nudgeText, "caring");

      if (liveSessionRef.current && isSessionActiveRef.current) {
        liveSessionRef.current.sendPrompt(
          `${radhaConfigRef.current.creatorName || "Ravindra Boss"} has been quietly thinking for a bit. Gently check in with him in your natural, sweet voice: "${nudgeText}"`,
          false
        );
      }
    }, waitMs);
  }, [isSessionActive, appendAndPersistMessage]);

  useEffect(() => {
    if (isSessionActive) {
      resetInactivityTimer();
    } else {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
        inactivityTimerRef.current = null;
      }
      hasTriggeredInactivityRef.current = false;
    }
    return () => {
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
        inactivityTimerRef.current = null;
      }
    };
  }, [isSessionActive, resetInactivityTimer]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, appState]);

  const handleTextCommand = useCallback(
    async (finalTranscript: string) => {
      // Noise / empty / accidental 1-character trigger filter
      if (!isMeaningfulTranscript(finalTranscript)) {
        setAppState("idle");
        return;
      }

      lastUserInteractionRef.current = Date.now();
      resetInactivityTimer();
      const cfg = radhaConfigRef.current;

      if (isSessionActive && liveSessionRef.current) {
        liveSessionRef.current.sendText(finalTranscript);
        resetInactivityTimer();
        return;
      }

      const preMessageRoutineState = routineStateRef.current;
      appendAndPersistMessage("user", finalTranscript);

      const lowerTranscript = finalTranscript.toLowerCase().trim();
      if (
        lowerTranscript.includes("open panel") ||
        lowerTranscript.includes("open chat") ||
        lowerTranscript.includes("open guide") ||
        lowerTranscript.includes("open hub") ||
        lowerTranscript.includes("show panel") ||
        lowerTranscript.includes("show chat")
      ) {
        setIsPanelOpen(true);
        const tab = lowerTranscript.includes("guide")
          ? "guide"
          : lowerTranscript.includes("hub")
          ? "hub"
          : "chat";
        setActiveTab(tab);
        const openResponse = `Ji Boss! ${tab} panel open kar diya hai.`;
        appendAndPersistMessage("radha", openResponse, "happy");
        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(openResponse, cfg.voiceName, cfg.voicePitch, "happy");
        }
        setAppState("idle");
        resetInactivityTimer();
        return;
      }

      if (
        lowerTranscript.includes("close panel") ||
        lowerTranscript.includes("close chat") ||
        lowerTranscript.includes("close guide") ||
        lowerTranscript.includes("hide panel") ||
        lowerTranscript.includes("hide chat")
      ) {
        setIsPanelOpen(false);
        const closeResponse = "Samajh gayi Boss. Side panel band kar diya hai.";
        appendAndPersistMessage("radha", closeResponse, "neutral");
        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(closeResponse, cfg.voiceName, cfg.voicePitch, "neutral");
        }
        setAppState("idle");
        resetInactivityTimer();
        return;
      }

      setAppState("processing");

      // 1. Check Voice Notes & Timed Reminders ("नोट लिखो...", "10 मिनट बाद याद दिलाना...")
      const noteOrReminder = detectNoteOrReminderCommand(finalTranscript);
      if (noteOrReminder) {
        let replyText = "";
        if (noteOrReminder.type === "note") {
          handleAddVoiceNote(noteOrReminder.content);
          replyText = `जी बॉस, मैंने आपका नोट सेव कर लिया है: "${noteOrReminder.content}"।`;
        } else if (noteOrReminder.type === "read_notes") {
          const notes = voiceNotesRef.current;
          replyText =
            notes.length === 0
              ? "बॉस, अभी कोई नोट सेव नहीं है। आप बोल सकते हैं 'राधा, नोट लिखो...'।"
              : `बॉस, आपके कुल ${notes.length} नोट्स हैं। ताज़ा नोट्स: ${notes
                  .slice(0, 3)
                  .map((n, i) => `${i + 1}. ${n.content}`)
                  .join(" | ")}`;
        } else if (noteOrReminder.type === "reminder") {
          const triggerAt = Date.now() + Math.round(noteOrReminder.delayMinutes * 60 * 1000);
          await handleCreateReminder(noteOrReminder.title, triggerAt);
          const minLabel =
            noteOrReminder.delayMinutes >= 60
              ? `${Math.round((noteOrReminder.delayMinutes / 60) * 10) / 10} घंटे`
              : `${Math.round(noteOrReminder.delayMinutes)} मिनट`;
          replyText = `जी बॉस, ${minLabel} बाद के लिए "${noteOrReminder.title}" का रिमाइंडर सेट कर दिया है।`;
        }

        appendAndPersistMessage("radha", replyText, "happy");
        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(replyText, cfg.voiceName, cfg.voicePitch, "happy");
        }
        setAppState("idle");
        resetInactivityTimer();
        return;
      }

      // 2. Check Live Weather Voice Query ("आज का मौसम कैसा है?", "Delhi ka weather batao")
      const weatherQuery = detectWeatherVoiceQuery(finalTranscript);
      if (weatherQuery.matched) {
        const freshWeather = await handleRefreshLiveWeather(weatherQuery.city);
        const weatherReply = freshWeather
          ? formatWeatherHindiReply(freshWeather, cfg.ownerNickname || "बॉस")
          : "बॉस, अभी मौसम की लाइव जानकारी नहीं मिल पा रही है, कृपया इंटरनेट चेक कर लीजिए।";
        appendAndPersistMessage("radha", weatherReply, "happy");
        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(weatherReply, cfg.voiceName, cfg.voicePitch, "happy");
        }
        setAppState("idle");
        resetInactivityTimer();
        return;
      }

      const commandResult = processCommand(finalTranscript);
      let responseText = "";

      // 3. Instant Direct Answers (Real-Time Date/Day/Time + Safe Math Calculation)
      if (commandResult.isDirectAnswer) {
        responseText = commandResult.action;
        appendAndPersistMessage("radha", responseText, "happy");
        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(responseText, cfg.voiceName, cfg.voicePitch, "happy");
        }
        setAppState("idle");
        resetInactivityTimer();
        return;
      }

      if (commandResult.isBrowserAction) {
        responseText = commandResult.action;
        appendAndPersistMessage("radha", responseText, "happy");

        if (!isMuted) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(responseText, cfg.voiceName, cfg.voicePitch, "happy");
        }

        setAppState("idle");
        resetInactivityTimer();

        setTimeout(() => {
          if (commandResult.url) {
            openBrowserUrl(commandResult.url);
          }
        }, 1000);
      } else {
        // Check if Boss asked for Social Media / Workspace Voice Briefing (Instagram, Gmail, Facebook)
        const socialQuery = detectSocialBriefingQuery(finalTranscript);
        if (socialQuery) {
          const freshSnap = await refreshSocialWorkspace();
          responseText = buildSocialWorkspaceVoiceBriefing(freshSnap, socialQuery);
          appendAndPersistMessage("radha", responseText, "happy");
          if (!isMuted) {
            setAppState("speaking");
            await playRadhaVoiceOrFallback(responseText, cfg.voiceName, cfg.voicePitch, "happy");
          }
          setAppState("idle");
          resetInactivityTimer();
          return;
        }

        // Check if Boss directly confirmed/declined a pending routine question with a crisp reply
        const routineIntent = detectRoutineIntentFromMessage(
          finalTranscript,
          preMessageRoutineState
        );
        if (routineIntent.replySuggestion) {
          if (routineIntent.updated) {
            setRoutineState(routineIntent.nextState);
            routineStateRef.current = routineIntent.nextState;
          }
          const rEmotion = routineIntent.replyEmotion || "happy";
          appendAndPersistMessage("radha", routineIntent.replySuggestion, rEmotion);
          if (!isMuted) {
            setAppState("speaking");
            await playRadhaVoiceOrFallback(
              routineIntent.replySuggestion,
              cfg.voiceName,
              cfg.voicePitch,
              rEmotion
            );
          }
          setAppState("idle");
          resetInactivityTimer();
          return;
        }

        const responseToken = systemSessionTokenRef.current;
        responseText = await getRadhaResponse(
          finalTranscript,
          messagesRef.current,
          cfg,
          memoriesRef.current,
          {
            tasks: tasksRef.current,
            reminders: remindersRef.current,
            bonding: bondingRef.current,
            sessionContext: sessionContextRef.current,
            latestSentiment: sentimentsRef.current[0] || null,
            sentiments: sentimentsRef.current,
            routineState: routineStateRef.current,
            socialSnapshot: socialSnapshotRef.current,
          }
        );
        const replyEmotion =
          detectEmotionFromText(responseText, "radha") || radhaEmotionRef.current || "neutral";
        appendAndPersistMessage("radha", responseText, replyEmotion);

        if (!isMuted && responseToken === systemSessionTokenRef.current) {
          setAppState("speaking");
          await playRadhaVoiceOrFallback(responseText, cfg.voiceName, cfg.voicePitch, replyEmotion);
        }
        if (responseToken === systemSessionTokenRef.current) {
          setAppState("idle");
        }
        resetInactivityTimer();

        if (cfg.autoSleepOnBye !== false && isFarewellPhrase(finalTranscript)) {
          if (isSystemActiveRef.current) {
            setWakeWordEnabled(true);
            pushCyberLog("FAREWELL COMPLETE -> WAKE-WORD STANDBY ARMED");
            showNotice(`राधा स्लीप मोड में है — "${cfg.wakeWordText || "राधा"}" बोलकर फिर जगाएं।`);
          }
        }
      }
    },
    [
      isMuted,
      isSessionActive,
      resetInactivityTimer,
      appendAndPersistMessage,
      openBrowserUrl,
      pushCyberLog,
      showNotice,
      playRadhaVoiceOrFallback,
      refreshSocialWorkspace,
      handleAddVoiceNote,
      handleCreateReminder,
      handleRefreshLiveWeather,
    ]
  );

  useEffect(() => {
    return () => {
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
      }
      stopScreenShare();
      stopCamera();
    };
  }, []);

  const stopScreenShare = () => {
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach((track) => track.stop());
      screenStreamRef.current = null;
    }
    if (screenIntervalRef.current) {
      window.clearInterval(screenIntervalRef.current);
      screenIntervalRef.current = null;
    }
    setIsScreenSharing(false);
  };

  const stopCamera = useCallback(() => {
    if (faceScanTimerRef.current) {
      window.clearTimeout(faceScanTimerRef.current);
      faceScanTimerRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop());
      cameraStreamRef.current = null;
    }
    if (cameraIntervalRef.current) {
      window.clearInterval(cameraIntervalRef.current);
      cameraIntervalRef.current = null;
    }
    setIsCameraActive(false);
    setOwnerFaceStatus("idle");
  }, []);

  const runOwnerFaceVerification = useCallback(async () => {
    const cfg = radhaConfigRef.current;
    const hasCalibrated = Boolean(cfg.biometricProfile?.calibrated);
    if (!cfg.ownerPhotoUrl && !hasCalibrated) {
      showNotice("पहले Admin Panel (@123hack) → Boss Biometric में 3D Face Calibration करें।");
      return;
    }
    if (faceScanInFlightRef.current) return;
    const video = cameraVideoRef.current;
    if (!video || video.readyState < 2 || !video.videoWidth) {
      showNotice("कैमरा फीड तैयार हो रही है, 1 सेकंड बाद फिर Scan Face दबाएं।");
      return;
    }

    faceScanInFlightRef.current = true;
    setOwnerFaceStatus("scanning");
    pushCyberLog(
      hasCalibrated
        ? "3D BIOMETRIC LIVENESS SCAN: CAPTURING ANTI-SPOOF BURST..."
        : "BIOMETRIC FACE ID: SCANNING LIVE CAMERA FRAME..."
    );

    const captureFrameBase64 = (): string => {
      const canvas = cameraCanvasRef.current || document.createElement("canvas");
      cameraCanvasRef.current = canvas;
      const targetW = Math.min(512, video.videoWidth || 512);
      const targetH = Math.max(
        240,
        Math.round(targetW * ((video.videoHeight || 480) / (video.videoWidth || 640)))
      );
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d");
      if (!ctx) return "";
      ctx.drawImage(video, 0, 0, targetW, targetH);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.82);
      return dataUrl.split(",")[1] || "";
    };

    try {
      const liveFrameBase64 = captureFrameBase64();
      if (!liveFrameBase64) throw new Error("Frame capture failed");

      // Capture a second frame 500ms later for anti-spoof 3D liveness check
      let liveFrame2Base64 = "";
      if (!cfg.biometricProfile || cfg.biometricProfile.requireLivenessCheck !== false) {
        await new Promise((r) => setTimeout(r, 500));
        if (cameraVideoRef.current && cameraVideoRef.current.readyState >= 2) {
          liveFrame2Base64 = captureFrameBase64();
        }
      }

      const ownerName = cfg.ownerNickname || cfg.ownerFullName || cfg.creatorName || "Ravindra Boss";
      const result = await verifyOwnerFace({
        ownerPhotoDataUrl: cfg.ownerPhotoUrl,
        liveFrameBase64,
        liveFrame2Base64: liveFrame2Base64 || undefined,
        ownerName,
        ownerBio: cfg.ownerBio,
        biometricProfile: cfg.biometricProfile,
      });

      if (!result) {
        setOwnerFaceStatus("idle");
        showNotice("Face ID स्कैन अभी पूरा नहीं हो सका। थोड़ी देर बाद कोशिश करें।");
        return;
      }

      setOwnerFaceInfo(result);
      if (result.spoofDetected) {
        setOwnerFaceStatus("spoof");
        pushCyberLog("SECURITY ALERT: PHOTO/SCREEN SPOOF ATTEMPT BLOCKED!");
        const spoofText =
          result.greeting ||
          "सावधान बॉस! यह असली चेहरा नहीं बल्कि फोटो या स्क्रीन से स्पूफ करने की कोशिश लग रही है — एक्सेस ब्लॉक कर दिया गया है!";
        appendAndPersistMessage("radha", spoofText, "angry");
        if (isSessionActiveRef.current && liveSessionRef.current) {
          liveSessionRef.current.setEmotion("angry");
          liveSessionRef.current.sendPrompt(
            `Security alert: someone tried to spoof the camera using a photo or phone screen. Warn firmly in Hindi: "${spoofText}"`,
            false
          );
        } else {
          speakDirectText(spoofText, "angry");
        }
      } else if (result.faceDetected && result.isOwner) {
        setOwnerFaceStatus("verified");
        pushCyberLog(
          `BIOMETRIC FACE ID: ${result.hashVerified ? "3D HASH VERIFIED" : "OWNER VERIFIED"} (${result.confidence}% · ${result.expression.toUpperCase()})`
        );
        const greetingText =
          result.greeting || `अरे ${ownerName}! मैंने आपको तुरंत पहचान लिया, कैसे हैं आप?`;
        appendAndPersistMessage("radha", greetingText, "happy");
        if (isSessionActiveRef.current && liveSessionRef.current) {
          liveSessionRef.current.setEmotion("happy");
          liveSessionRef.current.sendPrompt(
            `आपने अभी कैमरे से ${ownerName} का असली चेहरा वेरिफाई कर लिया है (${result.confidence}% confidence, expression: ${result.expression}). तुरंत प्यार से हिंदी में ग्रीट करो: "${greetingText}"`,
            false
          );
        } else {
          speakDirectText(greetingText, "happy");
        }
      } else if (result.faceDetected) {
        setOwnerFaceStatus("guest");
        pushCyberLog(`BIOMETRIC FACE ID: NON-OWNER DETECTED (${result.confidence}%)`);
        const guestText =
          result.greeting ||
          `नमस्ते! आप ${ownerName} से अलग लग रहे हैं — कृपया बताइए आप कौन हैं?`;
        appendAndPersistMessage("radha", guestText, "neutral");
        if (isSessionActiveRef.current && liveSessionRef.current) {
          liveSessionRef.current.setEmotion("neutral");
          liveSessionRef.current.sendPrompt(
            `कैमरे पर ${ownerName} के अलावा कोई और व्यक्ति दिख रहा है। विनम्रता से हिंदी में पूछो कि वे कौन हैं: "${guestText}"`,
            false
          );
        } else {
          speakDirectText(guestText, "neutral");
        }
      } else {
        setOwnerFaceStatus("idle");
        showNotice("कैमरे में साफ़ चेहरा दिखाई नहीं दिया — थोड़ा पास आकर Scan Face दबाएं।");
      }
    } catch {
      setOwnerFaceStatus("idle");
      showNotice("Face ID verification interrupted.");
    } finally {
      faceScanInFlightRef.current = false;
    }
  }, [appendAndPersistMessage, pushCyberLog, showNotice, speakDirectText]);

  const startCamera = async (
    currentFacing: "user" | "environment" = facingMode,
    triggerFaceScanNow: boolean = false
  ) => {
    if (isScreenSharing) stopScreenShare();
    if (faceScanTimerRef.current) {
      window.clearTimeout(faceScanTimerRef.current);
      faceScanTimerRef.current = null;
    }
    if (cameraStreamRef.current) {
      cameraStreamRef.current.getTracks().forEach((track) => track.stop());
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: currentFacing,
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      cameraStreamRef.current = stream;

      if (!cameraVideoRef.current) {
        cameraVideoRef.current = document.createElement("video");
        cameraVideoRef.current.setAttribute("playsinline", "true");
        cameraVideoRef.current.setAttribute("muted", "true");
      }
      if (!cameraCanvasRef.current) {
        cameraCanvasRef.current = document.createElement("canvas");
      }

      cameraVideoRef.current.srcObject = stream;
      cameraVideoRef.current.play().catch((e) => console.warn("Video play failed:", e));

      setIsCameraActive(true);
      setOwnerFaceStatus("idle");
      startCameraCapture();
      pushCyberLog("OPTICAL CAMERA FEED ONLINE");

      const cfg = radhaConfigRef.current;
      if (
        (triggerFaceScanNow || cfg.faceRecognitionEnabled !== false) &&
        (cfg.ownerPhotoUrl || cfg.biometricProfile?.calibrated) &&
        currentFacing === "user"
      ) {
        faceScanTimerRef.current = window.setTimeout(() => {
          faceScanTimerRef.current = null;
          runOwnerFaceVerification();
        }, 1500);
      }
    } catch (err: any) {
      console.warn("Camera was not started:", err.message || err);
      showNotice("Camera permission denied or unavailable.");
      setIsCameraActive(false);
    }
  };

  const toggleCamera = async () => {
    if (isCameraActive) {
      stopCamera();
    } else {
      await startCamera(facingMode);
    }
  };

  const toggleFacingMode = async () => {
    const nextFacing = facingMode === "user" ? "environment" : "user";
    setFacingMode(nextFacing);
    if (isCameraActive) {
      await startCamera(nextFacing);
    }
  };

  const handleTestFaceId = async () => {
    setFacingMode("user");
    if (isCameraActive && facingMode === "user") {
      await runOwnerFaceVerification();
    } else {
      await startCamera("user", true);
    }
  };

  const startCameraCapture = () => {
    if (cameraIntervalRef.current) {
      window.clearInterval(cameraIntervalRef.current);
    }
    cameraIntervalRef.current = window.setInterval(() => {
      if (!liveSessionRef.current || !isSessionActiveRef.current) return;
      if (!cameraVideoRef.current || !cameraCanvasRef.current) return;

      const video = cameraVideoRef.current;
      const canvas = cameraCanvasRef.current;
      const ctx = canvas.getContext("2d");

      if (video.readyState >= 2 && ctx) {
        canvas.width = 640;
        canvas.height = Math.floor(640 * (video.videoHeight / video.videoWidth)) || 480;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const dataUrl = canvas.toDataURL("image/jpeg", 0.5);
        const base64Data = dataUrl.split(",")[1];
        if (base64Data) {
          liveSessionRef.current.sendVideoFrame(base64Data);
        }
      }
    }, 2000);
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      try {
        if (!navigator.mediaDevices || typeof navigator.mediaDevices.getDisplayMedia !== "function") {
          showNotice("Screen capture not supported on mobile browser; switching to rear camera.");
          setFacingMode("environment");
          await startCamera("environment");
          return;
        }

        const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
        screenStreamRef.current = stream;

        if (!screenVideoRef.current) {
          screenVideoRef.current = document.createElement("video");
          screenVideoRef.current.setAttribute("playsinline", "true");
          screenVideoRef.current.setAttribute("muted", "true");
        }
        if (!screenCanvasRef.current) {
          screenCanvasRef.current = document.createElement("canvas");
        }

        screenVideoRef.current.srcObject = stream;
        screenVideoRef.current.play().catch((e) => console.warn("Screen video play error:", e));

        stream.getVideoTracks()[0].onended = () => {
          stopScreenShare();
        };

        setIsScreenSharing(true);
        startScreenCapture();
        pushCyberLog("SCREEN CAPTURE UPLINK ACTIVE");
      } catch (err: any) {
        console.warn("Screen sharing was not started:", err.message || err);
        if (err.name === "NotAllowedError" || err.message?.includes("Permission denied")) {
          showNotice("Screen sharing permission was denied.");
        } else {
          showNotice("Screen share unavailable. Activating rear camera.");
          setFacingMode("environment");
          await startCamera("environment");
        }
      }
    }
  };

  const startScreenCapture = () => {
    if (screenIntervalRef.current) {
      window.clearInterval(screenIntervalRef.current);
    }
    screenIntervalRef.current = window.setInterval(() => {
      if (!liveSessionRef.current || !isSessionActiveRef.current) return;
      if (!screenVideoRef.current || !screenCanvasRef.current) return;

      const video = screenVideoRef.current;
      const canvas = screenCanvasRef.current;
      const ctx = canvas.getContext("2d");

      if (video.readyState >= 2 && ctx) {
        canvas.width = 640;
        canvas.height = Math.floor(640 * (video.videoHeight / video.videoWidth)) || 360;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const dataUrl = canvas.toDataURL("image/jpeg", 0.5);
        const base64Data = dataUrl.split(",")[1];
        if (base64Data) {
          liveSessionRef.current.sendVideoFrame(base64Data);
        }
      }
    }, 2000);
  };

  const startLiveVoiceSession = useCallback(
    async (initialWake?: { type: "greeting" | "command"; text?: string }) => {
      // Strict synchronous singleton mutex prevents double Live sessions / double sound
      if (isSessionActiveRef.current || isStartingSessionRef.current) return;
      isStartingSessionRef.current = true;
      isSessionActiveRef.current = true;

      try {
        // Immediately stop any lingering TTS, browser SpeechSynthesis, or Wake-Word SpeechRecognition
        stopActivePCM();
        try {
          window.speechSynthesis?.cancel();
        } catch {}
        if (wakeRecRef.current) {
          try {
            wakeRecRef.current.onresult = null;
            wakeRecRef.current.onerror = null;
            wakeRecRef.current.onend = null;
            wakeRecRef.current.onstart = null;
            wakeRecRef.current.abort();
          } catch {}
          wakeRecRef.current = null;
        }
        if (liveSessionRef.current) {
          liveSessionRef.current.stop();
          liveSessionRef.current = null;
        }

        setIsSessionActive(true);
        setIsMicMuted(false);
        setIsMuted(false);
        resetRadhaSession();
        pushCyberLog("ACTIVATING FULL LIVE NEURAL VOICE LINK");

        const session = new LiveSessionManager();
        session.isMuted = false;
        session.isMicMuted = false;
        session.setEmotion(initialWake ? "excited" : radhaEmotionRef.current);
        liveSessionRef.current = session;

        let wakeHandoffSent = false;
        session.onReady = () => {
          if (wakeHandoffSent || !initialWake || !isSystemActiveRef.current) return;
          wakeHandoffSent = true;
          if (initialWake.type === "command" && initialWake.text?.trim()) {
            session.sendText(initialWake.text.trim());
          } else if (initialWake.type === "greeting") {
            const greetingLine =
              WAKE_WORD_GREETINGS[wakeGreetingIdxRef.current % WAKE_WORD_GREETINGS.length];
            wakeGreetingIdxRef.current += 1;
            session.sendPrompt(
              `बॉस ने अभी आपको "${radhaConfigRef.current.wakeWordText || "राधा"}" बोलकर एक्टिवेट किया है। तुरंत बहुत छोटे और प्यारे 2-4 शब्दों में हिंदी में जवाब दो (जैसे: "${greetingLine}") और आगे उनकी हर बात ध्यान से सुनने के लिए तैयार रहो।`,
              false
            );
          }
        };

        session.onStateChange = (state) => {
          setAppState(state);
        };

        session.onMessage = (sender, text) => {
          appendAndPersistMessage(sender, text);
          resetInactivityTimer();
        };

        session.onEmotionChange = (emotion) => {
          setRadhaEmotion(emotion);
        };

        session.onMemorySaved = (savedMemory) => {
          setMemories((prev) => {
            if (prev.some((m) => m.id === savedMemory.id)) return prev;
            return [savedMemory, ...prev];
          });
          pushCyberLog(`MEMORY LOCKED: ${savedMemory.content.slice(0, 32)}`);
        };

        session.onReminderCreated = (reminder) => {
          setReminders((prev) =>
            [...prev, reminder].sort((a, b) => a.triggerAt - b.triggerAt)
          );
        };

        session.onTaskCreated = (task) => {
          setTasks((prev) => [task, ...prev]);
        };

        session.onCyberEvent = (logLine) => {
          pushCyberLog(logLine);
        };

        session.onRoutineUpdated = (task, completed) => {
          setRoutineState((prev) => {
            const base = loadDailyRoutineState();
            const current = prev.date === base.date ? prev : base;
            const next: DailyRoutineState = { ...current };
            if (task === "bathed") next.bathed = completed;
            else if (task === "lunch") next.lunchDone = completed;
            else if (task === "dinner") next.dinnerDone = completed;
            else if (task === "health") next.wellnessChecked = completed;
            else if (task === "water" && completed) next.waterCount = Math.min(12, current.waterCount + 1);
            next.lastPromptedTask = null;
            saveDailyRoutineState(next);
            routineStateRef.current = next;
            return next;
          });
        };

        session.onGetSocialBriefing = async (platform) => {
          const snap = await refreshSocialWorkspace();
          return buildSocialWorkspaceVoiceBriefing(snap, platform);
        };

        session.onWeatherFetched = (weather) => {
          setLiveWeather(weather);
          liveWeatherRef.current = weather;
        };

        session.onVoiceNoteSaved = (note) => {
          setVoiceNotes((prev) => [note, ...prev]);
        };

        session.onUserSpeech = () => {
          lastUserInteractionRef.current = Date.now();
          resetInactivityTimer();
        };

        session.onPlaybackEnd = () => {
          resetInactivityTimer();
        };

        session.onCommand = (url) => {
          setTimeout(() => {
            openBrowserUrl(url);
          }, 800);
        };

        session.onFarewellComplete = () => {
          const ww = radhaConfigRef.current.wakeWordText || "राधा";
          if (isSystemActiveRef.current) {
            setWakeWordEnabled(true);
            pushCyberLog(`AUTO-SLEEP COMPLETE -> WAKE-WORD "${ww}" RE-ARMED`);
            showNotice(`राधा स्लीप मोड में चली गई है — "${ww}" बोलकर फिर जगाएं।`);
          }
        };

        session.onClose = () => {
          isStartingSessionRef.current = false;
          isSessionActiveRef.current = false;
          setIsSessionActive(false);
          if (inactivityTimerRef.current) {
            clearTimeout(inactivityTimerRef.current);
            inactivityTimerRef.current = null;
          }
          if (liveSessionRef.current === session) {
            liveSessionRef.current = null;
          }
          stopCamera();
          stopScreenShare();
          pushCyberLog("LIVE VOICE SESSION TERMINATED");
        };

        await session.start(
          radhaConfigRef.current,
          memoriesRef.current,
          messagesRef.current,
          {
            tasks: tasksRef.current,
            reminders: remindersRef.current,
            bonding: bondingRef.current,
            sessionContext: sessionContextRef.current,
            latestSentiment: sentimentsRef.current[0] || null,
            sentiments: sentimentsRef.current,
            routineState: routineStateRef.current,
            socialSnapshot: socialSnapshotRef.current,
          }
        );

        if (isCameraActive) startCameraCapture();
        if (isScreenSharing) startScreenCapture();
      } catch (e) {
        console.warn("Failed to start session:", e);
        isSessionActiveRef.current = false;
        if (inactivityTimerRef.current) {
          clearTimeout(inactivityTimerRef.current);
          inactivityTimerRef.current = null;
        }
        setShowPermissionModal(true);
        setIsSessionActive(false);
        setAppState("idle");
      } finally {
        isStartingSessionRef.current = false;
      }
    },
    [
      appendAndPersistMessage,
      isCameraActive,
      isScreenSharing,
      openBrowserUrl,
      pushCyberLog,
      refreshSocialWorkspace,
      resetInactivityTimer,
      showNotice,
      stopCamera,
    ]
  );

  // Master Start / Stop System Gate (Strict Manual Activation — Zero Auto-Run!)
  const activateRadhaSystem = useCallback(() => {
    unlockAudioPlayback();
    systemSessionTokenRef.current += 1;
    isSystemActiveRef.current = true;
    setIsSystemActive(true);
    setWakeWordEnabled(true);
    lastUserInteractionRef.current = Date.now();
    const ww = radhaConfigRef.current.wakeWordText || "राधा";
    pushCyberLog(`SYSTEM ACTIVE · SAY "${ww}" TO FULLY ACTIVATE RADHA`);
    showNotice(`राधा एक्टिव है — "${ww}" बोलिए, तुरंत पूरी तरह चालू होकर सुनेगी!`);
    if (!liveWeatherRef.current) {
      handleRefreshLiveWeather();
    }
  }, [handleRefreshLiveWeather, pushCyberLog, showNotice]);

  const stopRadhaSystem = useCallback(() => {
    // Immediately invalidate ALL in-flight async voice tasks & kill timers, TTS, Live Voice, Wake-Word, Mic & Wake Lock
    systemSessionTokenRef.current += 1;
    isSystemActiveRef.current = false;
    setIsSystemActive(false);
    setWakeWordEnabled(false);
    isStartingSessionRef.current = false;
    isSessionActiveRef.current = false;
    setIsSessionActive(false);

    stopActivePCM();
    try {
      window.speechSynthesis?.cancel();
    } catch {}
    isVoiceCommandBusyRef.current = false;

    if (inactivityTimerRef.current) {
      clearTimeout(inactivityTimerRef.current);
      inactivityTimerRef.current = null;
    }
    if (wakeDelayTimerRef.current) {
      window.clearTimeout(wakeDelayTimerRef.current);
      wakeDelayTimerRef.current = null;
    }
    if (wakeRestartTimerRef.current) {
      window.clearTimeout(wakeRestartTimerRef.current);
      wakeRestartTimerRef.current = null;
    }
    if (wakeRecRef.current) {
      try {
        wakeRecRef.current.onresult = null;
        wakeRecRef.current.onerror = null;
        wakeRecRef.current.onend = null;
        wakeRecRef.current.onstart = null;
        wakeRecRef.current.abort();
      } catch {}
      wakeRecRef.current = null;
    }
    if (liveSessionRef.current) {
      liveSessionRef.current.stop();
      liveSessionRef.current = null;
    }

    stopCamera();
    stopScreenShare();
    releaseScreenWakeLock();
    setWakeLockActive(false);
    setAppState("idle");
    resetRadhaSession();
    pushCyberLog("SYSTEM STOPPED · ALL MIC, VOICE & TIMERS KILLED");
  }, [pushCyberLog, stopCamera]);

  const toggleSystemActive = useCallback(() => {
    if (isSystemActiveRef.current) {
      stopRadhaSystem();
    } else {
      activateRadhaSystem();
    }
  }, [activateRadhaSystem, stopRadhaSystem]);

  // Smart Barge-In: immediately halts Radha's active voice output and opens mic cleanly
  const handleSmartBargeIn = useCallback(() => {
    stopActivePCM();
    try {
      window.speechSynthesis?.cancel();
    } catch {}
    if (liveSessionRef.current && isSessionActiveRef.current) {
      liveSessionRef.current.interruptAndListen();
      pushCyberLog("SMART BARGE-IN -> LISTENING");
    } else {
      setAppState("idle");
    }
  }, [pushCyberLog]);

  const toggleListening = async () => {
    unlockAudioPlayback();
    // If Radha is currently speaking during an active session, tapping Mic performs clean Smart Barge-In
    if (isSessionActive && appState === "speaking") {
      handleSmartBargeIn();
      return;
    }
    if (isSessionActive || isSessionActiveRef.current) {
      // If Wake-Word is OFF, ending Live Call turns the entire system cleanly OFF so nothing runs silently in background!
      if (!wakeWordEnabled) {
        stopRadhaSystem();
        return;
      }
      isStartingSessionRef.current = false;
      isSessionActiveRef.current = false;
      setIsSessionActive(false);
      stopActivePCM();
      try {
        window.speechSynthesis?.cancel();
      } catch {}
      if (inactivityTimerRef.current) {
        clearTimeout(inactivityTimerRef.current);
        inactivityTimerRef.current = null;
      }
      if (liveSessionRef.current) {
        liveSessionRef.current.stop();
        liveSessionRef.current = null;
      }
      stopCamera();
      stopScreenShare();
      setAppState("idle");
      resetRadhaSession();
      const ww = radhaConfigRef.current.wakeWordText || "राधा";
      showNotice(`लाइव कॉल बंद — "${ww}" वेक-वर्ड स्टैंडबाय पर है (पूरी तरह बंद करने के लिए STOP दबाएं)`);
    } else {
      if (!isSystemActiveRef.current) {
        systemSessionTokenRef.current += 1;
        isSystemActiveRef.current = true;
        setIsSystemActive(true);
        if (!liveWeatherRef.current) handleRefreshLiveWeather();
      }
      await startLiveVoiceSession();
    }
  };

  // Keep latest handlers in stable refs so the single SpeechRecognition engine NEVER drops or restarts on unrelated UI updates
  const startLiveVoiceSessionRef = useRef(startLiveVoiceSession);
  useEffect(() => {
    startLiveVoiceSessionRef.current = startLiveVoiceSession;
  }, [startLiveVoiceSession]);

  // =========================================================================
  // ULTRA-FAST WAKE-WORD ENGINE -> INSTANT FULL LIVE NEURAL VOICE ACTIVATION
  // Single-instance recognizer strictly for Wake-Word ("राधा").
  // The instant "राधा" is heard: release SpeechRecognition -> start FULL Gemini Live Voice
  // (Radha's EXACT original emotional human voice, continuous fast listening, zero double sound!)
  // =========================================================================
  const wakeRecRef = useRef<any>(null);
  const wakeDelayTimerRef = useRef<number | null>(null);
  const wakeRestartTimerRef = useRef<number | null>(null);
  const isVoiceCommandBusyRef = useRef<boolean>(false);

  useEffect(() => {
    if (!isSystemActive || !wakeWordEnabled || isSessionActive) {
      isVoiceCommandBusyRef.current = false;
      if (wakeDelayTimerRef.current) {
        window.clearTimeout(wakeDelayTimerRef.current);
        wakeDelayTimerRef.current = null;
      }
      if (wakeRestartTimerRef.current) {
        window.clearTimeout(wakeRestartTimerRef.current);
        wakeRestartTimerRef.current = null;
      }
      if (wakeRecRef.current) {
        try {
          wakeRecRef.current.onresult = null;
          wakeRecRef.current.onerror = null;
          wakeRecRef.current.onend = null;
          wakeRecRef.current.onstart = null;
          wakeRecRef.current.abort();
        } catch {}
        wakeRecRef.current = null;
      }
      return;
    }

    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) {
      showNotice("Browser SpeechRecognition unsupported for Wake-Word mode.");
      setWakeWordEnabled(false);
      return;
    }

    let cancelled = false;
    let isRunning = false;
    let activeRecognition: any = null;

    const matchesWakeWord = (text: string): boolean => {
      const normalized = text.trim().toLowerCase();
      if (!normalized) return false;
      const custom = (radhaConfigRef.current.wakeWordText || "राधा").trim().toLowerCase();
      if (custom && normalized.includes(custom)) return true;
      return /(?:^|[\s,!.?])(radha|raadha|raada|raddha|राधा|राध|राधे)(?:$|[\s,!.?])/i.test(
        normalized
      );
    };

    const stripLeadingWakeWord = (text: string): string => {
      const custom = (radhaConfigRef.current.wakeWordText || "राधा").trim();
      let cleaned = text.trim();
      if (custom) {
        const escaped = custom.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        cleaned = cleaned.replace(
          new RegExp(`^(?:hey\\s+|ok\\s+|hello\\s+|अरे\\s+|सुनो\\s+)?${escaped}[,:!?.\\s-]*`, "i"),
          ""
        );
      }
      cleaned = cleaned.replace(
        /^(?:hey\s+|ok\s+|hello\s+|अरे\s+|सुनो\s+)?(?:radha|raadha|raada|raddha|राधा|राध|राधे)[,:!?.\\s-]*/i,
        ""
      );
      return cleaned.trim();
    };

    const stopCurrentRecognizer = () => {
      isRunning = false;
      if (wakeRestartTimerRef.current) {
        window.clearTimeout(wakeRestartTimerRef.current);
        wakeRestartTimerRef.current = null;
      }
      if (activeRecognition) {
        try {
          activeRecognition.onresult = null;
          activeRecognition.onerror = null;
          activeRecognition.onend = null;
          activeRecognition.onstart = null;
          activeRecognition.abort();
        } catch {}
        activeRecognition = null;
      }
      wakeRecRef.current = null;
    };

    const scheduleSelfHealingRestart = (delayMs: number = 400) => {
      if (
        cancelled ||
        !isSystemActiveRef.current ||
        isSessionActiveRef.current ||
        isStartingSessionRef.current ||
        isVoiceCommandBusyRef.current
      ) {
        return;
      }
      if (wakeRestartTimerRef.current) {
        window.clearTimeout(wakeRestartTimerRef.current);
      }
      wakeRestartTimerRef.current = window.setTimeout(() => {
        wakeRestartTimerRef.current = null;
        startFreshRecognizer();
      }, delayMs);
    };

    // Instant Wake-Word -> Full Live Neural Voice Activation (ZERO double audio, EXACT original emotional voice!)
    const handleWakeWordDetected = (fullTranscript: string, isFinalResult: boolean) => {
      if (
        cancelled ||
        !isSystemActiveRef.current ||
        isVoiceCommandBusyRef.current ||
        isSessionActiveRef.current ||
        isStartingSessionRef.current
      ) {
        return;
      }

      isVoiceCommandBusyRef.current = true;
      stopCurrentRecognizer();
      stopActivePCM();
      try {
        window.speechSynthesis?.cancel();
      } catch {}

      playCyberTone("wake");
      const ww = radhaConfigRef.current.wakeWordText || "राधा";
      const inlineCommand = isFinalResult ? stripLeadingWakeWord(fullTranscript) : "";
      const hasInlineCommand =
        Boolean(inlineCommand) &&
        isMeaningfulTranscript(inlineCommand) &&
        inlineCommand.split(/\s+/).length >= 2;

      setRadhaEmotion("excited");
      setAppState("processing");
      pushCyberLog(
        hasInlineCommand
          ? `WAKE "${ww}" + COMMAND -> FULL LIVE ACTIVATION`
          : `WAKE "${ww}" DETECTED -> FULL LIVE ACTIVATION`
      );

      // 220ms clean hardware mic release gap (prevents Chrome/Android WebView mic lock conflict)
      wakeDelayTimerRef.current = window.setTimeout(async () => {
        wakeDelayTimerRef.current = null;
        if (cancelled || !isSystemActiveRef.current || isSessionActiveRef.current) {
          isVoiceCommandBusyRef.current = false;
          return;
        }
        try {
          await startLiveVoiceSessionRef.current(
            hasInlineCommand
              ? { type: "command", text: inlineCommand }
              : { type: "greeting" }
          );
        } finally {
          isVoiceCommandBusyRef.current = false;
        }
      }, 220);
    };

    const startFreshRecognizer = () => {
      if (
        cancelled ||
        isRunning ||
        !isSystemActiveRef.current ||
        isSessionActiveRef.current ||
        isStartingSessionRef.current ||
        isVoiceCommandBusyRef.current
      ) {
        return;
      }

      stopCurrentRecognizer();

      try {
        const rec = new SpeechRec();
        rec.continuous = true;
        rec.interimResults = true;
        rec.maxAlternatives = 3;
        rec.lang = "hi-IN";
        activeRecognition = rec;
        wakeRecRef.current = rec;

        rec.onstart = () => {
          if (activeRecognition !== rec) return;
          isRunning = true;
        };

        rec.onresult = (event: any) => {
          if (
            cancelled ||
            activeRecognition !== rec ||
            !isSystemActiveRef.current ||
            isSessionActiveRef.current ||
            isStartingSessionRef.current ||
            isVoiceCommandBusyRef.current ||
            isRadhaSpeakingRef.current
          ) {
            return;
          }

          for (let i = event.resultIndex; i < event.results.length; i++) {
            const resultObj = event.results[i];
            for (let alt = 0; alt < Math.min(3, resultObj.length || 1); alt++) {
              const transcript = String(resultObj[alt]?.transcript || "");
              if (matchesWakeWord(transcript)) {
                handleWakeWordDetected(transcript, Boolean(resultObj.isFinal));
                return;
              }
            }
          }
        };

        rec.onerror = (ev: any) => {
          if (activeRecognition !== rec) return;
          isRunning = false;
          const errCode = String(ev?.error || "");
          if (errCode === "not-allowed" || errCode === "service-not-allowed") {
            setWakeWordEnabled(false);
            setAppState("idle");
            showNotice("माइक्रोफ़ोन की अनुमति नहीं मिली — कृपया Mic Permission Allow करें।");
            return;
          }
          scheduleSelfHealingRestart(400);
        };

        rec.onend = () => {
          if (activeRecognition !== rec) return;
          isRunning = false;
          scheduleSelfHealingRestart(400);
        };

        rec.start();
        isRunning = true;
      } catch {
        isRunning = false;
        scheduleSelfHealingRestart(450);
      }
    };

    startFreshRecognizer();
    pushCyberLog(`WAKE-WORD STANDBY ARMED: SAY "${radhaConfigRef.current.wakeWordText || "राधा"}"`);

    return () => {
      cancelled = true;
      isVoiceCommandBusyRef.current = false;
      if (wakeDelayTimerRef.current) {
        window.clearTimeout(wakeDelayTimerRef.current);
        wakeDelayTimerRef.current = null;
      }
      stopCurrentRecognizer();
    };
  }, [isSystemActive, wakeWordEnabled, isSessionActive, pushCyberLog, showNotice]);

  const handleRunDeepSentiment = useCallback(
    async (customText?: string) => {
      const lastBossMsg = [...messagesRef.current].reverse().find((m) => m.sender === "user");
      const targetText =
        customText?.trim() ||
        lastBossMsg?.text ||
        "Boss checking in with Radha for live sentiment calibration.";
      const deepRecord = await analyzeBossSentimentDeep(targetText, messagesRef.current);
      setSentiments((prev) => {
        const next = [deepRecord, ...prev].slice(0, 50);
        sentimentsRef.current = next;
        return next;
      });
      pushCyberLog(
        `DEEP SENTIMENT SCAN: ${deepRecord.dominantMood.toUpperCase()} (${deepRecord.score > 0 ? `+${deepRecord.score}` : deepRecord.score})`
      );
    },
    [pushCyberLog]
  );

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim()) return;
    handleTextCommand(textInput);
    setTextInput("");
    setShowTextInput(false);
  };

  const handleAskQuestion = useCallback(
    (question: string) => {
      setActiveTab("chat");
      setTextInput("");
      handleTextCommand(question);
    },
    [handleTextCommand]
  );

  const openHubSection = (sec: SmartHubSection) => {
    setSmartHubSection(sec);
    setActiveTab("hub");
    setIsPanelOpen(true);
  };

  const primary = radhaConfig.primaryColor || "#00ff9d";
  const secondary = radhaConfig.secondaryColor || "#00e5ff";
  const activeRemindersCount = reminders.filter((r) => !r.completed).length;
  const pendingTasksCount = tasks.filter((t) => !t.completed).length;
  const isWaitingForWakeWord = isSystemActive && wakeWordEnabled && !isSessionActive;
  const wakeWordLabel = radhaConfig.wakeWordText || "राधा";

  return (
    <div
      className="h-[100dvh] w-full max-w-[100vw] text-white flex flex-col items-center justify-between font-sans relative overflow-hidden overflow-x-hidden m-0 p-0"
      style={{ backgroundColor: radhaConfig.backgroundColor || "#020608" }}
    >
      {/* Custom Background Banner / Wallpaper from Admin Panel */}
      {radhaConfig.backgroundImageUrl && (
        <div className="absolute inset-0 w-full h-full pointer-events-none z-0">
          <img
            src={radhaConfig.backgroundImageUrl}
            alt="Custom Background"
            className="w-full h-full object-cover"
          />
          <div
            className="absolute inset-0 bg-black"
            style={{ opacity: radhaConfig.backgroundOverlayOpacity ?? 0.65 }}
          />
        </div>
      )}

      {/* Khatarnak Hacker Tactical Grid & Subtle CRT Scanlines */}
      <div className="absolute inset-0 hacker-grid-bg pointer-events-none z-0 opacity-80" />
      <div className="absolute inset-0 hacker-scanlines pointer-events-none z-0 opacity-35" />

      {/* Outer HUD Tactical Corner Frame */}
      <div className="absolute inset-2.5 pointer-events-none z-10">
        <div
          className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 opacity-50"
          style={{ borderColor: primary }}
        />
        <div
          className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 opacity-50"
          style={{ borderColor: primary }}
        />
        <div
          className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 opacity-50"
          style={{ borderColor: secondary }}
        />
        <div
          className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 opacity-50"
          style={{ borderColor: secondary }}
        />
      </div>

      {/* Alarm Banner when Reminder Fires */}
      <AnimatePresence>
        {activeAlarmBanner && (
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-[#051412]/95 border-2 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-3 backdrop-blur-xl max-w-[92vw] font-mono"
            style={{ borderColor: primary, boxShadow: `0 0 30px ${primary}55` }}
          >
            <AlarmClock size={18} style={{ color: primary }} className="animate-bounce shrink-0" />
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-widest" style={{ color: primary }}>
                VOICE ALARM TRIGGERED
              </div>
              <div className="text-xs font-bold text-white truncate">{activeAlarmBanner.title}</div>
            </div>
            <button
              type="button"
              onClick={() => setActiveAlarmBanner(null)}
              className="px-2.5 py-1 rounded-lg text-[11px] font-bold text-black cursor-pointer shrink-0"
              style={{ backgroundColor: primary }}
            >
              OK
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Non-blocking System Notice Toast */}
      <AnimatePresence>
        {noticeToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-black/90 border border-amber-400/50 text-amber-200 px-4 py-2 rounded-xl text-xs font-mono shadow-xl flex items-center gap-2 max-w-[90vw]"
          >
            <span>{noticeToast}</span>
            <button onClick={() => setNoticeToast(null)} className="p-0.5 hover:text-white cursor-pointer">
              <X size={13} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Open URL Toast */}
      <AnimatePresence>
        {openUrlToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-16 sm:top-20 left-1/2 -translate-x-1/2 z-50 text-black px-4 py-2 rounded-full shadow-2xl border border-white/20 flex items-center gap-2.5 backdrop-blur-md max-w-[90vw] font-mono"
            style={{
              background: `linear-gradient(90deg, ${primary}, ${secondary})`,
            }}
          >
            <span className="text-xs font-bold shrink-0">LINK:</span>
            <a
              href={openUrlToast}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold underline max-w-[180px] sm:max-w-xs truncate"
            >
              {openUrlToast}
            </a>
            <button
              onClick={() => setOpenUrlToast(null)}
              className="p-1 hover:bg-black/20 rounded-full transition-colors ml-1 shrink-0 cursor-pointer"
              title="Dismiss"
            >
              <X size={12} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {showPermissionModal && <PermissionModal onClose={() => setShowPermissionModal(false)} />}

      {/* Password-Protected Admin Full Control Center (@123hack) */}
      <AdminPanel
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        config={radhaConfig}
        onUpdateConfig={handleUpdateConfig}
        memories={memories}
        messageCount={messages.length}
        onAddMemory={handleAddMemory}
        onDeleteMemory={handleDeleteMemory}
        onClearChatHistory={handleClearChatHistory}
        onTestFaceId={handleTestFaceId}
      />

      {/* Upgrade 4: Collapsible Command & Insights Side-Panel (Instagram, Gmail, Facebook & Daily Care) */}
      <SocialWorkspacePanel
        isOpen={isInsightsOpen}
        onClose={() => setIsInsightsOpen(false)}
        config={radhaConfig}
        socialConfig={socialConfig}
        snapshot={socialSnapshot}
        isRefreshing={isSocialRefreshing}
        onRefresh={() => refreshSocialWorkspace()}
        onSaveSocialConfig={handleSaveSocialConfig}
        onSpeakBriefing={handleSpeakSocialBriefing}
        routineState={routineState}
        onToggleRoutineTask={handleToggleRoutineTask}
      />

      {/* Hidden-by-Default Glassmorphic Command Drawer (Weather, Voice Notes, Biological Status, Device Care) */}
      <CommandDrawer
        isOpen={isCommandDrawerOpen}
        onClose={() => setIsCommandDrawerOpen(false)}
        config={radhaConfig}
        isSystemActive={isSystemActive}
        onToggleSystemActive={toggleSystemActive}
        weather={liveWeather}
        isWeatherLoading={isWeatherLoading}
        onRefreshWeather={handleRefreshLiveWeather}
        onSpeakWeather={handleSpeakCurrentWeather}
        voiceNotes={voiceNotes}
        onAddVoiceNote={handleAddVoiceNote}
        onDeleteVoiceNote={handleDeleteVoiceNote}
        reminders={reminders}
        onCreateQuickReminder={(title, mins) =>
          handleCreateReminder(title, Date.now() + Math.round(mins * 60 * 1000))
        }
        onDeleteReminder={handleDeleteReminder}
        battery={batteryStatus}
        isOnline={isOnline}
        wakeLockActive={wakeLockActive}
        wakeWordEnabled={wakeWordEnabled}
        onToggleWakeWord={() => {
          if (!isSystemActive) {
            activateRadhaSystem();
          } else {
            setWakeWordEnabled((v) => !v);
          }
        }}
        isMuted={isMuted}
        onToggleMute={() => {
          const next = !isMuted;
          setIsMuted(next);
          if (liveSessionRef.current) liveSessionRef.current.isMuted = next;
        }}
        isMicMuted={isMicMuted}
        onToggleMicMute={() => {
          const next = !isMicMuted;
          setIsMicMuted(next);
          if (liveSessionRef.current) liveSessionRef.current.isMicMuted = next;
        }}
        biologicalStatus={biologicalStatus}
        isSyncingBio={isSyncingBio}
        onConnectGoogleFit={handleConnectGoogleFit}
        onImportAppleHealthFile={handleImportAppleHealthFile}
        onSyncHealthWebhook={handleSyncHealthWebhook}
        onDisconnectBio={handleDisconnectBio}
        onUpdateConfig={handleUpdateConfig}
      />

      {/* Cinematic Cyber Ambient Glows */}
      <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none">
        <div
          className="absolute top-[-22%] left-[-12%] w-[48%] h-[48%] blur-[130px] rounded-full opacity-18 transition-colors duration-500"
          style={{ backgroundColor: primary }}
        />
        <div
          className="absolute bottom-[-22%] right-[-12%] w-[48%] h-[48%] blur-[130px] rounded-full opacity-18 transition-colors duration-500"
          style={{ backgroundColor: secondary }}
        />
      </div>

      {/* Header */}
      <header className="absolute top-0 left-0 w-full flex justify-between items-center z-20 shrink-0 px-4 py-3 md:px-8 md:py-4">
        <div className="flex items-center gap-3">
          {/* Radha Icon -> Click to Open Admin Panel (@123hack) */}
          <button
            type="button"
            onClick={() => setIsAdminOpen(true)}
            className="group flex items-center gap-2.5 text-left cursor-pointer focus:outline-none"
            title="Open Admin Panel (@123hack)"
          >
            <div
              className="relative w-9 h-9 rounded-lg flex items-center justify-center font-mono font-bold text-sm text-black overflow-hidden border transition-all"
              style={{
                background: `linear-gradient(135deg, ${primary}, ${secondary})`,
                borderColor: `${primary}90`,
                boxShadow: `0 0 18px ${primary}55`,
              }}
            >
              {radhaConfig.avatarImageUrl ? (
                <img
                  src={radhaConfig.avatarImageUrl}
                  alt={radhaConfig.assistantName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span>{(radhaConfig.assistantName || "R").charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <h1 className="text-lg font-mono font-bold tracking-[0.14em] uppercase text-white group-hover:opacity-100">
                  {radhaConfig.assistantName || "Radha"}
                </h1>
                <Shield size={12} style={{ color: primary }} />
              </div>
              <span className="text-[10px] font-mono text-white/45 group-hover:text-white/80 tracking-wider">
                ROOT // ADMIN · LVL {bonding.level}
              </span>
            </div>
          </button>

          {/* Live Wake-Word Standby Visual Indicator (Strictly synced to active wake-word listening) */}
          {isWaitingForWakeWord && (
            <div
              role="status"
              aria-live="polite"
              className="hidden lg:flex items-center gap-2.5 pl-3 border-l border-white/15 whitespace-nowrap shrink-0"
              title={`Radha is actively listening for "${wakeWordLabel}"`}
            >
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span
                  className="motion-safe:animate-ping absolute inline-flex h-full w-full rounded-full opacity-75"
                  style={{ backgroundColor: primary }}
                />
                <span
                  className="relative inline-flex rounded-full h-2.5 w-2.5"
                  style={{
                    backgroundColor: primary,
                    boxShadow: `0 0 10px ${primary}`,
                  }}
                />
              </span>
              <div className="flex flex-col leading-tight">
                <span
                  className="text-[11px] font-mono font-semibold tracking-wider uppercase"
                  style={{ color: primary }}
                >
                  LISTENING FOR &ldquo;{wakeWordLabel}&rdquo;
                </span>
                <span className="text-[9px] font-mono text-white/55 tracking-widest uppercase">
                  WAKE-WORD STANDBY ACTIVE
                </span>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Subtle Live Weather Pill (Opens Command Drawer — Zero Clutter) */}
          <button
            type="button"
            onClick={() => {
              setIsCommandDrawerOpen(true);
              if (!liveWeather) handleRefreshLiveWeather();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border bg-black/55 text-white/85 hover:bg-white/10 transition-all cursor-pointer"
            style={{ borderColor: `${secondary}45` }}
            title={
              liveWeather
                ? `${liveWeather.city}: ${liveWeather.tempC}°C (${liveWeather.conditionEn})`
                : "Open Command Drawer (Weather, Notes, Bio, Device)"
            }
          >
            <CloudSun size={13} className="text-amber-300 shrink-0" />
            <span className="tabular-nums">
              {liveWeather ? `${liveWeather.tempC}°C` : "DRAWER"}
            </span>
            <SlidersHorizontal size={11} className="opacity-55 hidden sm:inline" />
          </button>

          {/* Live Boss Sentiment Quick-Access Indicator */}
          <button
            type="button"
            onClick={() => openHubSection("sentiment")}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border bg-black/55 text-white/80 hover:bg-white/10 transition-all cursor-pointer"
            style={{
              borderColor:
                sentiments[0]?.polarity === "intense"
                  ? "rgba(255, 42, 85, 0.55)"
                  : sentiments[0]?.polarity === "negative"
                  ? "rgba(249, 115, 22, 0.5)"
                  : `${secondary}45`,
            }}
            title="Open Boss Sentiment Analysis Engine"
          >
            <Brain
              size={13}
              style={{
                color:
                  sentiments[0]?.polarity === "intense"
                    ? "#ff2a55"
                    : sentiments[0]?.polarity === "negative"
                    ? "#f97316"
                    : primary,
              }}
            />
            <span className="hidden xl:inline">SENTIMENT</span>
            <span className="tabular-nums" style={{ color: primary }}>
              {sentiments[0]
                ? sentiments[0].score > 0
                  ? `+${sentiments[0].score}`
                  : sentiments[0].score
                : "SYNC"}
            </span>
          </button>

          {/* Wake-Word Toggle (Gated behind isSystemActive) */}
          <button
            type="button"
            onClick={() => {
              if (!isSystemActive) {
                activateRadhaSystem();
              } else {
                setWakeWordEnabled((v) => !v);
              }
            }}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all cursor-pointer ${
              isSystemActive && wakeWordEnabled
                ? "text-black"
                : "bg-black/55 text-white/70 border-white/15 hover:text-white hover:bg-white/10"
            }`}
            style={
              isSystemActive && wakeWordEnabled
                ? {
                    backgroundColor: primary,
                    borderColor: primary,
                    boxShadow: isWaitingForWakeWord ? `0 0 16px ${primary}66` : undefined,
                  }
                : undefined
            }
            aria-label={
              isWaitingForWakeWord
                ? `Listening for wake-word ${wakeWordLabel}`
                : `Hands-free Wake-Word: Say ${wakeWordLabel}`
            }
            title={
              isWaitingForWakeWord
                ? `Actively listening for "${wakeWordLabel}" — click to pause wake-word`
                : `Hands-free Wake-Word: Say "${wakeWordLabel}"`
            }
          >
            {isWaitingForWakeWord ? (
              <span className="relative flex h-2.5 w-2.5 shrink-0" aria-hidden="true">
                <span className="motion-safe:animate-ping absolute inline-flex h-full w-full rounded-full bg-black/70 opacity-75" />
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-black" />
              </span>
            ) : (
              <Radio size={13} className="shrink-0" />
            )}
            <span className={isWaitingForWakeWord ? "inline" : "hidden lg:inline"}>
              {isWaitingForWakeWord
                ? `SAY "${wakeWordLabel}"`
                : isSystemActive && wakeWordEnabled
                ? `WAKE: ARMED`
                : `WAKE: "${wakeWordLabel}"`}
            </span>
          </button>

          {/* Upgrade 4: Collapsible Command & Insights Side-Panel Toggle */}
          <button
            type="button"
            onClick={() => setIsInsightsOpen((v) => !v)}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border flex items-center gap-1.5 transition-all cursor-pointer ${
              isInsightsOpen
                ? "text-black"
                : "bg-black/50 text-white/80 border-white/15 hover:bg-white/10"
            }`}
            style={
              isInsightsOpen
                ? { backgroundColor: secondary, borderColor: secondary }
                : { borderColor: `${secondary}45` }
            }
            title="Open Social Media, Workspace Insights & Daily Care Panel"
          >
            <BarChart3 size={13} />
            <span className="hidden sm:inline">INSIGHTS</span>
          </button>

          {/* Smart Command Hub Quick Open */}
          <button
            type="button"
            onClick={() => {
              if (isPanelOpen && activeTab === "hub") {
                setIsPanelOpen(false);
              } else {
                setActiveTab("hub");
                setIsPanelOpen(true);
              }
            }}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border flex items-center gap-1.5 transition-all cursor-pointer ${
              isPanelOpen && activeTab === "hub"
                ? "text-black"
                : "bg-black/50 text-white/80 border-white/15 hover:bg-white/10"
            }`}
            style={
              isPanelOpen && activeTab === "hub"
                ? { backgroundColor: primary, borderColor: primary }
                : { borderColor: `${primary}45` }
            }
            title="Open Smart Command Hub (Alarms, Tasks, Web Intel, Scanner, Google Workspace, Bond)"
          >
            <Layers size={13} />
            <span className="hidden sm:inline">SMART HUB</span>
            {(activeRemindersCount > 0 || pendingTasksCount > 0) && (
              <span className="text-[10px] px-1 rounded bg-black/30">
                {activeRemindersCount + pendingTasksCount}
              </span>
            )}
          </button>

          {/* Full Chat & Guide Drawer Toggle */}
          <button
            type="button"
            onClick={() => {
              if (isPanelOpen && activeTab !== "hub") {
                setIsPanelOpen(false);
              } else {
                setActiveTab("chat");
                setIsPanelOpen(true);
              }
            }}
            className="px-2.5 py-1.5 rounded-lg text-[11px] font-mono font-semibold border bg-black/50 text-white/75 border-white/15 hover:bg-white/10 hover:text-white flex items-center gap-1.5 transition-all cursor-pointer"
            title="Open Chat & Tails Guide"
          >
            <MessageSquare size={13} />
            <span className="hidden md:inline">CONSOLE</span>
          </button>

          {messages.length > 0 && (
            <button
              type="button"
              onClick={() => handleClearChatHistory()}
              className="p-2 rounded-lg bg-black/50 hover:bg-red-500/20 hover:text-red-400 transition-colors border border-white/15 cursor-pointer"
              title="Clear Chat Transcript (Permanent memory stays safe)"
            >
              <Trash2 size={15} className="opacity-75" />
            </button>
          )}

          <button
            type="button"
            onClick={() => {
              const next = !isMicMuted;
              setIsMicMuted(next);
              if (liveSessionRef.current) liveSessionRef.current.isMicMuted = next;
            }}
            className="p-2 rounded-lg bg-black/50 hover:bg-white/10 transition-colors border border-white/15 cursor-pointer"
            title={isMicMuted ? "Unmute Microphone" : "Mute Microphone"}
          >
            {isMicMuted ? (
              <MicOff size={15} className="text-red-400" />
            ) : (
              <Mic size={15} className="opacity-80" />
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              const next = !isMuted;
              setIsMuted(next);
              if (liveSessionRef.current) liveSessionRef.current.isMuted = next;
            }}
            className="p-2 rounded-lg bg-black/50 hover:bg-white/10 transition-colors border border-white/15 cursor-pointer"
            title={isMuted ? "Unmute Radha Voice" : "Mute Radha Voice"}
          >
            {isMuted ? (
              <VolumeX size={15} className="text-red-400" />
            ) : (
              <Volume2 size={15} className="opacity-80" />
            )}
          </button>
        </div>
      </header>

      {/* Proprietary Signature Engine: 3D-Projected Synaptic Neural Consciousness Field */}
      <NeuralConsciousnessField
        config={radhaConfig}
        appState={appState}
        emotion={radhaEmotion}
        latestSentiment={sentiments[0] || null}
        ownerVerified={ownerFaceStatus === "verified"}
        isWaitingForWakeWord={isWaitingForWakeWord}
      />

      {/* Main Content - Center Visualizer & Status */}
      <main className="absolute inset-0 flex flex-row items-center justify-between w-full h-full z-10 overflow-hidden pt-20 pb-28 px-4 md:px-12 pointer-events-none">
        <div className="flex w-full h-full items-center justify-center relative">
          <Visualizer state={appState} emotion={radhaEmotion} config={radhaConfig} />
        </div>
      </main>

      {/* Left-Side 100% Real Network Telemetry + Boss Health + Biological Status Panel */}
      <HackerTelemetryPanel
        config={radhaConfig}
        isSessionActive={isSessionActive}
        wakeWordActive={isSystemActive && wakeWordEnabled}
        cyberLogs={cyberLogs}
        bondingLevel={bonding.level}
        sentiments={sentiments}
        ownerVerified={ownerFaceStatus === "verified"}
        biologicalStatus={biologicalStatus}
        isSyncingBio={isSyncingBio}
        onConnectGoogleFit={handleConnectGoogleFit}
        onImportAppleHealthFile={handleImportAppleHealthFile}
        onDisconnectBio={handleDisconnectBio}
      />

      {/* Right-Side Compact Terminal Live Chat Box */}
      {!isPanelOpen && (
        <CompactChatBox
          messages={messages}
          config={radhaConfig}
          emotion={radhaEmotion}
          appState={appState}
          memoryCount={memories.length}
          onSendQuickMessage={(text) => handleTextCommand(text)}
          onOpenFullPanel={() => {
            setActiveTab("chat");
            setIsPanelOpen(true);
          }}
        />
      )}

      {/* Footer Controls (Clean — Voice Waveform Bar Removed as Requested) */}
      <footer className="absolute bottom-0 left-0 w-full flex flex-col items-center justify-center pb-5 md:pb-6 z-20 shrink-0 gap-3">
        <AnimatePresence>
          {showTextInput && (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              onSubmit={handleTextSubmit}
              className="w-full max-w-md flex items-center gap-2 bg-[#040d11]/90 border rounded-xl p-1.5 pl-4 backdrop-blur-md shadow-2xl mx-4"
              style={{ borderColor: `${primary}45` }}
            >
              <input
                type="text"
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder={`Command ${radhaConfig.assistantName || "Radha"}...`}
                className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/35 text-xs font-mono"
                autoFocus
              />
              <button
                type="submit"
                disabled={!textInput.trim()}
                className="p-2 rounded-lg text-black disabled:opacity-40 transition-colors cursor-pointer"
                style={{ backgroundColor: primary }}
              >
                <Send size={15} />
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <div className="flex items-center flex-wrap justify-center gap-2 sm:gap-2.5 px-3 font-mono">
          {/* Strict Manual Start / Stop Master Gate Button */}
          <button
            type="button"
            onClick={toggleSystemActive}
            className="flex items-center gap-2 px-4 sm:px-5 py-3 rounded-xl font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 shadow-2xl border cursor-pointer"
            style={
              isSystemActive
                ? {
                    backgroundColor: "rgba(239, 68, 68, 0.22)",
                    borderColor: "#ef4444",
                    color: "#fca5a5",
                    boxShadow: "0 0 22px rgba(239, 68, 68, 0.32)",
                  }
                : {
                    backgroundColor: `${primary}24`,
                    borderColor: primary,
                    color: primary,
                    boxShadow: `0 0 24px ${primary}38`,
                  }
            }
            title={
              isSystemActive
                ? "Stop Radha immediately (kills mic, TTS, wake-word & all timers)"
                : "Start / Activate Radha system (arms wake-word, mic & smart care)"
            }
          >
            <Power size={17} />
            <span>{isSystemActive ? "STOP" : "START"}</span>
          </button>

          {/* Primary Voice Link / Smart Barge-In Mic Control */}
          <button
            type="button"
            onClick={toggleListening}
            className="group relative flex items-center gap-2 px-5 sm:px-6 py-3 rounded-xl font-bold text-xs sm:text-sm uppercase tracking-wider transition-all duration-300 shadow-2xl border cursor-pointer"
            style={
              isSessionActive && appState === "speaking"
                ? {
                    backgroundColor: "rgba(245, 158, 11, 0.22)",
                    borderColor: "#f59e0b",
                    color: "#fcd34d",
                    boxShadow: "0 0 22px rgba(245, 158, 11, 0.35)",
                  }
                : isSessionActive
                ? {
                    backgroundColor: "rgba(255, 42, 85, 0.2)",
                    borderColor: "#ff2a55",
                    color: "#ff5c7c",
                    boxShadow: "0 0 24px rgba(255, 42, 85, 0.35)",
                  }
                : {
                    backgroundColor: `${secondary}1e`,
                    borderColor: secondary,
                    color: secondary,
                    boxShadow: `0 0 22px ${secondary}30`,
                  }
            }
          >
            {isSessionActive && appState === "speaking" ? (
              <>
                <Hand size={17} />
                <span>INTERRUPT</span>
              </>
            ) : isSessionActive ? (
              <>
                <MicOff size={17} />
                <span>END CALL</span>
              </>
            ) : (
              <>
                <Mic size={17} className="group-hover:animate-bounce" />
                <span>TALK</span>
              </>
            )}
          </button>

          {!isSessionActive && (
            <button
              type="button"
              onClick={() => setShowTextInput(!showTextInput)}
              className="p-3 rounded-xl bg-black/60 border border-white/15 hover:bg-white/10 transition-colors shadow-xl cursor-pointer"
              title="Command Input"
            >
              <Keyboard size={18} className="opacity-80" />
            </button>
          )}

          {/* Quick File / Photo / Code Scanner Button */}
          <button
            type="button"
            onClick={() => openHubSection("scanner")}
            className="p-3 rounded-xl bg-black/60 border border-white/15 hover:bg-white/10 transition-colors shadow-xl cursor-pointer"
            title="Scan Photo, Screenshot, PDF or Code"
          >
            <FileSearch size={18} style={{ color: secondary }} />
          </button>

          {/* Live Camera + Owner Face ID Button (always available!) */}
          <button
            type="button"
            onClick={toggleCamera}
            className={`p-3 rounded-xl border transition-colors shadow-xl cursor-pointer ${
              isCameraActive
                ? "bg-cyan-500/25 border-cyan-400 text-cyan-300"
                : "bg-black/60 border-white/15 hover:bg-white/10"
            }`}
            title={isCameraActive ? "Stop Camera" : "Start Camera & Owner Face ID"}
          >
            {isCameraActive ? <CameraOff size={18} /> : <Camera size={18} className="opacity-80" />}
          </button>

          {isSessionActive && (
            <button
              type="button"
              onClick={toggleScreenShare}
              className={`p-3 rounded-xl border transition-colors shadow-xl cursor-pointer ${
                isScreenSharing
                  ? "bg-emerald-500/25 border-emerald-400 text-emerald-300"
                  : "bg-black/60 border-white/15 hover:bg-white/10"
              }`}
              title={isScreenSharing ? "Stop Screen Share" : "Share Screen"}
            >
              {isScreenSharing ? <MonitorOff size={18} /> : <MonitorUp size={18} className="opacity-80" />}
            </button>
          )}
        </div>
      </footer>

      {/* Sliding Side Drawer (Chat Console, Smart Command Hub, Tails OS Guide) */}
      <AnimatePresence>
        {isPanelOpen && (
          <motion.div
            initial={{ x: "100%", opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: "100%", opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 180 }}
            className="absolute top-0 right-0 h-full w-full sm:w-[440px] md:w-[470px] bg-[#040b0f]/95 border-l backdrop-blur-xl z-30 flex flex-col pt-16 pb-4 shadow-2xl pointer-events-auto"
            style={{ borderColor: `${primary}35` }}
          >
            {/* Drawer Tab Headers */}
            <div className="flex items-center px-4 border-b border-white/10 shrink-0 mb-3 gap-1 font-mono">
              <button
                type="button"
                onClick={() => setActiveTab("chat")}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                  activeTab === "chat"
                    ? "text-white"
                    : "border-transparent text-white/45 hover:text-white"
                }`}
                style={activeTab === "chat" ? { borderColor: primary, color: primary } : undefined}
              >
                <MessageSquare size={13} />
                <span>Chat</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("hub")}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                  activeTab === "hub"
                    ? "text-white"
                    : "border-transparent text-white/45 hover:text-white"
                }`}
                style={activeTab === "hub" ? { borderColor: primary, color: primary } : undefined}
              >
                <Layers size={13} />
                <span>Smart Hub</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("guide")}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-[11px] font-bold uppercase tracking-wider border-b-2 transition-all cursor-pointer ${
                  activeTab === "guide"
                    ? "text-white"
                    : "border-transparent text-white/45 hover:text-white"
                }`}
                style={activeTab === "guide" ? { borderColor: primary, color: primary } : undefined}
              >
                <BookOpen size={13} />
                <span>Tails</span>
              </button>

              <button
                type="button"
                onClick={() => setIsPanelOpen(false)}
                className="ml-auto p-1.5 hover:bg-white/10 rounded-lg text-white/50 hover:text-white transition-all cursor-pointer"
                title="Close Drawer"
              >
                <X size={15} />
              </button>
            </div>

            {/* Drawer Tab Content */}
            <div className="flex-1 min-h-0 px-4 overflow-hidden flex flex-col pb-2">
              {activeTab === "hub" ? (
                <SmartCommandHub
                  config={radhaConfig}
                  initialSection={smartHubSection}
                  reminders={reminders}
                  tasks={tasks}
                  moods={moods}
                  sentiments={sentiments}
                  latestSentiment={sentiments[0] || null}
                  bonding={bonding}
                  currentEmotion={radhaEmotion}
                  onCreateReminder={handleCreateReminder}
                  onDeleteReminder={handleDeleteReminder}
                  onCreateTask={handleCreateTask}
                  onToggleTask={handleToggleTask}
                  onDeleteTask={handleDeleteTask}
                  onLogMood={async (em, note) => {
                    setRadhaEmotion(em);
                    await recordMoodProgress(em, note, 20);
                    pushCyberLog(`MOOD LOGGED: ${em.toUpperCase()} (+20 XP)`);
                  }}
                  onRunDeepSentiment={handleRunDeepSentiment}
                  onSpeakText={speakDirectText}
                  onAskRadha={handleAskQuestion}
                  onCyberLog={pushCyberLog}
                />
              ) : activeTab === "chat" ? (
                <div className="flex flex-col h-full justify-between">
                  <div className="mb-3 shrink-0">
                    <WeatherWidget onAskQuestion={handleAskQuestion} />
                  </div>

                  <div className="flex-1 overflow-y-auto pr-1 mb-4 space-y-3.5 scrollbar-thin">
                    {messages.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center px-4 text-white/35 gap-3">
                        <MessageSquare size={32} style={{ color: primary }} className="opacity-35" />
                        <p className="text-xs font-mono font-semibold text-white/75">
                          RADHA NEURAL CONSOLE READY
                        </p>
                        <div className="mt-2 w-full flex flex-col gap-2 max-w-sm">
                          {[
                            "Aaj ki breaking India news kya hai?",
                            "10 minute baad paani peene ka reminder laga do",
                            "Mere pending tasks kya hain?",
                            "Radha, tumhe kab banaya gaya tha?",
                          ].map((promptText, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => handleAskQuestion(promptText)}
                              className="text-left px-3 py-2 bg-white/5 border border-white/10 rounded-xl text-xs hover:bg-white/10 text-white/80 transition-all cursor-pointer flex items-center justify-between"
                            >
                              <span>{promptText}</span>
                              <span style={{ color: primary }} className="font-mono font-bold">
                                &gt;
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : (
                      messages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"}`}
                        >
                          <div
                            className="text-[9px] font-mono mb-0.5 tracking-wider opacity-60"
                            style={{ color: msg.sender === "user" ? primary : secondary }}
                          >
                            {msg.sender === "user" ? "RAVINDRA BOSS" : (radhaConfig.assistantName || "RADHA").toUpperCase()}
                          </div>
                          <div
                            className={`px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed max-w-[85%] break-words shadow-sm ${
                              msg.sender === "user"
                                ? "bg-emerald-500/15 text-emerald-50 border border-emerald-400/25 rounded-tr-none"
                                : "bg-white/5 text-white/90 border border-white/10 rounded-tl-none"
                            }`}
                          >
                            <span className="whitespace-pre-wrap">{msg.text}</span>
                          </div>
                        </div>
                      ))
                    )}
                    {appState === "processing" && (
                      <div className="flex flex-col items-start">
                        <div className="text-[9px] font-mono mb-0.5 tracking-wider opacity-60" style={{ color: secondary }}>
                          RADHA
                        </div>
                        <div className="px-3 py-2 bg-white/5 text-xs text-white/60 rounded-2xl rounded-tl-none border border-white/10 flex items-center gap-2 font-mono">
                          <Loader2 size={12} className="animate-spin" style={{ color: secondary }} />
                          <span className="text-[11px]">COMPUTING...</span>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <form
                    onSubmit={handleTextSubmit}
                    className="flex gap-2 bg-black/50 border border-white/15 rounded-xl p-1.5 pl-3.5 shrink-0 focus-within:border-emerald-400/50 transition-all"
                  >
                    <input
                      type="text"
                      value={textInput}
                      onChange={(e) => setTextInput(e.target.value)}
                      placeholder="Type command or message..."
                      className="flex-1 bg-transparent border-none outline-none text-white placeholder:text-white/30 text-xs py-1 font-mono"
                    />
                    <button
                      type="submit"
                      disabled={!textInput.trim() || appState === "processing"}
                      className="p-2 rounded-lg text-black disabled:opacity-30 transition-colors cursor-pointer"
                      style={{ backgroundColor: primary }}
                    >
                      <Send size={13} />
                    </button>
                  </form>
                </div>
              ) : (
                <TailsGuide onAskQuestion={handleAskQuestion} />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Camera / Screen Share Preview + Live Biometric Owner Face ID Overlay */}
      <AnimatePresence>
        {(isCameraActive || isScreenSharing) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            className="absolute bottom-24 left-4 md:left-8 z-30 w-56 h-44 bg-black/90 border rounded-xl overflow-hidden shadow-2xl pointer-events-auto flex flex-col backdrop-blur-md"
            style={{
              borderColor:
                ownerFaceStatus === "spoof"
                  ? "#DC2626"
                  : ownerFaceStatus === "verified"
                  ? "#16A34A"
                  : ownerFaceStatus === "guest"
                  ? "#D97706"
                  : `${primary}60`,
            }}
          >
            <div className="absolute top-0 left-0 w-full bg-gradient-to-b from-black/90 to-transparent p-2 flex justify-between items-center z-10 font-mono">
              <span
                className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-black/70"
                style={{
                  color:
                    ownerFaceStatus === "spoof"
                      ? "#f87171"
                      : ownerFaceStatus === "verified"
                      ? "#4ade80"
                      : ownerFaceStatus === "guest"
                      ? "#fbbf24"
                      : primary,
                }}
              >
                {isCameraActive
                  ? ownerFaceStatus === "spoof"
                    ? "SPOOF BLOCKED!"
                    : ownerFaceStatus === "verified"
                    ? `${ownerFaceInfo?.hashVerified ? "3D HASH" : "BOSS"} ${ownerFaceInfo?.confidence || 95}%`
                    : ownerFaceStatus === "scanning"
                    ? "3D LIVENESS SCAN..."
                    : ownerFaceStatus === "guest"
                    ? "GUEST DETECTED"
                    : "CAM // LIVE"
                  : "SCR // LIVE"}
              </span>
              <div className="flex gap-1 items-center">
                {isCameraActive && (
                  <button
                    type="button"
                    onClick={toggleFacingMode}
                    className="px-1.5 py-0.5 rounded bg-black/70 border border-white/15 text-white/90 text-[9px] font-bold cursor-pointer"
                  >
                    {facingMode === "user" ? "BACK" : "FRONT"}
                  </button>
                )}
                <button
                  type="button"
                  onClick={isCameraActive ? stopCamera : stopScreenShare}
                  className="p-1 rounded bg-red-500/80 hover:bg-red-600 text-white cursor-pointer"
                  title="Close preview"
                >
                  <X size={9} />
                </button>
              </div>
            </div>

            <video
              ref={(el) => {
                if (el) {
                  const stream = isCameraActive ? cameraStreamRef.current : screenStreamRef.current;
                  if (el.srcObject !== stream) el.srcObject = stream;
                  el.play().catch(() => {});
                }
              }}
              className={`w-full h-full object-cover ${isCameraActive && facingMode === "user" ? "scale-x-[-1]" : ""}`}
              muted
              playsInline
            />

            {isCameraActive && (
              <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/90 to-transparent p-2 flex items-center justify-between gap-2 z-10 font-mono">
                <span className="text-[9px] text-white/75 truncate">
                  {ownerFaceInfo?.expression
                    ? `Mood: ${ownerFaceInfo.expression}`
                    : radhaConfig.ownerPhotoUrl
                    ? "Face ID Ready"
                    : "Upload photo in Admin"}
                </span>
                <button
                  type="button"
                  disabled={ownerFaceStatus === "scanning"}
                  onClick={runOwnerFaceVerification}
                  className="px-2 py-1 rounded-md text-[9.5px] font-bold text-black flex items-center gap-1 disabled:opacity-50 cursor-pointer shrink-0"
                  style={{ backgroundColor: primary }}
                >
                  <ScanFace size={11} />
                  <span>{ownerFaceStatus === "scanning" ? "SCAN..." : "SCAN FACE"}</span>
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
