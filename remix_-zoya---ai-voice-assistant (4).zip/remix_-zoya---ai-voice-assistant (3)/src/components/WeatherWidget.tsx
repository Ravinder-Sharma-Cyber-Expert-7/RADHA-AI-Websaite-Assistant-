import React, { useState, useEffect } from "react";
import { 
  Sun, 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  CloudLightning, 
  Wind, 
  Droplets,
  Calendar, 
  Clock, 
  Search, 
  MapPin, 
  Loader2,
  AlertCircle
} from "lucide-react";

interface WeatherData {
  city: string;
  temp: number;
  apparentTemp: number;
  humidity: number;
  windSpeed: number;
  conditionCode: number;
  isDay: boolean;
  precipitation: number;
}

interface WeatherWidgetProps {
  onAskQuestion?: (question: string) => void;
}

export default function WeatherWidget({ onAskQuestion }: WeatherWidgetProps) {
  // Time and Date State
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  
  // Weather Search & Data State
  const [searchCity, setSearchCity] = useState("New Delhi");
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 1. Ticking Digital Clock
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // 3. Weather Fetcher (Open-Meteo & Geocoding)
  const fetchWeatherForCity = async (cityName: string) => {
    setLoading(true);
    setError(null);
    try {
      // Step A: Geocode city name to lat/long using Open-Meteo geocoding API
      const geoRes = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cityName)}&count=1&language=en&format=json`
      );
      const geoData = await geoRes.json();
      
      if (!geoData.results || geoData.results.length === 0) {
        throw new Error("City not found. Try another search!");
      }
      
      const { latitude, longitude, name: resolvedCityName, country } = geoData.results[0];
      
      // Step B: Fetch current weather
      const weatherRes = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation,weather_code,wind_speed_10m&timezone=auto`
      );
      const weatherData = await weatherRes.json();
      const current = weatherData.current;
      
      if (!current) {
        throw new Error("Could not retrieve weather data.");
      }

      const freshWeather: WeatherData = {
        city: `${resolvedCityName}, ${country}`,
        temp: Math.round(current.temperature_2m),
        apparentTemp: Math.round(current.apparent_temperature),
        humidity: current.relative_humidity_2m,
        windSpeed: Math.round(current.wind_speed_10m),
        conditionCode: current.weather_code,
        isDay: current.is_day === 1,
        precipitation: current.precipitation
      };

      setWeather(freshWeather);
      
      // Expose to window context so Radha services can access it dynamically
      const desc = getWeatherDescription(freshWeather.conditionCode);
      (window as any).currentWeatherText = `City: ${freshWeather.city}, Temp: ${freshWeather.temp}°C, Feel: ${freshWeather.apparentTemp}°C, Condition: ${desc}, Humidity: ${freshWeather.humidity}%, Wind: ${freshWeather.windSpeed} km/h`;
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  // Run on mount
  useEffect(() => {
    fetchWeatherForCity("New Delhi");
  }, []);

  // Try Geolocation
  const handleUseLocation = () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      return;
    }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          // Reverse geocode or fetch weather directly
          const weatherRes = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,apparent_temperature,relative_humidity_2m,is_day,precipitation,weather_code,wind_speed_10m&timezone=auto`
          );
          const weatherData = await weatherRes.json();
          const current = weatherData.current;
          
          if (!current) {
            throw new Error("Could not retrieve weather data.");
          }

          const freshWeather: WeatherData = {
            city: "Your Location",
            temp: Math.round(current.temperature_2m),
            apparentTemp: Math.round(current.apparent_temperature),
            humidity: current.relative_humidity_2m,
            windSpeed: Math.round(current.wind_speed_10m),
            conditionCode: current.weather_code,
            isDay: current.is_day === 1,
            precipitation: current.precipitation
          };

          setWeather(freshWeather);
          const desc = getWeatherDescription(freshWeather.conditionCode);
          (window as any).currentWeatherText = `Your Location, Temp: ${freshWeather.temp}°C, Feel: ${freshWeather.apparentTemp}°C, Condition: ${desc}, Humidity: ${freshWeather.humidity}%, Wind: ${freshWeather.windSpeed} km/h`;
        } catch (err: any) {
          setError("Failed to fetch weather for your location.");
        } finally {
          setLoading(false);
        }
      },
      (err) => {
        setError("Location permission denied or unavailable.");
        setLoading(false);
      }
    );
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchCity.trim()) {
      fetchWeatherForCity(searchCity.trim());
    }
  };

  // Helper to get weather code description and icon
  const getWeatherDescription = (code: number): string => {
    if (code === 0) return "Clear Sky";
    if (code >= 1 && code <= 3) return "Mainly Clear / Partly Cloudy";
    if (code === 45 || code === 48) return "Foggy";
    if (code >= 51 && code <= 55) return "Drizzle";
    if (code >= 61 && code <= 65) return "Rainy";
    if (code >= 71 && code <= 77) return "Snowy";
    if (code >= 80 && code <= 82) return "Rain Showers";
    if (code >= 95 && code <= 99) return "Thunderstorm";
    return "Overcast";
  };

  const getWeatherIcon = (code: number, isDay: boolean) => {
    const size = 32;
    if (code === 0) {
      return <Sun size={size} className={isDay ? "text-amber-400 animate-spin-slow" : "text-indigo-200"} />;
    }
    if (code >= 1 && code <= 3) {
      return <Cloud size={size} className="text-blue-300" />;
    }
    if (code === 45 || code === 48) {
      return <Cloud size={size} className="text-gray-400 opacity-60" />;
    }
    if (code >= 51 && code <= 55) {
      return <CloudRain size={size} className="text-cyan-400" />;
    }
    if (code >= 61 && code <= 65) {
      return <CloudRain size={size} className="text-blue-400 animate-pulse" />;
    }
    if (code >= 71 && code <= 77) {
      return <CloudSnow size={size} className="text-white" />;
    }
    if (code >= 80 && code <= 82) {
      return <CloudRain size={size} className="text-blue-500" />;
    }
    if (code >= 95 && code <= 99) {
      return <CloudLightning size={size} className="text-violet-400 animate-bounce" />;
    }
    return <Cloud size={size} className="text-slate-300" />;
  };

  // Date formatted beautifully
  const formattedDay = currentTime.toLocaleDateString("en-US", { weekday: "long" });
  const formattedDateString = currentTime.toLocaleDateString("en-US", {
    day: "numeric",
    month: "long",
    year: "numeric"
  });

  return (
    <div className="w-full bg-black/55 border border-emerald-400/20 rounded-xl p-3.5 flex flex-col gap-3 backdrop-blur-md shadow-xl text-left font-mono">
      
      {/* 1. Date, Ticking Clock & Calendar Display */}
      <div className="flex justify-between items-center border-b border-white/10 pb-2.5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-400/25 text-emerald-300">
            <Calendar size={16} />
          </div>
          <div>
            <h4 className="text-[10px] uppercase tracking-wider text-emerald-400/80">{formattedDay}</h4>
            <p className="text-xs font-semibold text-white/90">{formattedDateString}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-black/60 px-2.5 py-1.5 rounded-lg border border-cyan-400/20">
          <Clock size={12} className="text-cyan-400 animate-pulse" />
          <span className="text-xs font-medium tracking-widest text-cyan-300 tabular-nums">
            {currentTime.toLocaleTimeString("en-US", { hour12: false })}
          </span>
        </div>
      </div>

      {/* 2. Real-Time Weather Section */}
      <div className="flex flex-col gap-2.5">
        {/* Search Bar / Location Controls */}
        <form onSubmit={handleSearchSubmit} className="flex gap-1.5">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchCity}
              onChange={(e) => setSearchCity(e.target.value)}
              placeholder="Search city weather..."
              className="w-full bg-white/5 hover:bg-white/10 focus:bg-black/50 text-xs border border-white/15 rounded-lg py-1.5 pl-8 pr-2 outline-none text-white focus:border-emerald-400/60 transition-all placeholder:text-white/25"
            />
            <Search size={12} className="absolute left-2.5 top-2.5 text-white/40" />
          </div>
          <button
            type="submit"
            className="px-2.5 py-1.5 bg-emerald-400 hover:bg-emerald-300 rounded-lg text-black font-bold transition-colors cursor-pointer"
            title="Search city"
          >
            <Search size={12} />
          </button>
          <button
            type="button"
            onClick={handleUseLocation}
            className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 border border-white/15 rounded-lg text-cyan-300 transition-colors cursor-pointer"
            title="Use current GPS location"
          >
            <MapPin size={12} />
          </button>
        </form>

        {loading ? (
          <div className="flex items-center justify-center py-4 gap-2 text-xs text-white/50">
            <Loader2 size={14} className="animate-spin text-violet-400" />
            <span>Fetching weather details...</span>
          </div>
        ) : error ? (
          <div className="flex items-center gap-2 p-2 bg-red-500/10 border border-red-500/20 rounded-xl text-[11px] text-red-300">
            <AlertCircle size={14} />
            <span className="flex-1">{error}</span>
            <button 
              onClick={() => fetchWeatherForCity("New Delhi")} 
              className="underline font-bold text-red-400 hover:text-red-300"
            >
              Reset
            </button>
          </div>
        ) : weather ? (
          <div className="grid grid-cols-2 gap-2 bg-black/30 p-3 rounded-xl border border-white/5">
            {/* Condition & Icon */}
            <div className="flex items-center gap-3">
              <div className="p-1 rounded-lg bg-white/5 border border-white/5 shrink-0">
                {getWeatherIcon(weather.conditionCode, weather.isDay)}
              </div>
              <div className="min-w-0">
                <p className="text-[10px] text-white/40 font-mono truncate tracking-wider uppercase">
                  {weather.city.split(",")[0]}
                </p>
                <p className="text-xs font-semibold text-white/90 truncate">
                  {getWeatherDescription(weather.conditionCode)}
                </p>
              </div>
            </div>

            {/* Temperature & Stats */}
            <div className="flex flex-col items-end justify-center">
              <div className="flex items-start">
                <span className="text-xl font-bold font-mono text-white tracking-tighter tabular-nums">{weather.temp}</span>
                <span className="text-xs font-semibold text-emerald-400 mt-0.5">°C</span>
              </div>
              <p className="text-[10px] text-white/40">Feels like {weather.apparentTemp}°C</p>
            </div>

            {/* Sub stats */}
            <div className="col-span-2 grid grid-cols-2 border-t border-white/10 pt-2 mt-1 gap-2 text-[10px] text-white/60 font-mono">
              <div className="flex items-center gap-1.5">
                <Droplets size={10} className="text-cyan-400" />
                <span>Hum: {weather.humidity}%</span>
              </div>
              <div className="flex items-center gap-1.5 justify-end">
                <Wind size={10} className="text-emerald-400" />
                <span>Wind: {weather.windSpeed} km/h</span>
              </div>
            </div>
          </div>
        ) : null}
      </div>

    </div>
  );
}
