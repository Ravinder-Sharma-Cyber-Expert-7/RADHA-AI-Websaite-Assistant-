export interface DeviceBatteryStatus {
  supported: boolean;
  level: number | null; // 0..100
  charging: boolean;
}

export interface VoiceNoteItem {
  id: string;
  content: string;
  createdAt: number;
}

const VOICE_NOTES_STORAGE_KEY = "radha_voice_notes_v1";

// ==========================================
// 1. REAL PERSISTENT VOICE NOTES (localStorage)
// ==========================================
export function loadVoiceNotes(): VoiceNoteItem[] {
  try {
    const raw = localStorage.getItem(VOICE_NOTES_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item) => item && typeof item.content === "string" && item.content.trim().length > 0)
      .slice(0, 100);
  } catch {
    return [];
  }
}

export function saveVoiceNotes(notes: VoiceNoteItem[]): void {
  try {
    localStorage.setItem(VOICE_NOTES_STORAGE_KEY, JSON.stringify(notes.slice(0, 100)));
  } catch {}
}

export function addVoiceNote(content: string): VoiceNoteItem | null {
  const clean = content.trim();
  if (!clean) return null;
  const existing = loadVoiceNotes();
  const note: VoiceNoteItem = {
    id: `note-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    content: clean,
    createdAt: Date.now(),
  };
  saveVoiceNotes([note, ...existing]);
  return note;
}

export function deleteVoiceNote(id: string): VoiceNoteItem[] {
  const updated = loadVoiceNotes().filter((n) => n.id !== id);
  saveVoiceNotes(updated);
  return updated;
}

// ==========================================
// 2. NATURAL VOICE NOTE & TIMED REMINDER PARSER
// ==========================================
export type VoiceNoteOrReminderIntent =
  | { type: "note"; content: string }
  | { type: "reminder"; title: string; delayMinutes: number }
  | { type: "read_notes" }
  | null;

const HINDI_NUM_MAP: Record<string, number> = {
  ek: 1,
  एक: 1,
  do: 2,
  दो: 2,
  teen: 3,
  तीन: 3,
  chaar: 4,
  char: 4,
  चार: 4,
  paanch: 5,
  panch: 5,
  पांच: 5,
  पाँच: 5,
  das: 10,
  दस: 10,
  pandrah: 15,
  पंद्रह: 15,
  bees: 20,
  बीस: 20,
  tees: 30,
  तीस: 30,
  saath: 60,
  साठ: 60,
};

function parseNumericToken(token: string): number | null {
  const trimmed = token.trim().toLowerCase();
  const num = Number(trimmed);
  if (!Number.isNaN(num) && num > 0) return num;
  if (HINDI_NUM_MAP[trimmed]) return HINDI_NUM_MAP[trimmed];
  return null;
}

export function detectNoteOrReminderCommand(text: string): VoiceNoteOrReminderIntent {
  const clean = text.trim();
  if (clean.length < 3) return null;

  // Strip optional leading wake word "राधा," / "radha"
  const stripped = clean
    .replace(/^(?:hey\s+)?(?:radha|राधा)[,:\s-]+/i, "")
    .trim();

  // Read saved notes
  if (
    /(?:mere|my|saare|sabhi|all)\s+(?:notes?|नोट्स?)\s+(?:sunao|batao|dikhao|padho|read|show)|(?:नोट्स?|नोट)\s+(?:सुनाओ|बताओ|दिखाओ|पढ़ो)/i.test(
      stripped
    )
  ) {
    return { type: "read_notes" };
  }

  // Save a voice note: "नोट लिखो ...", "note likho ...", "save note ...", "make a note ..."
  const notePatterns: RegExp[] = [
    /^(?:ek\s+|एक\s+)?(?:नोट\s*(?:लिखो|बनाओ|सेव\s*करो|लिख\s*लो)|note\s*(?:likho|likh\s*lo|banao|save\s*karo|karo)|save\s+(?:a\s+)?note|take\s+(?:a\s+)?note|make\s+(?:a\s+)?note|write\s+(?:a\s+)?note)\s*(?:ki|that|:|-)?\s*(.+)$/i,
    /^(?:note\s+down|नोट\s+डाउन\s+करो)\s*(?:ki|that|:|-)?\s*(.+)$/i,
  ];
  for (const rx of notePatterns) {
    const m = stripped.match(rx);
    if (m?.[1] && m[1].trim().length >= 2) {
      return { type: "note", content: m[1].trim() };
    }
  }

  // Timed reminder / alarm:
  // e.g. "10 मिनट बाद याद दिलाना पानी पीना है", "10 minute baad yaad dilana call karna hai", "remind me in 5 minutes to drink water"
  const hindiTimerMatch = stripped.match(
    /(\d+|ek|do|teen|chaar|char|paanch|panch|das|pandrah|bees|tees|एक|दो|तीन|चार|पांच|पाँच|दस|पंद्रह|बीस|तीस)\s*(?:मिनट|मिनिट|minute|minutes|min|घंटे|घंटा|hour|hours|hr|सेकंड|second|seconds|sec)\s*(?:बाद|baad|me|mein|ke\s*baad|का|ka)?\s*(?:याद\s*दिलाना|याद\s*दिला\s*देना|yaad\s*dilana|yaad\s*dila\s*dena|reminder\s*(?:laga\s*do|set\s*karo|lagana)?|alarm\s*(?:laga\s*do|set\s*karo)?|रिमाइंडर|अलार्म)\s*(?:ki|कि|to|:|-)?\s*(.*)$/i
  );
  if (hindiTimerMatch) {
    const rawNum = parseNumericToken(hindiTimerMatch[1]);
    if (rawNum) {
      let delayMinutes = rawNum;
      if (/घंटे|घंटा|hour|hours|hr/i.test(stripped)) delayMinutes = rawNum * 60;
      else if (/सेकंड|second|seconds|sec/i.test(stripped)) delayMinutes = Math.max(0.25, rawNum / 60);

      // Extract title either after the keyword or before the number
      let title = (hindiTimerMatch[2] || "").trim();
      if (!title) {
        const prefix = stripped.slice(0, hindiTimerMatch.index || 0).trim();
        title = prefix.replace(/^(?:mujhe|मुझे|please|plz)\s+/i, "").trim();
      }
      title = title
        .replace(/^(?:ka|ki|ke|का|की|के)\s+/i, "")
        .replace(/\s*(?:laga\s*do|set\s*karo|कर\s*देना|लगा\s*दो)$/i, "")
        .trim();

      return {
        type: "reminder",
        title: title || "Boss Reminder",
        delayMinutes,
      };
    }
  }

  // English reminder: "remind me in 10 minutes to check email"
  const enTimerMatch = stripped.match(
    /^(?:remind\s+me|set\s+(?:a\s+)?(?:reminder|alarm|timer))\s+(?:in|after|for)\s+(\d+)\s*(minutes?|mins?|hours?|hrs?|seconds?|secs?)\s*(?:to|about|for|:|-)?\s*(.*)$/i
  );
  if (enTimerMatch) {
    const rawNum = Number(enTimerMatch[1]);
    if (!Number.isNaN(rawNum) && rawNum > 0) {
      let delayMinutes = rawNum;
      if (/hour|hr/i.test(enTimerMatch[2])) delayMinutes = rawNum * 60;
      else if (/sec/i.test(enTimerMatch[2])) delayMinutes = Math.max(0.25, rawNum / 60);
      return {
        type: "reminder",
        title: (enTimerMatch[3] || "").trim() || "Boss Reminder",
        delayMinutes,
      };
    }
  }

  return null;
}

// ==========================================
// 3. REAL SCREEN WAKE LOCK HELPER (APK / MOBILE READY)
// ==========================================
let activeWakeLockSentinel: any = null;

export async function acquireScreenWakeLock(): Promise<boolean> {
  try {
    const wl = (navigator as any).wakeLock;
    if (!wl || typeof wl.request !== "function") return false;
    if (activeWakeLockSentinel && !activeWakeLockSentinel.released) return true;
    activeWakeLockSentinel = await wl.request("screen");
    activeWakeLockSentinel.addEventListener?.("release", () => {
      activeWakeLockSentinel = null;
    });
    return true;
  } catch {
    return false;
  }
}

export async function releaseScreenWakeLock(): Promise<void> {
  try {
    if (activeWakeLockSentinel) {
      await activeWakeLockSentinel.release();
      activeWakeLockSentinel = null;
    }
  } catch {
    activeWakeLockSentinel = null;
  }
}

export function isScreenWakeLockHeld(): boolean {
  return Boolean(activeWakeLockSentinel && !activeWakeLockSentinel.released);
}

// ==========================================
// 4. REAL BATTERY SUBSCRIBER
// ==========================================
export function subscribeRealBattery(
  onUpdate: (status: DeviceBatteryStatus) => void
): () => void {
  let active = true;
  let batteryObj: any = null;

  const emit = () => {
    if (!active || !batteryObj) return;
    onUpdate({
      supported: true,
      level: Math.round(Number(batteryObj.level || 0) * 100),
      charging: Boolean(batteryObj.charging),
    });
  };

  if (typeof (navigator as any).getBattery === "function") {
    (navigator as any)
      .getBattery()
      .then((bat: any) => {
        if (!active) return;
        batteryObj = bat;
        emit();
        bat.addEventListener?.("levelchange", emit);
        bat.addEventListener?.("chargingchange", emit);
      })
      .catch(() => {
        if (active) onUpdate({ supported: false, level: null, charging: false });
      });
  } else {
    onUpdate({ supported: false, level: null, charging: false });
  }

  return () => {
    active = false;
    if (batteryObj) {
      try {
        batteryObj.removeEventListener?.("levelchange", emit);
        batteryObj.removeEventListener?.("chargingchange", emit);
      } catch {}
    }
  };
}
