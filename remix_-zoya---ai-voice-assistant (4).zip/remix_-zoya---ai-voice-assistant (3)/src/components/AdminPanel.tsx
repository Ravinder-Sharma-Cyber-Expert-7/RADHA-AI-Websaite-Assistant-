import React, { useEffect, useRef, useState } from "react";
import {
  Brain,
  Camera,
  Check,
  CheckCircle2,
  Download,
  Eye,
  EyeOff,
  Fingerprint,
  Heart,
  Languages,
  Loader2,
  Lock,
  Palette,
  Plus,
  RotateCcw,
  ScanFace,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  Trash2,
  Upload,
  UserCheck,
  X,
} from "lucide-react";
import {
  CompactChatPosition,
  DEFAULT_RADHA_CONFIG,
  EmotionIntensity,
  MemoryItem,
  PreferredLanguage,
  RadhaConfig,
  SystemEventItem,
  UploadedVaultFile,
  VisualizerStyle,
  VoicePersona,
  calibrateOwnerBiometrics,
  uploadFileToSystemVault,
} from "../services/memoryService";

const ADMIN_PASSCODE = "@123hack";

const COLOR_PRESETS = [
  { name: "Hacker Matrix", primary: "#00ff9d", secondary: "#00e5ff", bg: "#020608" },
  { name: "Radha Classic", primary: "#8b5cf6", secondary: "#ec4899", bg: "#050505" },
  { name: "Cyber Neon", primary: "#06b6d4", secondary: "#3b82f6", bg: "#030712" },
  { name: "Royal Crimson", primary: "#ef4444", secondary: "#f59e0b", bg: "#090406" },
  { name: "Sunset Gold", primary: "#f59e0b", secondary: "#ec4899", bg: "#0a0705" },
];

const CALIBRATION_ANGLES = [
  {
    id: "front",
    label: "1/4 · सीधा सामने देखें",
    sub: "Look straight into the camera (Front 3D Baseline)",
  },
  {
    id: "left",
    label: "2/4 · चेहरा हल्का बाएँ घुमाएँ (~25°)",
    sub: "Turn your head gently to the LEFT for 3D depth parallax",
  },
  {
    id: "right",
    label: "3/4 · चेहरा हल्का दाएँ घुमाएँ (~25°)",
    sub: "Turn your head gently to the RIGHT for profile mapping",
  },
  {
    id: "tilt",
    label: "4/4 · हल्का ऊपर देखें और मुस्कुराएं",
    sub: "Tilt slightly up & smile for live anti-spoof verification",
  },
];

interface AdminPanelProps {
  isOpen: boolean;
  onClose: () => void;
  config: RadhaConfig;
  onUpdateConfig: (next: RadhaConfig) => void;
  memories: MemoryItem[];
  messageCount: number;
  onAddMemory: (content: string, category: string) => Promise<void>;
  onDeleteMemory: (id: string) => Promise<void>;
  onClearChatHistory: () => Promise<void>;
  onTestFaceId?: () => void;
  uploadedFiles?: UploadedVaultFile[];
  systemEvents?: SystemEventItem[];
  onVaultFileSynced?: (file: UploadedVaultFile, rawBase64?: string) => void;
  onDeleteVaultFile?: (id: string) => Promise<void>;
  onOwnerPhotoUploaded?: (dataUrl: string) => void;
  onSecurityAlert?: (msg: string) => void;
}

type AdminTab = "owner" | "design" | "emotions" | "system" | "memory";

function compressImageFile(file: File, maxDim: number, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("File read failed"));
    reader.onload = () => {
      const dataUrl = typeof reader.result === "string" ? reader.result : "";
      if (!dataUrl) {
        reject(new Error("Empty image data"));
        return;
      }
      const img = new Image();
      img.onerror = () => resolve(dataUrl);
      img.onload = () => {
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height, 1));
        const targetW = Math.max(1, Math.round(img.width * scale));
        const targetH = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(dataUrl);
          return;
        }
        ctx.drawImage(img, 0, 0, targetW, targetH);
        try {
          resolve(canvas.toDataURL("image/jpeg", quality));
        } catch {
          resolve(dataUrl);
        }
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Compute an 8x8 grayscale luminance vector from a video frame to measure real 3D head-turn parallax delta.
 */
function extractSpatialDescriptor(video: HTMLVideoElement): number[] {
  const mini = document.createElement("canvas");
  mini.width = 8;
  mini.height = 8;
  const ctx = mini.getContext("2d");
  if (!ctx) return new Array(64).fill(0);
  ctx.drawImage(video, 0, 0, 8, 8);
  const data = ctx.getImageData(0, 0, 8, 8).data;
  const vec: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    vec.push(Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]));
  }
  return vec;
}

function computeAverageParallax(vectors: number[][]): number {
  if (vectors.length < 2) return 0;
  let totalDiff = 0;
  let pairs = 0;
  for (let i = 0; i < vectors.length; i++) {
    for (let j = i + 1; j < vectors.length; j++) {
      let sum = 0;
      const len = Math.min(vectors[i].length, vectors[j].length);
      for (let k = 0; k < len; k++) {
        sum += Math.abs(vectors[i][k] - vectors[j][k]);
      }
      totalDiff += sum / Math.max(1, len);
      pairs++;
    }
  }
  return pairs > 0 ? Number((totalDiff / pairs).toFixed(2)) : 0;
}

export default function AdminPanel({
  isOpen,
  onClose,
  config,
  onUpdateConfig,
  memories,
  messageCount,
  onAddMemory,
  onDeleteMemory,
  onClearChatHistory,
  onTestFaceId,
  uploadedFiles = [],
  systemEvents = [],
  onVaultFileSynced,
  onDeleteVaultFile,
  onOwnerPhotoUploaded,
  onSecurityAlert,
}: AdminPanelProps) {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutUntil, setLockoutUntil] = useState(0);
  const [lockoutRemainingSec, setLockoutRemainingSec] = useState(0);
  const [activeTab, setActiveTab] = useState<AdminTab>("owner");
  const [newMemoryText, setNewMemoryText] = useState("");
  const [newMemoryCategory, setNewMemoryCategory] = useState("personal");
  const [savedNotice, setSavedNotice] = useState(false);
  const [importError, setImportError] = useState("");
  const [vaultUploading, setVaultUploading] = useState(false);
  const [vaultMsg, setVaultMsg] = useState("");
  const importInputRef = useRef<HTMLInputElement | null>(null);
  const vaultFileInputRef = useRef<HTMLInputElement | null>(null);

  // Hardened Security Lockout Countdown
  useEffect(() => {
    if (lockoutUntil <= Date.now()) {
      setLockoutRemainingSec(0);
      return;
    }
    const tick = () => {
      const rem = Math.max(0, Math.ceil((lockoutUntil - Date.now()) / 1000));
      setLockoutRemainingSec(rem);
      if (rem === 0) {
        setFailedAttempts(0);
        setErrorMsg("");
      }
    };
    tick();
    const id = window.setInterval(tick, 500);
    return () => window.clearInterval(id);
  }, [lockoutUntil]);

  // Boss Biometric Security: 4-Angle 3D Owner Face Calibration Wizard State
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [calibrationStep, setCalibrationStep] = useState(0);
  const [capturedAngles, setCapturedAngles] = useState<Array<{ angle: string; dataUrl: string }>>([]);
  const [capturedVectors, setCapturedVectors] = useState<number[][]>([]);
  const [isSubmittingCalib, setIsSubmittingCalib] = useState(false);
  const [calibStatusMsg, setCalibStatusMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const calibVideoRef = useRef<HTMLVideoElement | null>(null);
  const calibStreamRef = useRef<MediaStream | null>(null);

  const stopCalibrationCamera = () => {
    if (calibStreamRef.current) {
      calibStreamRef.current.getTracks().forEach((t) => {
        try {
          t.stop();
        } catch {}
      });
      calibStreamRef.current = null;
    }
  };

  useEffect(() => {
    if (!isOpen || !isCalibrating) {
      stopCalibrationCamera();
    }
    return () => {
      stopCalibrationCamera();
    };
  }, [isOpen, isCalibrating]);

  if (!isOpen) return null;

  const triggerSavedNotice = () => {
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 1800);
  };

  const patchConfig = (partial: Partial<RadhaConfig>) => {
    onUpdateConfig({ ...config, ...partial });
    triggerSavedNotice();
  };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutUntil > Date.now()) {
      const rem = Math.ceil((lockoutUntil - Date.now()) / 1000);
      setErrorMsg(`SECURITY LOCKOUT सक्रिय है! कृपया ${rem} सेकंड बाद प्रयास करें।`);
      return;
    }
    if (password === ADMIN_PASSCODE) {
      setIsUnlocked(true);
      setFailedAttempts(0);
      setErrorMsg("");
      setPassword("");
    } else {
      const nextFails = failedAttempts + 1;
      setFailedAttempts(nextFails);
      if (nextFails >= 5) {
        setLockoutUntil(Date.now() + 30000);
        setErrorMsg("5 बार गलत पासवर्ड! सुरक्षा के लिए एडमिन पैनल 30 सेकंड के लिए लॉक किया गया।");
        onSecurityAlert?.("INTRUSION ALERT: 5 failed Admin Panel password attempts blocked (30s lockout).");
      } else {
        setErrorMsg(`गलत पासवर्ड! (${nextFails}/5 प्रयास — 5 गलत प्रयास पर सुरक्षा लॉक लग जाएगा)`);
      }
    }
  };

  const handleLockAndClose = () => {
    stopCalibrationCamera();
    setIsCalibrating(false);
    setPassword("");
    setErrorMsg("");
    onClose();
  };

  const startCalibrationSession = async () => {
    setCalibStatusMsg(null);
    setCapturedAngles([]);
    setCapturedVectors([]);
    setCalibrationStep(0);
    setIsCalibrating(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      calibStreamRef.current = stream;
      setTimeout(() => {
        if (calibVideoRef.current) {
          calibVideoRef.current.srcObject = stream;
          calibVideoRef.current.play().catch(() => {});
        }
      }, 80);
    } catch {
      setIsCalibrating(false);
      setCalibStatusMsg({
        type: "err",
        text: "कैमरा एक्सेस नहीं मिला। कृपया ब्राउज़र में Camera Permission Allow करें।",
      });
    }
  };

  const cancelCalibrationSession = () => {
    stopCalibrationCamera();
    setIsCalibrating(false);
    setCapturedAngles([]);
    setCapturedVectors([]);
    setCalibrationStep(0);
  };

  const captureNextCalibrationAngle = async () => {
    const video = calibVideoRef.current;
    if (!video || video.readyState < 2 || !video.videoWidth) {
      setCalibStatusMsg({ type: "err", text: "कैमरा लोड हो रहा है, 1 सेकंड बाद क्लिक करें।" });
      return;
    }

    const angleDef = CALIBRATION_ANGLES[calibrationStep];
    if (!angleDef) return;

    const canvas = document.createElement("canvas");
    const targetW = 360;
    const targetH = Math.max(220, Math.round(targetW * (video.videoHeight / Math.max(1, video.videoWidth))));
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, targetW, targetH);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.78);
    const descriptor = extractSpatialDescriptor(video);

    const nextFrames = [...capturedAngles, { angle: angleDef.id, dataUrl }];
    const nextVectors = [...capturedVectors, descriptor];
    setCapturedAngles(nextFrames);
    setCapturedVectors(nextVectors);

    if (calibrationStep + 1 < CALIBRATION_ANGLES.length) {
      setCalibrationStep(calibrationStep + 1);
      return;
    }

    // All 4 angles captured -> compute real 3D parallax & call server anti-spoof calibration
    stopCalibrationCamera();
    setIsSubmittingCalib(true);
    setCalibStatusMsg(null);

    try {
      const parallaxDelta = computeAverageParallax(nextVectors);
      const spatialVector = nextVectors
        .map((v) => v.filter((_, idx) => idx % 4 === 0).join(","))
        .join("|");

      const ownerName = config.ownerNickname || config.ownerFullName || config.creatorName || "Ravindra Boss";
      const result = await calibrateOwnerBiometrics({
        angleFrames: nextFrames,
        ownerName,
        parallaxDelta,
        spatialVector,
      });

      if (result.calibrated && result.biometricHash) {
        patchConfig({
          ownerPhotoUrl: config.ownerPhotoUrl || nextFrames[0].dataUrl,
          faceRecognitionEnabled: true,
          biometricProfile: {
            calibrated: true,
            biometricHash: result.biometricHash,
            geometrySignature: result.geometrySignature,
            antiSpoofScore: result.antiSpoofScore,
            parallaxDelta,
            angleSnapshots: nextFrames.map((f) => f.dataUrl),
            calibratedAt: result.calibratedAt,
            requireLivenessCheck: true,
          },
        });
        setCalibStatusMsg({
          type: "ok",
          text:
            result.reason ||
            `3D Biometric Hash लॉक हो गया! (${result.biometricHash}) · Anti-Spoof: ${result.antiSpoofScore}%`,
        });
        setIsCalibrating(false);
      } else {
        setCalibStatusMsg({
          type: "err",
          text:
            result.reason ||
            "स्पूफ या स्थिर फ्रेम मिला — कृपया चारों एंगल में सिर को साफ़ घुमाकर दोबारा कैलिब्रेट करें।",
        });
        setIsCalibrating(false);
      }
    } catch (err: any) {
      setCalibStatusMsg({
        type: "err",
        text: err?.message || "3D Calibration failed. कृपया फिर से प्रयास करें।",
      });
      setIsCalibrating(false);
    } finally {
      setIsSubmittingCalib(false);
    }
  };

  const handleImageUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
    field: "backgroundImageUrl" | "avatarImageUrl" | "ownerPhotoUrl"
  ) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const maxDim = field === "backgroundImageUrl" ? 1280 : 480;
      const quality = field === "backgroundImageUrl" ? 0.78 : 0.84;
      const compressed = await compressImageFile(file, maxDim, quality);
      patchConfig({ [field]: compressed });
      if (field === "ownerPhotoUrl") {
        onOwnerPhotoUploaded?.(compressed);
      }
    } catch {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          patchConfig({ [field]: reader.result });
          if (field === "ownerPhotoUrl") {
            onOwnerPhotoUploaded?.(reader.result);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVaultFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setVaultUploading(true);
    setVaultMsg("फ़ाइल का SHA-256 और AI स्कैन करके राधा के लाइव ब्रेन में भेजा जा रहा है...");
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const dataUrl = String(reader.result || "");
        const base64Data = dataUrl.includes(",") ? dataUrl.split(",")[1] : dataUrl;
        const res = await uploadFileToSystemVault({
          base64Data,
          mimeType: file.type || "text/plain",
          fileName: file.name,
        });
        if (res?.file) {
          onVaultFileSynced?.(res.file, file.type.startsWith("image/") ? base64Data : undefined);
          setVaultMsg(`✓ "${file.name}" राधा के लाइव ब्रेन और सिस्टम वॉल्ट में सेव हो गई!`);
          triggerSavedNotice();
        }
      } catch (err: any) {
        setVaultMsg(err?.message || "Upload failed");
      } finally {
        setVaultUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAddMemorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemoryText.trim()) return;
    await onAddMemory(newMemoryText.trim(), newMemoryCategory);
    setNewMemoryText("");
    triggerSavedNotice();
  };

  const handleExportConfig = () => {
    try {
      const blob = new Blob([JSON.stringify(config, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `radha-admin-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {}
  };

  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setImportError("");
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || "{}"));
        if (!parsed || typeof parsed !== "object") {
          setImportError("Invalid backup JSON file.");
          return;
        }
        onUpdateConfig({ ...DEFAULT_RADHA_CONFIG, ...parsed });
        triggerSavedNotice();
      } catch {
        setImportError("Backup file parse failed. Valid JSON upload karein.");
      }
    };
    reader.readAsText(file);
  };

  const bio = config.biometricProfile;
  const activeCalibAngle = CALIBRATION_ANGLES[calibrationStep] || CALIBRATION_ANGLES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      {!isUnlocked ? (
        /* Admin Lock Screen */
        <div className="w-full max-w-sm bg-[#0d0d14] border border-white/15 rounded-2xl p-6 shadow-2xl">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2.5">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-black"
                style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
              >
                <Lock size={18} />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">Admin Panel Lock</h2>
                <p className="text-xs text-white/50">Ravindra Boss Control Access</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleLockAndClose}
              className="p-1.5 rounded-lg text-white/50 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              title="Close"
            >
              <X size={16} />
            </button>
          </div>

          <form onSubmit={handleUnlock} className="space-y-4">
            <div>
              <label className="block text-xs text-white/65 mb-1.5">
                Admin Password दर्ज करें
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMsg) setErrorMsg("");
                  }}
                  placeholder="Enter admin password..."
                  autoFocus
                  className="w-full bg-white/5 border border-white/15 focus:border-emerald-400 rounded-xl px-3.5 py-2.5 pr-10 text-sm text-white placeholder:text-white/30 outline-none transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/50 hover:text-white cursor-pointer"
                  title={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              {lockoutRemainingSec > 0 && (
                <p className="mt-2 text-xs font-mono text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-lg px-2.5 py-1.5">
                  SECURITY LOCKOUT ACTIVE · Retry in {lockoutRemainingSec}s
                </p>
              )}
              {errorMsg && <p className="mt-2 text-xs text-red-400">{errorMsg}</p>}
            </div>

            <button
              type="submit"
              disabled={lockoutRemainingSec > 0}
              className="w-full py-2.5 rounded-xl font-semibold text-sm text-black transition-opacity hover:opacity-90 disabled:opacity-40 cursor-pointer"
              style={{
                background: `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})`,
              }}
            >
              {lockoutRemainingSec > 0 ? `Locked (${lockoutRemainingSec}s)` : "Unlock Control Center"}
            </button>
          </form>
        </div>
      ) : (
        /* Full Admin Control Center */
        <div className="w-full max-w-4xl max-h-[90dvh] bg-[#0b0b12] border border-white/15 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
          {/* Top Bar */}
          <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-3">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-black"
                style={{
                  background: `linear-gradient(135deg, ${config.primaryColor}, ${config.secondaryColor})`,
                }}
              >
                <Shield size={18} />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">
                  Radha Full Control Center
                </h2>
                <p className="text-xs text-white/50">
                  Boss 3D Biometric Security, Hindi Lock, Emotions, Wake-Word &amp; Memory
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {savedNotice && (
                <span className="flex items-center gap-1 text-xs text-emerald-400 mr-2">
                  <Check size={14} /> Saved
                </span>
              )}
              <button
                type="button"
                onClick={() => {
                  stopCalibrationCamera();
                  setIsCalibrating(false);
                  setIsUnlocked(false);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 hover:bg-white/10 text-white/75 hover:text-white border border-white/10 cursor-pointer"
              >
                Lock
              </button>
              <button
                type="button"
                onClick={handleLockAndClose}
                className="p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/10 cursor-pointer"
                title="Close Admin Panel"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 px-5 pt-3 pb-2 border-b border-white/10 overflow-x-auto shrink-0">
            {[
              { id: "owner" as AdminTab, label: "Boss Biometric & Profile", icon: ScanFace },
              { id: "design" as AdminTab, label: "Look & Design", icon: Palette },
              { id: "emotions" as AdminTab, label: "Voice, Hindi & Emotions", icon: Heart },
              { id: "system" as AdminTab, label: "System & Wake", icon: Sliders },
              { id: "memory" as AdminTab, label: `Memory (${memories.length})`, icon: Brain },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                    isActive
                      ? "bg-white/12 text-white"
                      : "text-white/55 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon size={14} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Tab Body */}
          <div className="flex-1 overflow-y-auto p-5 space-y-6">
            {/* TAB 1: BOSS BIOMETRIC SECURITY + OWNER PROFILE */}
            {activeTab === "owner" && (
              <>
                {/* BOSS BIOMETRIC SECURITY — 3D MULTI-ANGLE FACE CALIBRATION LAYER */}
                <section
                  className="p-4 rounded-2xl border space-y-4"
                  style={{
                    backgroundColor: bio?.calibrated
                      ? "rgba(22, 163, 74, 0.08)"
                      : "rgba(6, 182, 212, 0.06)",
                    borderColor: bio?.calibrated
                      ? "rgba(34, 197, 94, 0.35)"
                      : "rgba(34, 211, 238, 0.28)",
                  }}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <div
                        className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border"
                        style={{
                          backgroundColor: bio?.calibrated
                            ? "rgba(22, 163, 74, 0.2)"
                            : "rgba(6, 182, 212, 0.18)",
                          borderColor: bio?.calibrated
                            ? "rgba(74, 222, 128, 0.45)"
                            : "rgba(34, 211, 238, 0.4)",
                          color: bio?.calibrated ? "#4ade80" : "#22d3ee",
                        }}
                      >
                        {bio?.calibrated ? <ShieldCheck size={18} /> : <Fingerprint size={18} />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="text-sm font-semibold text-white">
                            Boss Biometric Security · 3D Anti-Spoof Face Calibration
                          </h3>
                          <span
                            className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                              bio?.calibrated
                                ? "bg-emerald-500/20 text-emerald-300 border-emerald-400/40"
                                : "bg-amber-500/20 text-amber-200 border-amber-400/40"
                            }`}
                          >
                            {bio?.calibrated ? "3D HASH LOCKED" : "CALIBRATION REQUIRED"}
                          </span>
                        </div>
                        <p className="text-[11px] text-white/60 mt-0.5">
                          चेहरे के 4 अलग-अलग 3D एंगल (सीधा, बाएँ, दाएँ, ऊपर) स्कैन करके एक यूनिक 3D-mapped SHA-256 हैश बनाता है — जिसे कोई फोटो या फ़ोन स्क्रीन दिखाकर स्पूफ नहीं कर सकता।
                        </p>
                      </div>
                    </div>

                    {!isCalibrating && (
                      <button
                        type="button"
                        disabled={isSubmittingCalib}
                        onClick={startCalibrationSession}
                        className="px-3.5 py-2 rounded-xl text-xs font-semibold text-black flex items-center gap-1.5 cursor-pointer shrink-0 disabled:opacity-50"
                        style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
                      >
                        <ScanFace size={14} />
                        <span>
                          {bio?.calibrated
                            ? "Re-Calibrate 3D Face"
                            : "Start Owner Face Calibration"}
                        </span>
                      </button>
                    )}
                  </div>

                  {calibStatusMsg && (
                    <div
                      className={`p-3 rounded-xl text-xs border flex items-start gap-2 ${
                        calibStatusMsg.type === "ok"
                          ? "bg-emerald-500/15 border-emerald-400/35 text-emerald-200"
                          : "bg-red-500/15 border-red-400/35 text-red-200"
                      }`}
                    >
                      {calibStatusMsg.type === "ok" ? (
                        <CheckCircle2 size={15} className="shrink-0 mt-0.5" />
                      ) : (
                        <ShieldAlert size={15} className="shrink-0 mt-0.5" />
                      )}
                      <span>{calibStatusMsg.text}</span>
                    </div>
                  )}

                  {/* Active 4-Angle Guided Webcam Calibration Wizard */}
                  {isCalibrating && (
                    <div className="p-4 rounded-xl bg-black/65 border border-cyan-400/35 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-xs font-semibold text-cyan-300">
                            {activeCalibAngle.label}
                          </div>
                          <div className="text-[11px] text-white/55">{activeCalibAngle.sub}</div>
                        </div>
                        <button
                          type="button"
                          onClick={cancelCalibrationSession}
                          className="px-2.5 py-1 rounded-lg text-[11px] bg-white/10 hover:bg-white/15 text-white/80 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </div>

                      {/* 4-Step Progress Track */}
                      <div className="grid grid-cols-4 gap-2">
                        {CALIBRATION_ANGLES.map((step, idx) => {
                          const done = idx < capturedAngles.length;
                          const current = idx === calibrationStep;
                          return (
                            <div
                              key={step.id}
                              className={`px-2 py-1.5 rounded-lg border text-[10px] font-mono text-center ${
                                done
                                  ? "bg-emerald-500/20 border-emerald-400/50 text-emerald-300"
                                  : current
                                  ? "bg-cyan-500/20 border-cyan-400 text-cyan-200 font-bold"
                                  : "bg-white/5 border-white/10 text-white/40"
                              }`}
                            >
                              {done ? `✓ ${step.id.toUpperCase()}` : step.id.toUpperCase()}
                            </div>
                          );
                        })}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 items-center">
                        <div className="sm:col-span-3 relative rounded-xl overflow-hidden bg-black border border-cyan-400/40 aspect-video">
                          <video
                            ref={calibVideoRef}
                            className="w-full h-full object-cover scale-x-[-1]"
                            muted
                            playsInline
                          />
                          {/* 3D Alignment Reticle Overlay */}
                          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                            <div className="w-36 h-44 rounded-full border-2 border-dashed border-cyan-300/70 shadow-[0_0_24px_rgba(34,211,238,0.3)]" />
                          </div>
                          <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/75 text-[10px] font-mono text-cyan-300">
                            3D MESH ANGLE: {activeCalibAngle.id.toUpperCase()}
                          </div>
                        </div>

                        <div className="sm:col-span-2 space-y-2.5">
                          <div className="grid grid-cols-2 gap-1.5">
                            {CALIBRATION_ANGLES.map((step, idx) => {
                              const snap = capturedAngles[idx];
                              return (
                                <div
                                  key={step.id}
                                  className="aspect-square rounded-lg bg-white/5 border border-white/10 overflow-hidden flex items-center justify-center relative"
                                >
                                  {snap ? (
                                    <img
                                      src={snap.dataUrl}
                                      alt={step.id}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <span className="text-[9.5px] font-mono text-white/35 uppercase">
                                      {step.id}
                                    </span>
                                  )}
                                </div>
                              );
                            })}
                          </div>

                          <button
                            type="button"
                            onClick={captureNextCalibrationAngle}
                            className="w-full py-2.5 px-3 rounded-xl text-xs font-bold text-black flex items-center justify-center gap-1.5 cursor-pointer"
                            style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
                          >
                            <Camera size={14} />
                            <span>
                              Capture Angle {calibrationStep + 1} / {CALIBRATION_ANGLES.length}
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {isSubmittingCalib && (
                    <div className="p-4 rounded-xl bg-black/60 border border-cyan-400/30 flex items-center gap-3 text-xs text-cyan-200 font-mono">
                      <Loader2 size={16} className="animate-spin text-cyan-400 shrink-0" />
                      <span>
                        Computing 3D Facial Geometry &amp; Anti-Spoof SHA-256 Biometric Hash...
                      </span>
                    </div>
                  )}

                  {/* Calibrated 3D Biometric Fingerprint Summary */}
                  {bio?.calibrated && !isCalibrating && (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
                      <div className="md:col-span-2 p-3 rounded-xl bg-black/45 border border-emerald-400/25 space-y-1.5 font-mono">
                        <div className="flex items-center justify-between text-[10.5px]">
                          <span className="text-white/55">3D MAPPED HASH</span>
                          <span className="text-emerald-300 font-bold">{bio.biometricHash}</span>
                        </div>
                        <div className="flex items-center justify-between text-[10.5px]">
                          <span className="text-white/55">ANTI-SPOOF SCORE</span>
                          <span className="text-emerald-300 font-bold">
                            {bio.antiSpoofScore}% · PARALLAX Δ {bio.parallaxDelta}
                          </span>
                        </div>
                        <div className="text-[10.5px] text-white/65 leading-relaxed pt-1 border-t border-white/10 font-sans">
                          {bio.geometrySignature}
                        </div>
                      </div>

                      <div className="flex flex-col justify-between gap-2 p-3 rounded-xl bg-black/45 border border-white/10">
                        <div className="grid grid-cols-4 gap-1">
                          {bio.angleSnapshots.slice(0, 4).map((snap, idx) => (
                            <img
                              key={idx}
                              src={snap}
                              alt={`Angle ${idx + 1}`}
                              className="w-full aspect-square object-cover rounded border border-emerald-400/35"
                            />
                          ))}
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <label className="flex items-center gap-1.5 text-[10.5px] text-white/75 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={bio.requireLivenessCheck !== false}
                              onChange={(e) =>
                                patchConfig({
                                  biometricProfile: {
                                    ...bio,
                                    requireLivenessCheck: e.target.checked,
                                  },
                                })
                              }
                              className="w-3.5 h-3.5 accent-emerald-400 cursor-pointer"
                            />
                            <span>Anti-Spoof Liveness</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => patchConfig({ biometricProfile: undefined })}
                            className="text-[10.5px] text-red-400 hover:underline cursor-pointer"
                          >
                            Clear 3D
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </section>

                <section className="grid grid-cols-1 md:grid-cols-5 gap-5 items-start">
                  {/* Owner Photo Upload & Quick Verification Card */}
                  <div className="md:col-span-2 p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-white flex items-center gap-1.5">
                        <UserCheck size={14} className="text-emerald-400" />
                        Owner Reference Photo
                      </span>
                      {(config.ownerPhotoUrl || bio?.calibrated) && (
                        <span className="text-[10px] font-mono text-emerald-400">
                          {bio?.calibrated ? "3D + PHOTO" : "ENROLLED"}
                        </span>
                      )}
                    </div>

                    <div className="relative w-full aspect-square max-h-52 rounded-xl bg-black/50 border border-white/10 overflow-hidden flex items-center justify-center">
                      {config.ownerPhotoUrl ? (
                        <img
                          src={config.ownerPhotoUrl}
                          alt="Owner Face Reference"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center px-4 space-y-2">
                          <ScanFace size={34} className="mx-auto text-white/30" />
                          <p className="text-[11px] text-white/50 leading-relaxed">
                            ऊपर 3D Face Calibration करें या अपनी फ्रंट फोटो अपलोड करें।
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <label
                        className="flex-1 py-2 px-3 rounded-xl text-xs font-semibold text-black flex items-center justify-center gap-1.5 cursor-pointer"
                        style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
                      >
                        <Upload size={13} />
                        <span>{config.ownerPhotoUrl ? "Change Photo" : "Upload Photo"}</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, "ownerPhotoUrl")}
                          className="hidden"
                        />
                      </label>

                      {config.ownerPhotoUrl && (
                        <button
                          type="button"
                          onClick={() => patchConfig({ ownerPhotoUrl: "" })}
                          className="px-3 py-2 rounded-xl text-xs bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/25 cursor-pointer"
                          title="Remove Owner Photo"
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>

                    {onTestFaceId && (
                      <button
                        type="button"
                        disabled={!config.ownerPhotoUrl && !bio?.calibrated}
                        onClick={() => {
                          stopCalibrationCamera();
                          setIsCalibrating(false);
                          onClose();
                          onTestFaceId();
                        }}
                        className="w-full py-2 px-3 rounded-xl text-xs font-medium bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-200 border border-cyan-400/30 disabled:opacity-40 flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Camera size={14} />
                        <span>Open Camera &amp; Verify 3D Face ID</span>
                      </button>
                    )}

                    <label className="flex items-center justify-between gap-3 pt-1 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Auto Live Face Recognition
                        </div>
                        <div className="text-[10.5px] text-white/50">
                          कैमरा ऑन होते ही बॉस का चेहरा वेरिफाई करके हिंदी में ग्रीट करे
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.faceRecognitionEnabled !== false}
                        onChange={(e) =>
                          patchConfig({ faceRecognitionEnabled: e.target.checked })
                        }
                        className="w-4 h-4 accent-emerald-400 cursor-pointer shrink-0"
                      />
                    </label>
                  </div>

                  {/* Owner Personal Details Form */}
                  <div className="md:col-span-3 space-y-3.5">
                    <div>
                      <h3 className="text-sm font-semibold text-white">
                        Owner Personal Profile (राधा को हमेशा याद रहेगा)
                      </h3>
                      <p className="text-[11px] text-white/50 mt-0.5">
                        यहाँ जो भी जानकारी भरेंगे, राधा हर चैट और लाइव वॉइस कॉल में उसे खुद याद रखेगी।
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs text-white/70 mb-1">
                          Owner Full Name
                        </label>
                        <input
                          type="text"
                          value={config.ownerFullName || ""}
                          onChange={(e) => patchConfig({ ownerFullName: e.target.value })}
                          placeholder="Ravindra Sharma"
                          className="w-full bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-400"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-white/70 mb-1">
                          Nickname (राधा क्या कहकर बुलाए)
                        </label>
                        <input
                          type="text"
                          value={config.ownerNickname || ""}
                          onChange={(e) => patchConfig({ ownerNickname: e.target.value })}
                          placeholder="Ravindra Boss"
                          className="w-full bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-400"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-white/70 mb-1">
                          Role / Profession
                        </label>
                        <input
                          type="text"
                          value={config.ownerRole || ""}
                          onChange={(e) => patchConfig({ ownerRole: e.target.value })}
                          placeholder="Cyber Expert & Hardware Developer"
                          className="w-full bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-400"
                        />
                      </div>

                      <div>
                        <label className="block text-xs text-white/70 mb-1">
                          City / Location
                        </label>
                        <input
                          type="text"
                          value={config.ownerCity || ""}
                          onChange={(e) => patchConfig({ ownerCity: e.target.value })}
                          placeholder="India"
                          className="w-full bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-white/70 mb-1">
                        Owner Bio, Hardware Projects, Likes &amp; Personal Details
                      </label>
                      <textarea
                        rows={5}
                        value={config.ownerBio || ""}
                        onChange={(e) => patchConfig({ ownerBio: e.target.value })}
                        placeholder="जैसे: मेरा जन्मदिन, मेरे हार्डवेयर प्रोजेक्ट्स, पसंद-नापसंद, या कोई भी खास बात जो राधा को हमेशा पता होनी चाहिए..."
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-white/30 outline-none focus:border-emerald-400 leading-relaxed"
                      />
                    </div>
                  </div>
                </section>
              </>
            )}

            {/* TAB 2: LOOK & DESIGN */}
            {activeTab === "design" && (
              <>
                <section className="space-y-3">
                  <h3 className="text-sm font-semibold text-white">Theme Color Presets</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {COLOR_PRESETS.map((preset) => (
                      <button
                        key={preset.name}
                        type="button"
                        onClick={() =>
                          patchConfig({
                            primaryColor: preset.primary,
                            secondaryColor: preset.secondary,
                            backgroundColor: preset.bg,
                          })
                        }
                        className="flex flex-col items-start gap-2 p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-1.5">
                          <span
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: preset.primary }}
                          />
                          <span
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: preset.secondary }}
                          />
                        </div>
                        <span className="text-[11px] font-medium text-white/85">
                          {preset.name}
                        </span>
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                    <label className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5">
                      <span className="text-xs text-white/80">Primary Color</span>
                      <input
                        type="color"
                        value={config.primaryColor}
                        onChange={(e) => patchConfig({ primaryColor: e.target.value })}
                        className="w-8 h-7 rounded cursor-pointer bg-transparent border-0"
                      />
                    </label>
                    <label className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5">
                      <span className="text-xs text-white/80">Secondary Color</span>
                      <input
                        type="color"
                        value={config.secondaryColor}
                        onChange={(e) => patchConfig({ secondaryColor: e.target.value })}
                        className="w-8 h-7 rounded cursor-pointer bg-transparent border-0"
                      />
                    </label>
                    <label className="flex items-center justify-between bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5">
                      <span className="text-xs text-white/80">Background</span>
                      <input
                        type="color"
                        value={config.backgroundColor}
                        onChange={(e) => patchConfig({ backgroundColor: e.target.value })}
                        className="w-8 h-7 rounded cursor-pointer bg-transparent border-0"
                      />
                    </label>
                  </div>
                </section>

                <section className="space-y-3 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Visualizer Style &amp; 3D Synaptic Field
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {(
                      [
                        { id: "hud", label: "HUD Rings" },
                        { id: "orb", label: "Energy Orb" },
                        { id: "neon", label: "Neon Dual" },
                        { id: "minimal", label: "Minimal Halo" },
                      ] as { id: VisualizerStyle; label: string }[]
                    ).map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => patchConfig({ visualizerStyle: st.id })}
                        className={`px-3 py-2.5 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
                          config.visualizerStyle === st.id
                            ? "bg-white/15 border-white/40 text-white"
                            : "bg-white/5 border-white/10 text-white/65 hover:text-white"
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-white/75">
                        <span>Visualizer Size</span>
                        <span className="font-mono">{Math.round(config.visualizerScale * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0.7}
                        max={1.3}
                        step={0.05}
                        value={config.visualizerScale}
                        onChange={(e) =>
                          patchConfig({ visualizerScale: parseFloat(e.target.value) })
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-white/75">
                        <span>Animation Speed</span>
                        <span className="font-mono">{config.animationSpeed.toFixed(1)}x</span>
                      </div>
                      <input
                        type="range"
                        min={0.5}
                        max={2.2}
                        step={0.1}
                        value={config.animationSpeed}
                        onChange={(e) =>
                          patchConfig({ animationSpeed: parseFloat(e.target.value) })
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs text-white/75">
                        <span>Glow Intensity</span>
                        <span className="font-mono">{Math.round(config.glowIntensity * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min={0.2}
                        max={1.5}
                        step={0.05}
                        value={config.glowIntensity}
                        onChange={(e) =>
                          patchConfig({ glowIntensity: parseFloat(e.target.value) })
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />
                    </div>
                  </div>

                  <label className="flex items-center justify-between gap-3 p-3 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                    <div>
                      <div className="text-xs font-medium text-white">
                        3D Synaptic Neural Field (Signature Background)
                      </div>
                      <div className="text-[11px] text-white/50">
                        इमोशन और आवाज़ के साथ चलने वाला 3D न्यूरल कॉन्स्टलेशन
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.neuralFieldEnabled !== false}
                      onChange={(e) =>
                        patchConfig({ neuralFieldEnabled: e.target.checked })
                      }
                      className="w-4 h-4 accent-emerald-400 cursor-pointer"
                    />
                  </label>
                </section>

                <section className="space-y-3 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Custom Banner / Wallpaper &amp; Radha Avatar
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs text-white/70 block">
                        Background Banner / Image URL
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={config.backgroundImageUrl}
                          onChange={(e) =>
                            patchConfig({ backgroundImageUrl: e.target.value })
                          }
                          placeholder="Paste image URL or upload..."
                          className="flex-1 min-w-0 bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white placeholder:text-white/30 outline-none"
                        />
                        <label className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white flex items-center gap-1.5 cursor-pointer shrink-0">
                          <Upload size={13} />
                          <span>Upload</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(e, "backgroundImageUrl")}
                            className="hidden"
                          />
                        </label>
                      </div>
                      {config.backgroundImageUrl && (
                        <div className="flex items-center justify-between gap-3 pt-1">
                          <div className="flex-1 space-y-1">
                            <div className="flex justify-between text-[11px] text-white/60">
                              <span>Overlay Darkness</span>
                              <span>{Math.round(config.backgroundOverlayOpacity * 100)}%</span>
                            </div>
                            <input
                              type="range"
                              min={0.15}
                              max={0.9}
                              step={0.05}
                              value={config.backgroundOverlayOpacity}
                              onChange={(e) =>
                                patchConfig({
                                  backgroundOverlayOpacity: parseFloat(e.target.value),
                                })
                              }
                              className="w-full accent-emerald-400 cursor-pointer"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={() => patchConfig({ backgroundImageUrl: "" })}
                            className="text-xs text-red-400 hover:underline cursor-pointer"
                          >
                            Remove
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs text-white/70 block">
                        Radha Custom Avatar / Anime Icon
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={config.avatarImageUrl}
                          onChange={(e) => patchConfig({ avatarImageUrl: e.target.value })}
                          placeholder="Paste avatar URL or upload..."
                          className="flex-1 min-w-0 bg-white/5 border border-white/15 rounded-xl px-3 py-2 text-xs text-white placeholder:text-white/30 outline-none"
                        />
                        <label className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white flex items-center gap-1.5 cursor-pointer shrink-0">
                          <Upload size={13} />
                          <span>Upload</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(e, "avatarImageUrl")}
                            className="hidden"
                          />
                        </label>
                      </div>
                      {config.avatarImageUrl && (
                        <button
                          type="button"
                          onClick={() => patchConfig({ avatarImageUrl: "" })}
                          className="text-xs text-red-400 hover:underline cursor-pointer"
                        >
                          Remove Custom Avatar
                        </button>
                      )}
                    </div>
                  </div>
                </section>

                <section className="space-y-3 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Compact Side Chat &amp; Real Telemetry Layout
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      {(["left", "right", "hidden"] as CompactChatPosition[]).map((pos) => (
                        <button
                          key={pos}
                          type="button"
                          onClick={() => patchConfig({ compactChatPosition: pos })}
                          className={`flex-1 py-2 rounded-xl text-xs font-medium capitalize border cursor-pointer ${
                            config.compactChatPosition === pos
                              ? "bg-white/15 border-white/40 text-white"
                              : "bg-white/5 border-white/10 text-white/60 hover:text-white"
                          }`}
                        >
                          {pos}
                        </button>
                      ))}
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-white/75">
                        <span>Side Chat Width</span>
                        <span className="font-mono">{config.compactChatWidth}px</span>
                      </div>
                      <input
                        type="range"
                        min={240}
                        max={400}
                        step={10}
                        value={config.compactChatWidth}
                        onChange={(e) =>
                          patchConfig({ compactChatWidth: parseInt(e.target.value, 10) })
                        }
                        className="w-full accent-emerald-400 cursor-pointer"
                      />
                    </div>
                  </div>

                  <label className="flex items-center justify-between gap-4 p-3 rounded-xl bg-white/5 border border-white/10 cursor-pointer mt-2">
                    <div>
                      <div className="text-xs font-medium text-white">
                        Show Real Network, Boss Health &amp; Telemetry Panel
                      </div>
                      <div className="text-[11px] text-white/50">
                        एक तरफ Boss Health बार, Real Speed (Mbps), Ping, CPU और RAM दिखाएँ
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={config.showTelemetryPanel !== false}
                      onChange={(e) =>
                        patchConfig({ showTelemetryPanel: e.target.checked })
                      }
                      className="w-4 h-4 accent-emerald-400 cursor-pointer"
                    />
                  </label>
                </section>
              </>
            )}

            {/* TAB 3: VOICE, HINDI LANGUAGE LOCK & EMOTIONS */}
            {activeTab === "emotions" && (
              <>
                <section className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Languages size={15} className="text-emerald-400" />
                    <h3 className="text-sm font-semibold text-white">
                      Language Lock (राधा की भाषा लॉक)
                    </h3>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    {(
                      [
                        {
                          id: "hi-IN",
                          label: "Strict Hindi (Recommended)",
                          sub: "हमेशा हिंदी — जब तक बॉस न कहें",
                        },
                        {
                          id: "auto",
                          label: "Hindi + Auto Match",
                          sub: "डिफ़ॉल्ट हिंदी, यूज़र की भाषा मैच करे",
                        },
                        {
                          id: "en-IN",
                          label: "Indian English",
                          sub: "साफ़ अंग्रेज़ी में बात करे",
                        },
                      ] as { id: PreferredLanguage; label: string; sub: string }[]
                    ).map((lang) => (
                      <button
                        key={lang.id}
                        type="button"
                        onClick={() => patchConfig({ preferredLanguage: lang.id })}
                        className={`p-3 rounded-xl text-left border transition-colors cursor-pointer ${
                          (config.preferredLanguage || "hi-IN") === lang.id
                            ? "bg-emerald-500/15 border-emerald-400/50 text-white"
                            : "bg-white/5 border-white/10 text-white/65 hover:text-white"
                        }`}
                      >
                        <div className="text-xs font-semibold">{lang.label}</div>
                        <div className="text-[10.5px] text-white/50 mt-0.5">{lang.sub}</div>
                      </button>
                    ))}
                  </div>
                </section>

                <section className="space-y-4 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">Voice Persona &amp; Pitch</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {(["Kore", "Zephyr", "Puck", "Charon", "Fenrir"] as VoicePersona[]).map(
                      (voice) => (
                        <button
                          key={voice}
                          type="button"
                          onClick={() => patchConfig({ voiceName: voice })}
                          className={`py-2.5 px-3 rounded-xl text-xs font-medium border cursor-pointer ${
                            config.voiceName === voice
                              ? "bg-white/15 border-white/40 text-white"
                              : "bg-white/5 border-white/10 text-white/65 hover:text-white"
                          }`}
                        >
                          {voice}
                        </button>
                      )
                    )}
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-2">
                    <div className="flex justify-between text-xs text-white/80">
                      <span>Voice Pitch (आवाज़ की पिच)</span>
                      <span className="font-mono">
                        {(config.voicePitch ?? 1.0).toFixed(2)}x
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.75}
                      max={1.35}
                      step={0.05}
                      value={config.voicePitch ?? 1.0}
                      onChange={(e) =>
                        patchConfig({ voicePitch: parseFloat(e.target.value) })
                      }
                      className="w-full accent-emerald-400 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-white/45">
                      <span>Deep (0.75x)</span>
                      <span>Natural (1.00x)</span>
                      <span>Sweet / High (1.35x)</span>
                    </div>
                  </div>
                </section>

                <section className="space-y-3 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Human Emotion Depth
                  </h3>
                  <div className="grid grid-cols-3 gap-2">
                    {(
                      [
                        { id: "normal", label: "Balanced" },
                        { id: "high", label: "Expressive" },
                        { id: "ultra", label: "Ultra Real-Human" },
                      ] as { id: EmotionIntensity; label: string }[]
                    ).map((lvl) => (
                      <button
                        key={lvl.id}
                        type="button"
                        onClick={() => patchConfig({ emotionIntensity: lvl.id })}
                        className={`py-2.5 px-3 rounded-xl text-xs font-medium border cursor-pointer ${
                          config.emotionIntensity === lvl.id
                            ? "bg-white/15 border-white/40 text-white"
                            : "bg-white/5 border-white/10 text-white/65 hover:text-white"
                        }`}
                      >
                        {lvl.label}
                      </button>
                    ))}
                  </div>

                  <div className="space-y-3 pt-2">
                    <label className="flex items-center justify-between gap-4 p-3.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Scold → Instant Real Anger / Narazgi
                        </div>
                        <div className="text-[11px] text-white/50">
                          अगर बॉस डांटें तो राधा असली इंसान की तरह गुस्सा/नाराज़ हो जाए
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.scoldAngerReaction}
                        onChange={(e) =>
                          patchConfig({ scoldAngerReaction: e.target.checked })
                        }
                        className="w-4 h-4 accent-emerald-400 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between gap-4 p-3.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Voice Tone Detection (Laugh, Cry, Anger, Excitement)
                        </div>
                        <div className="text-[11px] text-white/50">
                          हंसने, रोने, गुस्से और मस्ती की आवाज़ को तुरंत पहचानकर रिएक्ट करे
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.detectLaughAndCry}
                        onChange={(e) =>
                          patchConfig({ detectLaughAndCry: e.target.checked })
                        }
                        className="w-4 h-4 accent-emerald-400 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between gap-4 p-3.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Show Live Mood Label on Visualizer
                        </div>
                        <div className="text-[11px] text-white/50">
                          राधा का मौजूदा मूड (खुश / गुस्सा / फ़िक्रमंद) स्क्रीन पर दिखे
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.showEmotionBadge}
                        onChange={(e) =>
                          patchConfig({ showEmotionBadge: e.target.checked })
                        }
                        className="w-4 h-4 accent-emerald-400 cursor-pointer"
                      />
                    </label>

                    <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 space-y-3">
                      <label className="flex items-center justify-between cursor-pointer">
                        <div>
                          <div className="text-xs font-medium text-white">
                            Auto Gentle Check-in on Silence
                          </div>
                          <div className="text-[11px] text-white/50">
                            काफ़ी देर चुप रहने पर राधा खुद प्यार से हालचाल पूछे
                          </div>
                        </div>
                        <input
                          type="checkbox"
                          checked={config.inactivityCheckinEnabled}
                          onChange={(e) =>
                            patchConfig({ inactivityCheckinEnabled: e.target.checked })
                          }
                          className="w-4 h-4 accent-emerald-400 cursor-pointer"
                        />
                      </label>
                      {config.inactivityCheckinEnabled && (
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs text-white/70">
                            <span>Wait Time</span>
                            <span className="font-mono">{config.inactivitySeconds}s</span>
                          </div>
                          <input
                            type="range"
                            min={30}
                            max={180}
                            step={15}
                            value={config.inactivitySeconds}
                            onChange={(e) =>
                              patchConfig({
                                inactivitySeconds: parseInt(e.target.value, 10),
                              })
                            }
                            className="w-full accent-emerald-400 cursor-pointer"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </section>
              </>
            )}

            {/* TAB 4: SYSTEM, WAKE-WORD & BRAIN */}
            {activeTab === "system" && (
              <div className="space-y-6">
                <section className="space-y-3">
                  <h3 className="text-sm font-semibold text-white">
                    Wake-Word, Auto-Sleep &amp; Anti-Drop Engine
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-white/70 mb-1.5">
                        Primary Wake-Word (डिफ़ॉल्ट: राधा)
                      </label>
                      <input
                        type="text"
                        value={config.wakeWordText || "राधा"}
                        onChange={(e) => patchConfig({ wakeWordText: e.target.value })}
                        placeholder="राधा"
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-emerald-400"
                      />
                    </div>
                    <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 text-[11px] text-white/60 leading-relaxed flex items-center">
                      बोलने पर: &ldquo;राधा&rdquo; → पूरा वॉइस सिस्टम चालू।
                      <br />
                      बोलने पर: &ldquo;राधा, बाद में बात करते हैं, बाय&rdquo; → रिप्लाई देकर खुद बंद!
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Auto-Sleep on Farewell (&ldquo;बाय / बाद में बात&rdquo;)
                        </div>
                        <div className="text-[11px] text-white/50">
                          बाय बोलते ही राधा जवाब देकर खुद वॉइस लिंक बंद कर दे
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.autoSleepOnBye !== false}
                        onChange={(e) => patchConfig({ autoSleepOnBye: e.target.checked })}
                        className="w-4 h-4 accent-emerald-400 cursor-pointer"
                      />
                    </label>

                    <label className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer">
                      <div>
                        <div className="text-xs font-medium text-white">
                          Anti-Drop Auto-Reconnect Voice
                        </div>
                        <div className="text-[11px] text-white/50">
                          बात करते-करते नेटवर्क झटके पर अपने आप रीकनेक्ट हो जाए
                        </div>
                      </div>
                      <input
                        type="checkbox"
                        checked={config.autoReconnectVoice !== false}
                        onChange={(e) =>
                          patchConfig({ autoReconnectVoice: e.target.checked })
                        }
                        className="w-4 h-4 accent-emerald-400 cursor-pointer"
                      />
                    </label>
                  </div>
                </section>

                <section className="space-y-4 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Identity, Origin &amp; Custom Brain Rules
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-white/70 mb-1.5">
                        Assistant Name
                      </label>
                      <input
                        type="text"
                        value={config.assistantName}
                        onChange={(e) => patchConfig({ assistantName: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-emerald-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/70 mb-1.5">
                        Creator / Master Name
                      </label>
                      <input
                        type="text"
                        value={config.creatorName}
                        onChange={(e) => patchConfig({ creatorName: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-emerald-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/70 mb-1.5">
                        Development / Creation Date
                      </label>
                      <input
                        type="text"
                        value={config.creationDate}
                        onChange={(e) => patchConfig({ creationDate: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-emerald-400"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/70 mb-1.5">
                        Day on Creation Date
                      </label>
                      <input
                        type="text"
                        value={config.creationDay}
                        onChange={(e) => patchConfig({ creationDay: e.target.value })}
                        className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white outline-none focus:border-emerald-400"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-white/70 mb-1.5">
                      Extra Custom Rules / Personality Instructions
                    </label>
                    <textarea
                      rows={4}
                      value={config.extraInstructions}
                      onChange={(e) => patchConfig({ extraInstructions: e.target.value })}
                      placeholder="यहाँ आप राधा के लिए कोई भी नए नियम या आदतें लिख सकते हैं..."
                      className="w-full bg-white/5 border border-white/15 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-white/30 outline-none focus:border-emerald-400 leading-relaxed"
                    />
                  </div>
                </section>

                <section className="space-y-3 border-t border-white/10 pt-5">
                  <h3 className="text-sm font-semibold text-white">
                    Configuration Backup &amp; Restore
                  </h3>
                  <div className="flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={handleExportConfig}
                      className="px-3.5 py-2 rounded-xl text-xs font-medium bg-white/10 hover:bg-white/15 text-white border border-white/15 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Download size={13} />
                      <span>Export Admin JSON</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => importInputRef.current?.click()}
                      className="px-3.5 py-2 rounded-xl text-xs font-medium bg-white/10 hover:bg-white/15 text-white border border-white/15 flex items-center gap-1.5 cursor-pointer"
                    >
                      <Upload size={13} />
                      <span>Import Admin JSON</span>
                    </button>
                    <input
                      ref={importInputRef}
                      type="file"
                      accept="application/json"
                      onChange={handleImportConfig}
                      className="hidden"
                    />
                  </div>
                  {importError && <p className="text-xs text-red-400">{importError}</p>}
                </section>
              </div>
            )}

            {/* TAB 5: MEMORY SYSTEM */}
            {activeTab === "memory" && (
              <section className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-xl bg-white/5 border border-white/10">
                  <div className="text-xs text-white/80">
                    Saved Long-Term Memories:{" "}
                    <span className="font-mono font-semibold text-white">
                      {memories.length}
                    </span>
                    <span className="mx-2 text-white/30">·</span>
                    Saved Chat Messages:{" "}
                    <span className="font-mono font-semibold text-white">
                      {messageCount}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={onClearChatHistory}
                    className="px-3 py-1.5 rounded-lg text-xs text-red-300 bg-red-500/15 hover:bg-red-500/25 border border-red-500/25 cursor-pointer"
                  >
                    Clear Chat Transcript Only
                  </button>
                </div>

                <form onSubmit={handleAddMemorySubmit} className="flex flex-col sm:flex-row gap-2">
                  <select
                    value={newMemoryCategory}
                    onChange={(e) => setNewMemoryCategory(e.target.value)}
                    className="bg-[#14141f] border border-white/15 rounded-xl px-3 py-2 text-xs text-white outline-none"
                  >
                    <option value="personal">Personal</option>
                    <option value="work">Work / Task</option>
                    <option value="preference">Preference</option>
                    <option value="emotion">Emotional</option>
                  </select>
                  <input
                    type="text"
                    value={newMemoryText}
                    onChange={(e) => setNewMemoryText(e.target.value)}
                    placeholder="राधा को हमेशा के लिए कुछ याद करवाएँ..."
                    className="flex-1 bg-white/5 border border-white/15 rounded-xl px-3.5 py-2 text-xs text-white placeholder:text-white/35 outline-none focus:border-emerald-400"
                  />
                  <button
                    type="submit"
                    disabled={!newMemoryText.trim()}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-black flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
                    style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
                  >
                    <Plus size={14} />
                    <span>Add Memory</span>
                  </button>
                </form>

                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                  {memories.length === 0 ? (
                    <p className="text-xs text-white/45 py-4 text-center">
                      अभी कोई अलग से मेमोरी सेव नहीं है। जैसे-जैसे आप राधा से बात करेंगे, वह ज़रूरी बातें और काम खुद ही परमानेंट मेमोरी में सेव कर लेगी।
                    </p>
                  ) : (
                    memories.map((mem) => (
                      <div
                        key={mem.id}
                        className="flex items-start justify-between gap-3 p-3 rounded-xl bg-white/[0.04] border border-white/10"
                      >
                        <div className="min-w-0">
                          <div className="text-[11px] text-white/45 mb-0.5">
                            {mem.category} ·{" "}
                            {new Date(mem.createdAt).toLocaleDateString()}
                          </div>
                          <p className="text-xs text-white/90 break-words">{mem.content}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onDeleteMemory(mem.id)}
                          className="p-1.5 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer shrink-0"
                          title="Delete Memory"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {/* Live System File Vault (Synced Immediately to Radha Live Voice Call & Chat) */}
                <div className="border-t border-white/10 pt-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-semibold text-white flex items-center gap-1.5">
                        <ShieldCheck size={14} className="text-emerald-400" />
                        <span>Radha Live System File Vault ({uploadedFiles.length})</span>
                      </h4>
                      <p className="text-[11px] text-white/50">
                        यहाँ अपलोड की गई हर फ़ाइल/फ़ोटो का SHA-256 हैश व AI विश्लेषण सीधे राधा की लाइव कॉल और चैट में पहुँच जाता है।
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={vaultUploading}
                      onClick={() => vaultFileInputRef.current?.click()}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold text-black flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                      style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
                    >
                      {vaultUploading ? <Loader2 size={13} className="animate-spin" /> : <Upload size={13} />}
                      <span>{vaultUploading ? "Syncing..." : "Upload File to Radha"}</span>
                    </button>
                    <input
                      ref={vaultFileInputRef}
                      type="file"
                      accept="image/*,application/pdf,text/*,.json,.js,.ts,.tsx,.py,.c,.cpp,.ino,.md,.csv"
                      onChange={handleVaultFileUpload}
                      className="hidden"
                    />
                  </div>
                  {vaultMsg && (
                    <p className="text-[11px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/25 rounded-lg px-3 py-1.5">
                      {vaultMsg}
                    </p>
                  )}
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {uploadedFiles.length === 0 ? (
                      <p className="text-xs text-white/40 py-2 text-center">
                        कोई फ़ाइल अपलोड नहीं है — ऊपर &quot;Upload File to Radha&quot; दबाकर कोई भी फ़ोटो/कोड/डॉक्यूमेंट भेजें।
                      </p>
                    ) : (
                      uploadedFiles.map((f) => (
                        <div
                          key={f.id}
                          className="flex items-start justify-between gap-2.5 p-2.5 rounded-xl bg-white/[0.04] border border-white/10"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-medium text-white truncate">
                              {f.name}{" "}
                              <span className="text-[10px] font-mono text-emerald-400/80">
                                · SHA256:{(f.sha256 || "").slice(0, 10)}
                              </span>
                            </div>
                            <p className="text-[11px] text-white/65 line-clamp-2 mt-0.5">
                              {f.summary}
                            </p>
                          </div>
                          {onDeleteVaultFile && (
                            <button
                              type="button"
                              onClick={() => onDeleteVaultFile(f.id)}
                              className="p-1.5 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-500/10 cursor-pointer shrink-0"
                              title="Remove file"
                            >
                              <Trash2 size={13} />
                            </button>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Live System Audit Log */}
                {systemEvents.length > 0 && (
                  <div className="border-t border-white/10 pt-4 space-y-2">
                    <h4 className="text-xs font-semibold text-white/85 flex items-center gap-1.5">
                      <Shield size={13} className="text-cyan-400" />
                      <span>System Awareness Audit Trail ({systemEvents.length})</span>
                    </h4>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                      {systemEvents.slice(0, 12).map((evt) => (
                        <div
                          key={evt.id}
                          className="text-[11px] font-mono text-white/65 bg-black/35 border border-white/10 rounded-lg px-2.5 py-1.5"
                        >
                          <span className="text-cyan-300">[{evt.category.toUpperCase()}]</span>{" "}
                          {evt.summary}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </section>
            )}
          </div>

          {/* Footer Bar */}
          <div className="flex items-center justify-between px-5 py-3.5 border-t border-white/10 bg-black/30 shrink-0">
            <button
              type="button"
              onClick={() => {
                onUpdateConfig({ ...DEFAULT_RADHA_CONFIG });
                triggerSavedNotice();
              }}
              className="flex items-center gap-1.5 text-xs text-white/60 hover:text-white transition-colors cursor-pointer"
            >
              <RotateCcw size={13} />
              <span>Reset All to Defaults</span>
            </button>

            <button
              type="button"
              onClick={handleLockAndClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-black cursor-pointer"
              style={{ backgroundColor: config.primaryColor || "#00ff9d" }}
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
