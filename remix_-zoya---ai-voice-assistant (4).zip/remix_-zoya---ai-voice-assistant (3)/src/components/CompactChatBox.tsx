import React, { useEffect, useRef, useState } from "react";
import { ChevronDown, ChevronUp, Send, Terminal } from "lucide-react";
import {
  ChatMessage,
  EMOTION_META,
  RadhaConfig,
  RadhaEmotion,
} from "../services/memoryService";

interface CompactChatBoxProps {
  messages: ChatMessage[];
  config: RadhaConfig;
  emotion: RadhaEmotion;
  appState: "idle" | "listening" | "processing" | "speaking";
  memoryCount: number;
  onSendQuickMessage: (text: string) => void;
  onOpenFullPanel: () => void;
}

export default function CompactChatBox({
  messages,
  config,
  emotion,
  appState,
  memoryCount,
  onSendQuickMessage,
  onOpenFullPanel,
}: CompactChatBoxProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [quickText, setQuickText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, appState, isCollapsed]);

  if (config.compactChatPosition === "hidden") {
    return null;
  }

  const isLeft = config.compactChatPosition === "left";
  const emotionMeta = EMOTION_META[emotion] || EMOTION_META.neutral;
  const recentSlice = messages.slice(-40);
  const widthPx = Math.max(240, Math.min(420, config.compactChatWidth || 300));
  const primary = config.primaryColor || "#00ff9d";
  const secondary = config.secondaryColor || "#00e5ff";

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickText.trim()) return;
    onSendQuickMessage(quickText.trim());
    setQuickText("");
  };

  return (
    <aside
      style={{ width: isCollapsed ? undefined : `${widthPx}px` }}
      className={`fixed z-20 pointer-events-auto transition-all duration-300 ${
        isLeft ? "left-3 sm:left-5" : "right-3 sm:right-5"
      } bottom-24 sm:top-20 sm:bottom-24 flex flex-col justify-end sm:justify-center max-w-[calc(100vw-24px)]`}
    >
      <div
        className={`flex flex-col bg-[#03090c]/85 backdrop-blur-xl border rounded-xl shadow-2xl overflow-hidden transition-all duration-300 ${
          isCollapsed ? "h-auto" : "max-h-[40vh] sm:max-h-[70vh] h-full"
        }`}
        style={{
          borderColor: `${primary}35`,
          boxShadow: `0 0 28px ${primary}14`,
        }}
      >
        {/* Terminal Header Bar */}
        <div
          className="flex items-center justify-between gap-2 px-3 py-2 border-b shrink-0 font-mono"
          style={{ borderColor: `${primary}25`, backgroundColor: `${primary}0d` }}
        >
          <button
            type="button"
            onClick={onOpenFullPanel}
            className="flex items-center gap-2 text-left min-w-0 group cursor-pointer"
            title="Open Full Chat & Smart Command Hub"
          >
            <Terminal size={13} style={{ color: primary }} className="shrink-0" />
            <span
              className="text-[11px] font-bold uppercase tracking-wider truncate"
              style={{ color: primary }}
            >
              COMMS // LOG
            </span>
            <span className="text-[10px] text-white/50 truncate">
              · {emotionMeta.hindiLabel} · {memoryCount} MEM
            </span>
          </button>

          <button
            type="button"
            onClick={() => setIsCollapsed((prev) => !prev)}
            className="p-1 rounded text-white/50 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
            title={isCollapsed ? "Expand Chat" : "Minimize Chat"}
          >
            {isCollapsed ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
          </button>
        </div>

        {/* Compact Line-by-Line Conversation Feed */}
        {!isCollapsed && (
          <>
            <div className="flex-1 overflow-y-auto px-3 py-2.5 space-y-1.5 text-[12px] leading-snug scrollbar-thin">
              {recentSlice.length === 0 ? (
                <p className="text-white/45 text-[11px] leading-relaxed py-3 font-mono">
                  &gt; यहाँ आपकी और {config.assistantName || "Radha"} की सारी बातचीत छोटी लाइन में दिखेगी।
                </p>
              ) : (
                recentSlice.map((msg) => {
                  const isUser = msg.sender === "user";
                  return (
                    <div
                      key={msg.id}
                      className="text-[12px] leading-snug break-words border-b border-white/[0.05] pb-1.5 last:border-b-0"
                    >
                      <span
                        className="font-mono font-bold text-[11px] mr-1.5"
                        style={{
                          color: isUser ? primary : secondary,
                        }}
                      >
                        {isUser ? "BOSS>" : `${(config.assistantName || "RADHA").toUpperCase()}>`}
                      </span>
                      <span className={isUser ? "text-white/85" : "text-white/95"}>
                        {msg.text}
                      </span>
                    </div>
                  );
                })
              )}

              {appState === "processing" && (
                <div className="text-[11px] font-mono italic pt-0.5" style={{ color: secondary }}>
                  &gt; {config.assistantName || "Radha"} processing...
                </div>
              )}
              <div ref={endRef} />
            </div>

            {/* Inline Quick Message Input */}
            <form
              onSubmit={handleSubmit}
              className="flex items-center gap-1.5 px-2.5 py-2 border-t border-white/10 bg-black/45 shrink-0"
            >
              <span className="font-mono text-xs" style={{ color: primary }}>
                $
              </span>
              <input
                type="text"
                value={quickText}
                onChange={(e) => setQuickText(e.target.value)}
                placeholder={`${config.assistantName || "Radha"} से कुछ कहें...`}
                className="flex-1 min-w-0 bg-transparent text-xs text-white placeholder:text-white/35 outline-none font-mono"
              />
              <button
                type="submit"
                disabled={!quickText.trim() || appState === "processing"}
                className="p-1.5 rounded-lg text-black disabled:opacity-30 transition-colors cursor-pointer shrink-0"
                style={{ backgroundColor: primary }}
                title="Send"
              >
                <Send size={12} />
              </button>
            </form>
          </>
        )}
      </div>
    </aside>
  );
}
