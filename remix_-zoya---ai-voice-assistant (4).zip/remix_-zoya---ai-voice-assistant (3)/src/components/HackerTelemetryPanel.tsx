import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ChevronDown,
  ChevronUp,
  Cpu,
  Download,
  Flame,
  Footprints,
  Gauge,
  HardDrive,
  HeartPulse,
  Link2,
  Radio,
  RefreshCw,
  Terminal,
  Upload,
  Wifi,
} from "lucide-react";
import { RadhaConfig } from "../services/memoryService";
import { BossSentimentRecord } from "../services/sentimentService";
import { BiologicalStatusData } from "../services/fitnessService";

interface ServerTelemetry {
  uptimeSec: number;
  cpuUsagePct: number;
  cpuLoad1m: number;
  cpuCores: number;
  heapUsedMB: number;
  rssMB: number;
  usedMemMB: number;
  totalMemMB: number;
  freeMemMB: number;
  ramUsedPct: number;
  activeLiveSockets: number;
  serverTime?: number;
}

interface HackerTelemetryPanelProps {
  config: RadhaConfig;
  isSessionActive: boolean;
  wakeWordActive: boolean;
  cyberLogs: string[];
  bondingLevel: number;
  sentiments: BossSentimentRecord[];
  ownerVerified?: boolean;
  biologicalStatus?: BiologicalStatusData;
  isSyncingBio?: boolean;
  onConnectGoogleFit?: () => void;
  onImportAppleHealthFile?: (file: File) => void;
  onDisconnectBio?: () => void;
}

function formatUptime(sec: number): string {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

function buildGraphCoords(
  series: number[],
  maxVal: number,
  width: number = 220,
  height: number = 42
): { polyline: string; area: string; lastX: number; lastY: number } {
  const safeSeries = series.length >= 2 ? series : [series[0] ?? 0, series[0] ?? 0];
  const safeMax = Math.max(1, maxVal);
  const coords = safeSeries.map((v, idx) => {
    const x = (idx / Math.max(1, safeSeries.length - 1)) * width;
    const norm = clamp(v / safeMax, 0.04, 0.96);
    const y = height - norm * (height - 4) - 2;
    return { x, y };
  });

  const polyline = coords.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const last = coords[coords.length - 1] || { x: width, y: height / 2 };
  const area = `0,${height} ${polyline} ${width},${height}`;
  return { polyline, area, lastX: last.x, lastY: last.y };
}

function computeDailyBossHealth(sentiments: BossSentimentRecord[]) {
  const startOfToday = new Date();
  startOfToday.setHours(0, 0, 0, 0);
  const todayMs = startOfToday.getTime();

  const todayRecords = sentiments.filter((s) => s.createdAt >= todayMs);
  const sample = todayRecords.length > 0 ? todayRecords : sentiments.slice(0, 8);

  if (sample.length === 0) {
    return {
      stressPct: 18,
      fatiguePct: 22,
      strainIndex: 20, // 0 = green/optimal, 100 = red/critical
      healthPct: 80,
      statusLabel: "Optimal",
      barColor: "#16A34A",
      sampleCount: 0,
    };
  }

  const avgStress = Math.round(
    sample.reduce((acc, r) => acc + clamp(r.stressLevel, 0, 100), 0) / sample.length
  );
  // Fatigue rises when energy is low and stress is high
  const avgFatigue = Math.round(
    sample.reduce(
      (acc, r) => acc + clamp(Math.round((100 - r.energyLevel) * 0.65 + r.stressLevel * 0.35), 0, 100),
      0
    ) / sample.length
  );

  const strainIndex = clamp(Math.round(avgStress * 0.55 + avgFatigue * 0.45), 0, 100);
  const healthPct = 100 - strainIndex;

  let statusLabel = "Optimal";
  let barColor = "#16A34A"; // Green
  if (strainIndex >= 68) {
    statusLabel = "High Strain";
    barColor = "#DC2626"; // Red
  } else if (strainIndex >= 40) {
    statusLabel = "Elevated";
    barColor = "#D97706"; // Amber
  }

  return {
    stressPct: avgStress,
    fatiguePct: avgFatigue,
    strainIndex,
    healthPct,
    statusLabel,
    barColor,
    sampleCount: todayRecords.length,
  };
}

export default function HackerTelemetryPanel({
  config,
  isSessionActive,
  wakeWordActive,
  cyberLogs,
  bondingLevel,
  sentiments,
  ownerVerified = false,
  biologicalStatus,
  isSyncingBio = false,
  onConnectGoogleFit,
  onImportAppleHealthFile,
  onDisconnectBio,
}: HackerTelemetryPanelProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activeView, setActiveView] = useState<"health" | "system">("health");
  const appleHealthFileRef = useRef<HTMLInputElement | null>(null);
  const [telemetry, setTelemetry] = useState<ServerTelemetry | null>(null);
  const [pingMs, setPingMs] = useState<number | null>(null);
  const [pingHistory, setPingHistory] = useState<number[]>([]);
  const [cpuHistory, setCpuHistory] = useState<number[]>([]);
  const [realSpeedMbps, setRealSpeedMbps] = useState<number | null>(null);
  const [speedHistory, setSpeedHistory] = useState<number[]>([]);
  const [isTestingSpeed, setIsTestingSpeed] = useState(false);
  const [netType, setNetType] = useState<string>("LIVE");
  const [batteryPct, setBatteryPct] = useState<number | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);

  const [eventFeed, setEventFeed] = useState<Array<{ id: string; time: string; msg: string }>>([
    { id: "init-1", time: new Date().toLocaleTimeString([], { hour12: false }), msg: "Real-time telemetry link ready" },
  ]);
  const lastLogCountRef = useRef(0);

  const bossHealth = useMemo(() => computeDailyBossHealth(sentiments), [sentiments]);

  // Real download throughput probe against /api/speedtest (128 KB binary payload)
  const runRealSpeedProbe = useCallback(async () => {
    setIsTestingSpeed(true);
    try {
      const start = performance.now();
      const res = await fetch(`/api/speedtest?t=${Date.now()}`, { cache: "no-store" });
      const buf = await res.arrayBuffer();
      const durationSec = Math.max(0.004, (performance.now() - start) / 1000);
      const bitsLoaded = buf.byteLength * 8;
      const mbps = Number((bitsLoaded / (durationSec * 1_000_000)).toFixed(1));
      setRealSpeedMbps(mbps);
      setSpeedHistory((prev) => [...prev.slice(-15), mbps]);
    } catch {
      const navConn = (navigator as any).connection;
      if (typeof navConn?.downlink === "number") {
        setRealSpeedMbps(Number(navConn.downlink.toFixed(1)));
      }
    } finally {
      setIsTestingSpeed(false);
    }
  }, []);

  // Sync ONLY genuine real system events from App / LiveSession (zero fake packets!)
  useEffect(() => {
    if (cyberLogs.length > lastLogCountRef.current) {
      const fresh = cyberLogs.slice(lastLogCountRef.current);
      lastLogCountRef.current = cyberLogs.length;
      const nowStr = new Date().toLocaleTimeString([], { hour12: false });
      setEventFeed((prev) => [
        ...prev.slice(-12),
        ...fresh.map((msg, i) => ({
          id: `real-${Date.now()}-${i}`,
          time: nowStr,
          msg,
        })),
      ]);
    }
  }, [cyberLogs]);

  // Poll 100% REAL server CPU/RAM telemetry & measure REAL HTTP RTT ping every 3s
  useEffect(() => {
    let active = true;

    const pollRealTelemetry = async () => {
      const start = performance.now();
      try {
        const res = await fetch("/api/telemetry", { cache: "no-store" });
        const elapsed = Math.max(1, Math.round(performance.now() - start));
        if (!active) return;
        if (res.ok) {
          const data: ServerTelemetry = await res.json();
          setTelemetry(data);
          setCpuHistory((prev) => [...prev.slice(-17), data.cpuUsagePct]);
        }
        setPingMs(elapsed);
        setPingHistory((prev) => [...prev.slice(-17), elapsed]);
      } catch {
        if (!active) return;
        setPingMs(null);
      }

      const navConn =
        (navigator as any).connection ||
        (navigator as any).mozConnection ||
        (navigator as any).webkitConnection;
      if (navConn?.effectiveType) {
        setNetType(String(navConn.effectiveType).toUpperCase());
      }
    };

    pollRealTelemetry();
    runRealSpeedProbe();

    const telInterval = window.setInterval(pollRealTelemetry, 3000);
    const speedInterval = window.setInterval(runRealSpeedProbe, 20000);

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    if (typeof (navigator as any).getBattery === "function") {
      (navigator as any)
        .getBattery()
        .then((bat: any) => {
          if (!active) return;
          setBatteryPct(Math.round(bat.level * 100));
          bat.addEventListener("levelchange", () => {
            if (active) setBatteryPct(Math.round(bat.level * 100));
          });
        })
        .catch(() => {});
    }

    return () => {
      active = false;
      window.clearInterval(telInterval);
      window.clearInterval(speedInterval);
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [runRealSpeedProbe]);

  if (config.showTelemetryPanel === false) {
    return null;
  }

  const primary = config.primaryColor || "#00ff9d";
  const secondary = config.secondaryColor || "#00e5ff";

  const maxPing = Math.max(60, ...pingHistory);
  const pingGraph = buildGraphCoords(pingHistory, maxPing, 220, 40);
  const cpuGraph = buildGraphCoords(cpuHistory, 100, 220, 40);
  const realJitterMs =
    pingHistory.length >= 2
      ? Math.max(...pingHistory.slice(-6)) - Math.min(...pingHistory.slice(-6))
      : 0;

  const sideClass = config.compactChatPosition === "left" ? "right-3 sm:right-5" : "left-3 sm:left-5";

  return (
    <aside
      className={`hidden md:flex fixed z-20 ${sideClass} top-20 bottom-24 w-[284px] lg:w-[306px] flex-col justify-center pointer-events-auto`}
    >
      <div
        className={`flex flex-col bg-[#040a0e]/90 backdrop-blur-xl border rounded-xl shadow-2xl overflow-hidden transition-all duration-200 font-mono ${
          isCollapsed ? "h-auto" : "max-h-[73vh]"
        }`}
        style={{
          borderColor: `${primary}35`,
          boxShadow: `0 0 28px ${primary}14`,
        }}
      >
        {/* Clean Tactical Header */}
        <div
          className="flex items-center justify-between px-3 py-2 border-b shrink-0"
          style={{ borderColor: `${primary}25`, backgroundColor: `${primary}0c` }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Activity size={13} style={{ color: primary }} className="shrink-0" />
            <span className="text-[11px] font-bold tracking-wider truncate" style={{ color: primary }}>
              Live Telemetry &amp; Health
            </span>
          </div>
          <div className="flex items-center gap-2 text-[10px]">
            <span className={isOnline ? "text-emerald-400" : "text-red-400"}>
              {isOnline ? "Online" : "Offline"}
            </span>
            <button
              type="button"
              onClick={() => setIsCollapsed((v) => !v)}
              className="p-1 rounded text-white/55 hover:text-white hover:bg-white/10 cursor-pointer"
              title={isCollapsed ? "Expand Telemetry" : "Minimize Telemetry"}
            >
              {isCollapsed ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
            </button>
          </div>
        </div>

        {!isCollapsed && (
          <>
            {/* Segmented Mode Switcher */}
            <div className="grid grid-cols-2 gap-1 p-2 pb-1.5 shrink-0 border-b border-white/[0.06] bg-black/30">
              <button
                type="button"
                onClick={() => setActiveView("health")}
                className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                  activeView === "health"
                    ? "text-black"
                    : "text-white/60 hover:text-white bg-white/[0.03]"
                }`}
                style={activeView === "health" ? { backgroundColor: primary } : undefined}
              >
                <HeartPulse size={11} />
                <span>Boss &amp; Net</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveView("system")}
                className={`flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-[10px] font-semibold transition-colors cursor-pointer ${
                  activeView === "system"
                    ? "text-black"
                    : "text-white/60 hover:text-white bg-white/[0.03]"
                }`}
                style={activeView === "system" ? { backgroundColor: secondary } : undefined}
              >
                <Gauge size={11} />
                <span>Host &amp; Logs</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-thin text-[11px]">
              {/* BOSS HEALTH INDICATOR (Always visible in primary tab — tracks daily stress & fatigue with green-to-red bar) */}
              <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-[10px] text-white/75 font-semibold">
                    <HeartPulse size={12} style={{ color: bossHealth.barColor }} />
                    <span>Boss Health</span>
                  </span>
                  <span
                    className="text-[10px] font-bold tabular-nums"
                    style={{ color: bossHealth.barColor }}
                  >
                    {bossHealth.statusLabel} · {bossHealth.healthPct}%
                  </span>
                </div>

                {/* Color-coded Green-to-Red Daily Stress & Fatigue Bar */}
                <div className="space-y-1">
                  <div className="relative h-2.5 rounded-full bg-white/10 overflow-hidden">
                    {/* Continuous green -> amber -> red track */}
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${Math.max(8, bossHealth.strainIndex)}%`,
                        background:
                          "linear-gradient(90deg, #16A34A 0%, #84CC16 32%, #D97706 64%, #DC2626 100%)",
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-[9px] text-white/45 tabular-nums">
                    <span>Fresh (0%)</span>
                    <span>Strain: {bossHealth.strainIndex}%</span>
                    <span>Burnout (100%)</span>
                  </div>
                </div>

                {/* Daily Stress & Fatigue Numeric Breakdown */}
                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/10 text-[10px] tabular-nums">
                  <div>
                    <div className="text-[9px] text-white/45">Daily Stress</div>
                    <div
                      className="font-bold"
                      style={{
                        color:
                          bossHealth.stressPct >= 65
                            ? "#DC2626"
                            : bossHealth.stressPct >= 40
                            ? "#D97706"
                            : "#16A34A",
                      }}
                    >
                      {bossHealth.stressPct}%
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[9px] text-white/45">Daily Fatigue</div>
                    <div
                      className="font-bold"
                      style={{
                        color:
                          bossHealth.fatiguePct >= 65
                            ? "#DC2626"
                            : bossHealth.fatiguePct >= 40
                            ? "#D97706"
                            : "#16A34A",
                      }}
                    >
                      {bossHealth.fatiguePct}%
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[9px] text-white/45 pt-0.5 tabular-nums">
                  <span>
                    {bossHealth.sampleCount > 0
                      ? `${bossHealth.sampleCount} scans today`
                      : "Baseline · chat to update"}
                  </span>
                  <span className={ownerVerified ? "text-emerald-400" : "text-white/40"}>
                    {ownerVerified ? "Face ID Verified" : "Face ID Standby"}
                  </span>
                </div>
              </div>

              {/* BIOLOGICAL STATUS (Real Google Fit REST API & Apple Health Export Sync — Zero Mock Data) */}
              <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-[10px] text-white/80 font-semibold">
                    <Footprints size={12} style={{ color: secondary }} />
                    <span>Biological Status</span>
                  </span>
                  <span
                    className="text-[9.5px] font-bold uppercase tracking-wide"
                    style={{
                      color:
                        biologicalStatus && biologicalStatus.source !== "disconnected"
                          ? primary
                          : "rgba(255,255,255,0.45)",
                    }}
                  >
                    {biologicalStatus && biologicalStatus.source !== "disconnected"
                      ? biologicalStatus.source === "google-fit"
                        ? "Google Fit"
                        : biologicalStatus.source === "apple-health"
                        ? "Apple Health"
                        : "Live Feed"
                      : "Disconnected"}
                  </span>
                </div>

                {biologicalStatus && biologicalStatus.source !== "disconnected" ? (
                  <>
                    <div className="grid grid-cols-2 gap-2 text-[10px] tabular-nums">
                      <div className="p-1.5 rounded bg-white/[0.03] border border-white/[0.06]">
                        <div className="text-[9px] text-white/45">Steps Today</div>
                        <div className="font-bold text-xs" style={{ color: primary }}>
                          {biologicalStatus.steps !== null
                            ? biologicalStatus.steps.toLocaleString()
                            : "--"}
                        </div>
                      </div>
                      <div className="p-1.5 rounded bg-white/[0.03] border border-white/[0.06]">
                        <div className="text-[9px] text-white/45 flex items-center gap-1">
                          <HeartPulse size={9} className="text-rose-400" />
                          <span>Heart Rate</span>
                        </div>
                        <div className="font-bold text-xs text-rose-300">
                          {biologicalStatus.heartRateBpm !== null
                            ? `${biologicalStatus.heartRateBpm} BPM`
                            : "--"}
                        </div>
                      </div>
                      <div className="p-1.5 rounded bg-white/[0.03] border border-white/[0.06]">
                        <div className="text-[9px] text-white/45 flex items-center gap-1">
                          <Flame size={9} className="text-amber-400" />
                          <span>Calories</span>
                        </div>
                        <div className="font-bold text-xs text-amber-300">
                          {biologicalStatus.caloriesKcal !== null
                            ? `${biologicalStatus.caloriesKcal} kcal`
                            : "--"}
                        </div>
                      </div>
                      <div className="p-1.5 rounded bg-white/[0.03] border border-white/[0.06]">
                        <div className="text-[9px] text-white/45">Active / Dist</div>
                        <div className="font-bold text-xs text-cyan-300">
                          {biologicalStatus.activeMinutes !== null
                            ? `${biologicalStatus.activeMinutes}m`
                            : biologicalStatus.distanceKm !== null
                            ? `${biologicalStatus.distanceKm} km`
                            : "--"}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-1.5 pt-1 border-t border-white/10 text-[9px] text-white/50">
                      <span className="truncate">
                        {biologicalStatus.lastSyncedAt
                          ? `Synced ${new Date(biologicalStatus.lastSyncedAt).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}`
                          : biologicalStatus.connectedLabel}
                      </span>
                      <div className="flex items-center gap-1 shrink-0">
                        {onConnectGoogleFit && biologicalStatus.source === "google-fit" && (
                          <button
                            type="button"
                            onClick={onConnectGoogleFit}
                            disabled={isSyncingBio}
                            className="px-1.5 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white/80 cursor-pointer disabled:opacity-40"
                            title="Refresh Google Fit"
                          >
                            <RefreshCw size={9} className={isSyncingBio ? "animate-spin" : ""} />
                          </button>
                        )}
                        {onDisconnectBio && (
                          <button
                            type="button"
                            onClick={onDisconnectBio}
                            className="px-1.5 py-0.5 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 cursor-pointer"
                            title="Disconnect health source"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-2">
                    <p className="text-[9.5px] text-white/50 leading-snug">
                      Connect real Google Fit or import Apple Health export for live steps, BPM &amp; calories.
                    </p>
                    <div className="grid grid-cols-2 gap-1.5">
                      {onConnectGoogleFit && (
                        <button
                          type="button"
                          onClick={onConnectGoogleFit}
                          disabled={isSyncingBio}
                          className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md text-[9.5px] font-bold text-black cursor-pointer disabled:opacity-50"
                          style={{ backgroundColor: primary }}
                        >
                          <Link2 size={10} />
                          <span>{isSyncingBio ? "Syncing..." : "Google Fit"}</span>
                        </button>
                      )}
                      {onImportAppleHealthFile && (
                        <>
                          <input
                            ref={appleHealthFileRef}
                            type="file"
                            accept=".xml,.json"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                onImportAppleHealthFile(file);
                                e.target.value = "";
                              }
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => appleHealthFileRef.current?.click()}
                            disabled={isSyncingBio}
                            className="flex items-center justify-center gap-1 py-1.5 px-2 rounded-md text-[9.5px] font-semibold bg-white/10 hover:bg-white/15 border border-white/15 text-white/85 cursor-pointer disabled:opacity-50"
                          >
                            <Upload size={10} />
                            <span>Apple Health</span>
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {activeView === "health" ? (
                <>
                  {/* REAL LIVE NETWORK SPEED (Measured directly via /api/speedtest) */}
                  <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5 text-[10px] text-white/75 font-semibold">
                        <Download size={11} style={{ color: primary }} />
                        <span>Real Net Speed</span>
                      </span>
                      <button
                        type="button"
                        onClick={runRealSpeedProbe}
                        disabled={isTestingSpeed}
                        className="flex items-center gap-1 text-[9.5px] text-white/65 hover:text-white cursor-pointer disabled:opacity-40"
                        title="Run real speed probe now"
                      >
                        <RefreshCw size={10} className={isTestingSpeed ? "animate-spin" : ""} />
                        <span>{isTestingSpeed ? "Testing" : "Test"}</span>
                      </button>
                    </div>

                    <div className="flex items-baseline justify-between tabular-nums">
                      <div className="text-lg font-bold" style={{ color: primary }}>
                        {realSpeedMbps !== null ? `${realSpeedMbps} Mbps` : "Measuring..."}
                      </div>
                      <div className="text-[10px] text-white/55">
                        {realSpeedMbps !== null
                          ? `${Math.round((realSpeedMbps * 1000) / 8)} KB/s`
                          : "--"}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[9.5px] text-white/50 pt-1 border-t border-white/10 tabular-nums">
                      <span>Link: {netType}</span>
                      <span>
                        Peak: {speedHistory.length ? `${Math.max(...speedHistory)} Mbps` : "--"}
                      </span>
                    </div>
                  </div>

                  {/* REAL PING RTT & JITTER GRAPH */}
                  <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-1.5 text-[10px] text-white/75 font-semibold">
                        <Wifi size={11} style={{ color: secondary }} />
                        <span>Real Ping RTT</span>
                      </span>
                      <span
                        className="font-bold text-xs tabular-nums"
                        style={{
                          color:
                            pingMs === null
                              ? "#DC2626"
                              : pingMs < 120
                              ? primary
                              : "#D97706",
                        }}
                      >
                        {pingMs !== null ? `${pingMs} ms` : "Offline"}
                      </span>
                    </div>

                    <div className="rounded bg-[#02070a] border border-white/[0.06] px-1 py-1">
                      <svg viewBox="0 0 220 40" className="w-full h-10 overflow-visible">
                        <defs>
                          <linearGradient id="realPingGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={secondary} stopOpacity="0.38" />
                            <stop offset="100%" stopColor={secondary} stopOpacity="0.02" />
                          </linearGradient>
                        </defs>
                        <polygon fill="url(#realPingGrad)" points={pingGraph.area} />
                        <polyline
                          fill="none"
                          stroke={secondary}
                          strokeWidth="1.6"
                          strokeLinejoin="round"
                          points={pingGraph.polyline}
                        />
                        <circle cx={pingGraph.lastX} cy={pingGraph.lastY} r="2.5" fill={secondary} />
                      </svg>
                    </div>

                    <div className="flex items-center justify-between text-[9.5px] text-white/50 tabular-nums">
                      <span>Jitter: ±{realJitterMs} ms</span>
                      <span>
                        Wake:{" "}
                        <span className={wakeWordActive ? "text-emerald-400" : "text-white/45"}>
                          {wakeWordActive ? `"${config.wakeWordText || "राधा"}" ON` : "Off"}
                        </span>
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* REAL SERVER CPU USAGE (OS Tick Delta) */}
                  <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-1.5">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="flex items-center gap-1.5 text-white/75 font-semibold">
                        <Cpu size={11} style={{ color: primary }} />
                        <span>Host CPU (Real)</span>
                      </span>
                      <span className="font-bold tabular-nums" style={{ color: primary }}>
                        {telemetry ? `${telemetry.cpuUsagePct}%` : "--"}
                      </span>
                    </div>

                    <div className="rounded bg-[#02070a] border border-white/[0.06] px-1 py-1">
                      <svg viewBox="0 0 220 40" className="w-full h-10 overflow-visible">
                        <defs>
                          <linearGradient id="realCpuGrad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={primary} stopOpacity="0.38" />
                            <stop offset="100%" stopColor={primary} stopOpacity="0.02" />
                          </linearGradient>
                        </defs>
                        <polygon fill="url(#realCpuGrad)" points={cpuGraph.area} />
                        <polyline
                          fill="none"
                          stroke={primary}
                          strokeWidth="1.6"
                          strokeLinejoin="round"
                          points={cpuGraph.polyline}
                        />
                        <circle cx={cpuGraph.lastX} cy={cpuGraph.lastY} r="2.5" fill={primary} />
                      </svg>
                    </div>

                    <div className="flex items-center justify-between text-[9.5px] text-white/50 tabular-nums">
                      <span>{telemetry?.cpuCores ?? "--"} Cores</span>
                      <span>Up {telemetry ? formatUptime(telemetry.uptimeSec) : "00:00:00"}</span>
                    </div>
                  </div>

                  {/* REAL SERVER RAM & NODE HEAP */}
                  <div className="p-2.5 rounded-lg bg-black/55 border border-white/10 space-y-2 tabular-nums">
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="flex items-center gap-1.5 text-white/75 font-semibold">
                        <HardDrive size={11} style={{ color: secondary }} />
                        <span>Host RAM (Real)</span>
                      </span>
                      <span className="font-bold" style={{ color: secondary }}>
                        {telemetry ? `${telemetry.ramUsedPct}%` : "--"}
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${telemetry?.ramUsedPct ?? 0}%`,
                          backgroundColor: secondary,
                        }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[9.5px] text-white/50">
                      <span>
                        Heap: {telemetry?.heapUsedMB ?? "--"} MB · RSS: {telemetry?.rssMB ?? "--"} MB
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[9.5px] text-white/50 pt-1 border-t border-white/10">
                      <span className="flex items-center gap-1">
                        <Radio size={10} style={{ color: primary }} />
                        Live WS: {telemetry?.activeLiveSockets ?? (isSessionActive ? 1 : 0)}
                      </span>
                      <span>
                        Power: {batteryPct !== null ? `${batteryPct}%` : "AC"} · Bond L{bondingLevel}
                      </span>
                    </div>
                  </div>

                  {/* REAL SYSTEM EVENTS LOG (No fake packets) */}
                  <div className="p-2.5 rounded-lg bg-black/65 border border-white/10 space-y-1.5">
                    <div className="flex items-center justify-between text-[10px] text-white/65 font-semibold">
                      <span className="flex items-center gap-1.5">
                        <Terminal size={11} style={{ color: primary }} />
                        <span>System Events</span>
                      </span>
                      <span className="text-[9px] text-white/40">{eventFeed.length}</span>
                    </div>
                    <div className="space-y-1 max-h-28 overflow-y-auto scrollbar-thin pr-1">
                      {eventFeed.slice(-7).map((entry) => (
                        <div key={entry.id} className="text-[9.5px] leading-tight text-emerald-300/90 break-words">
                          <span className="text-white/35 mr-1">[{entry.time}]</span>
                          <span>{entry.msg}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </>
        )}
      </div>
    </aside>
  );
}
